# -*- coding: utf-8 -*-
"""
اقتصاد رادیوی رویال: توکن + صف نوبتی + لایک به DJ

  • هر ۳۰ دقیقه ماندن در روم = ۵ توکن (قابل تنظیم)
  • هر آهنگ توی صف = ۱ توکن؛ صف نوبتی است (هر نفر یکی، بعد دور بعد)
  • لایک (!like): ۱ توکن به کسی که آهنگ را گذاشته برمی‌گردد
  • مدیر توکن می‌دهد/می‌گیرد: !tokengive !tokentake !tokenall

  !token  !tokentop  !like  !djtop  !save  !saved  !unsave
"""
import os
import asyncio
import logging

from persistent_store import load_json, save_json
from php_radio import CFG_FILE

logger = logging.getLogger(__name__)

_ECO_DEFAULTS = {
    "earn_amount": 5,        # توکن هر دوره‌ی حضور
    "earn_minutes": 30,      # طول هر دوره (دقیقه)
    "queue_cost": 1,         # هزینه‌ی گذاشتن آهنگ توی صف
    "save_cost": 2,          # هزینه‌ی ذخیره‌ی آهنگ توی حافظه‌ی سرور
    "like_reward": 1,        # توکنی که DJ با هر لایک می‌گیرد
    "max_queue_per_user": 2, # حداکثر آهنگ هر نفر توی صف همزمان
}

_ECO_COMMANDS = (
    "!token", "!tokens", "!توکن", "!tokengive", "!tokentake", "!tokenall",
    "!tokentop", "!like", "!djtop", "!save", "!saved", "!unsave",
)


def _num(text, default=None):
    try:
        return int(str(text).strip())
    except (TypeError, ValueError):
        return default


class RadioTokensMixin:
    # ─── تنظیمات و ذخیره‌سازی ──────────────────────────────────
    def _eco_cfg(self):
        cfg = dict(_ECO_DEFAULTS)
        extra = (load_json(CFG_FILE, {}) or {}).get("economy", {})
        if isinstance(extra, dict):
            for key in cfg:
                value = _num(extra.get(key))
                if value is not None and value >= 0:
                    cfg[key] = value
        cfg["earn_minutes"] = max(1, cfg["earn_minutes"])
        return cfg

    def _eco_path(self):
        base = os.path.dirname(os.path.abspath(self.ext_config_file))
        return os.path.join(base, "radio_economy.json")

    def _eco_data(self):
        if getattr(self, "_eco", None) is None:
            data = load_json(self._eco_path(), {})
            if not isinstance(data, dict):
                data = {}
            for key in ("balances", "likes", "names"):
                if not isinstance(data.get(key), dict):
                    data[key] = {}
            self._eco = data
            self._eco_progress = {}
            self._eco_like_seq = None
            self._eco_likers = set()
        return self._eco

    def _eco_save(self):
        try:
            save_json(self._eco_path(), self._eco_data())
        except Exception as exc:
            logger.error(f"ذخیره‌ی توکن‌ها ناموفق بود: {exc}")

    def _eco_bal(self, name):
        return int(self._eco_data()["balances"].get(name.lower(), 0))

    def _eco_add(self, name, amount, display=None):
        data = self._eco_data()
        low = name.lower()
        data["balances"][low] = max(0, int(data["balances"].get(low, 0)) + int(amount))
        data["names"][low] = display or data["names"].get(low) or name
        self._eco_save()
        return data["balances"][low]

    def _eco_name(self, low):
        return self._eco_data()["names"].get(low, low)

    async def _eco_room_names(self):
        resp = await self.highrise.get_room_users()
        users = resp.content if hasattr(resp, "content") else []
        return {u.username.lower(): u.username for u, _ in users if u.id != self.user_id}

    # ─── درآمد حضور در روم ─────────────────────────────────────
    async def _eco_earn_loop(self):
        await asyncio.sleep(20)
        self._eco_data()
        while True:
            try:
                if self._php_ready():
                    present = await self._eco_room_names()
                    cfg = self._eco_cfg()
                    prog = self._eco_progress
                    for low in [k for k in prog if k not in present]:
                        del prog[low]                      # از روم رفت ← دوره از اول
                    rewarded = []
                    for low, shown in present.items():
                        prog[low] = prog.get(low, 0) + 1
                        if prog[low] >= cfg["earn_minutes"]:
                            prog[low] = 0
                            self._eco_add(low, cfg["earn_amount"], shown)
                            rewarded.append("@" + shown)
                    if rewarded and cfg["earn_amount"] > 0:
                        await self._php_say(f"💰 توکن حضور (+{cfg['earn_amount']}): " + " ".join(rewarded))
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.debug(f"حلقه‌ی توکن: {exc}")
            await asyncio.sleep(60)

    # ─── کمک‌ها ────────────────────────────────────────────────
    async def _eco_no_radio(self):
        await self.highrise.chat("⚠️ رادیو هنوز تنظیم نشده (radio_config.json).")

    def _eco_target(self, arg):
        first = arg.strip().split(maxsplit=1)
        return first[0].lstrip("@") if first else ""

    # ─── روتر دستورها ──────────────────────────────────────────
    async def _cmd_eco(self, user, message):
        if not self._php_ready():
            return await self._eco_no_radio()
        parts = message.strip().split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""
        admin = self._is_admin(user)
        cfg = self._eco_cfg()
        data = self._eco_data()

        if cmd in ("!token", "!tokens", "!توکن"):
            low = user.username.lower()
            left = cfg["earn_minutes"] - self._eco_progress.get(low, 0)
            return await self._php_say(
                f"💰 @{user.username}: {self._eco_bal(user.username)} توکن\n"
                f"⏳ {left} دقیقه‌ی دیگر +{cfg['earn_amount']} توکن\n"
                f"🎤 هر آهنگ توی صف: {cfg['queue_cost']} توکن | ❤️ لایک‌ها توکن برمی‌گردانند"
            )

        if cmd in ("!tokengive", "!tokentake"):
            if not admin:
                return await self.highrise.chat("⛔ این دستور فقط برای مدیر است.")
            bits = arg.split()
            amount = _num(bits[1]) if len(bits) > 1 else None
            if not bits or not amount or amount <= 0 or amount > 100000:
                return await self.highrise.chat(f"فرمت: {cmd} @اسم تعداد")
            target = self._eco_target(arg)
            sign = 1 if cmd == "!tokengive" else -1
            new = self._eco_add(target, sign * amount)
            verb = "گرفت" if sign > 0 else "از دست داد"
            return await self.highrise.chat(f"✅ @{target} {amount} توکن {verb}. موجودی: {new}")

        if cmd == "!tokenall":
            if not admin:
                return await self.highrise.chat("⛔ این دستور فقط برای مدیر است.")
            amount = _num(arg)
            if not amount or amount <= 0 or amount > 1000:
                return await self.highrise.chat("فرمت: !tokenall تعداد")
            present = await self._eco_room_names()
            for low, shown in present.items():
                self._eco_add(low, amount, shown)
            return await self.highrise.chat(f"🎁 {amount} توکن به {len(present)} نفر داخل روم داده شد!")

        if cmd == "!tokentop":
            top = sorted(data["balances"].items(), key=lambda kv: kv[1], reverse=True)[:5]
            top = [(k, v) for k, v in top if v > 0]
            if not top:
                return await self.highrise.chat("هنوز کسی توکن ندارد.")
            lines = [f"{i}) @{self._eco_name(k)} — {v}" for i, (k, v) in enumerate(top, 1)]
            return await self._php_say("🏦 ثروتمندترین‌ها:\n" + "\n".join(lines))

        if cmd == "!djtop":
            top = sorted(data["likes"].items(), key=lambda kv: kv[1], reverse=True)[:5]
            top = [(k, v) for k, v in top if v > 0]
            if not top:
                return await self.highrise.chat("هنوز کسی لایک نگرفته؛ آهنگ بذار و لایک جمع کن! ❤️")
            lines = [f"{i}) @{self._eco_name(k)} — ❤️ {v}" for i, (k, v) in enumerate(top, 1)]
            return await self._php_say("🏆 برترین DJهای رویال:\n" + "\n".join(lines))

        if cmd == "!like":
            st = await self._php_status_data()
            if not st or not st.get("playing"):
                return await self.highrise.chat("الان آهنگی پخش نمی‌شود.")
            seq, dj = st.get("now_seq"), st.get("now_playing_by", "")
            if self._eco_like_seq != seq:
                self._eco_like_seq, self._eco_likers = seq, set()
            low = user.username.lower()
            if dj and low == dj.lower():
                return await self.highrise.chat("😅 آهنگ خودت را نمی‌شود لایک کرد.")
            if low in self._eco_likers:
                return await self.highrise.chat("❤️ قبلاً این آهنگ را لایک کرده‌ای.")
            self._eco_likers.add(low)
            text = f"❤️ @{user.username} این آهنگ را پسندید ({len(self._eco_likers)} لایک)"
            if dj:
                data["likes"][dj.lower()] = int(data["likes"].get(dj.lower(), 0)) + 1
                if cfg["like_reward"] > 0:
                    self._eco_add(dj, cfg["like_reward"])
                else:
                    self._eco_save()
                text += f"\n🎤 @{dj} +{cfg['like_reward']} توکن گرفت"
            return await self._php_say(text)

        if cmd == "!save":
            cost = 0 if admin else cfg["save_cost"]
            if cost and self._eco_bal(user.username) < cost:
                return await self.highrise.chat(
                    f"💰 ذخیره‌ی آهنگ {cost} توکن است؛ موجودی تو {self._eco_bal(user.username)}."
                )
            code, res = await self._php_api("save", {"by": user.username})
            if code == 200 and res and res.get("ok"):
                if cost:
                    self._eco_add(user.username, -cost)
                extra = " (جا کم بود؛ قدیمی‌ترین ذخیره‌ها پاک شد)" if res.get("evicted") else ""
                return await self._php_say(
                    f"💾 «{res.get('title')}» ذخیره شد{extra}\nپخش: !p s{res.get('n')} | صف: !q s{res.get('n')}"
                )
            return await self.highrise.chat(f"❌ {(res or {}).get('error') or 'سرور رادیو جواب نداد'}")

        if cmd == "!saved":
            code, res = await self._php_api("saved", timeout=10)
            tracks = (res or {}).get("tracks", []) if code == 200 else []
            if not tracks:
                return await self.highrise.chat("💾 هنوز آهنگ ذخیره‌شده‌ای نیست؛ وقتی آهنگ لینکی پخش می‌شود !save بزن.")
            per = 8
            pages = (len(tracks) + per - 1) // per
            page = min(max(_num(arg, 1), 1), pages)
            chunk = tracks[(page - 1) * per: page * per]
            lines = [f"s{t['n']}. {t['title']}" + (f" (@{t['by']})" if t.get("by") else "") for t in chunk]
            tail = f"\nپخش: !p s1 | صف: !q s1" + (f" | صفحه بعد: !saved {page + 1}" if page < pages else "")
            return await self._php_say(f"💾 آهنگ‌های ذخیره‌شده ({page}/{pages}):\n" + "\n".join(lines) + tail)

        if cmd == "!unsave":
            if not admin:
                return await self.highrise.chat("⛔ این دستور فقط برای مدیر است.")
            n = _num(arg.lower().lstrip("s"))
            if not n:
                return await self.highrise.chat("فرمت: !unsave شماره")
            code, res = await self._php_api("unsave", {"n": n})
            if code == 200 and res and res.get("ok"):
                return await self.highrise.chat(f"🗑 «{res.get('title')}» از ذخیره‌ها حذف شد.")
            return await self.highrise.chat(f"❌ {(res or {}).get('error') or 'سرور رادیو جواب نداد'}")
