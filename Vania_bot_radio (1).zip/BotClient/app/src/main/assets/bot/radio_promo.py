# -*- coding: utf-8 -*-
"""
راهنمای رادیو + لوپ تبلیغ/آموزش توکن (زردرنگ)

  !radiohelp                      همه‌ی دستورهای رادیو (برای همه)
  !radiopromo                     (مدیر) وضعیت لوپ و تنظیمات
  !radiopromo on | off            روشن/خاموش
  !radiopromo time <دقیقه>        فاصله‌ی پیام‌ها
  !radiopromo text <متن>          متن دلخواه   |  !radiopromo text reset  ← برگشت به متن پیش‌فرض
  !radiopromo color <زرد|قرمز|سبز|آبی|نارنجی|سفید|#RRGGBB|off>
  !radiopromo now                 همین الان یک‌بار بفرست

تنظیمات داخل پوشه‌ی داده‌ی بات ذخیره می‌شود؛ پس بدون بیلد جدید قابل تغییر است.
"""
import os
import time
import asyncio
import logging

from persistent_store import load_json, save_json

logger = logging.getLogger(__name__)

_PROMO_COMMANDS = ("!radiohelp", "!radiopromo")

_COLORS = {
    "yellow": "#FFD700", "زرد": "#FFD700",
    "red": "#FF4D4D", "قرمز": "#FF4D4D",
    "green": "#3DDC84", "سبز": "#3DDC84",
    "blue": "#4DA3FF", "آبی": "#4DA3FF",
    "orange": "#FF9F1A", "نارنجی": "#FF9F1A",
    "white": "#FFFFFF", "سفید": "#FFFFFF",
}

_DEFAULTS = {"enabled": True, "minutes": 10, "color": "#FFD700", "text": ""}


class RadioPromoMixin:
    # ─── تنظیمات ───────────────────────────────────────────────
    def _promo_path(self):
        base = os.path.dirname(os.path.abspath(self.ext_config_file))
        return os.path.join(base, "radio_promo.json")

    def _promo_cfg(self):
        data = load_json(self._promo_path(), {})
        cfg = dict(_DEFAULTS)
        if isinstance(data, dict):
            cfg.update({k: data[k] for k in _DEFAULTS if k in data})
        try:
            cfg["minutes"] = min(720, max(1, int(cfg["minutes"])))
        except (TypeError, ValueError):
            cfg["minutes"] = _DEFAULTS["minutes"]
        return cfg

    def _promo_set(self, **changes):
        cfg = self._promo_cfg()
        cfg.update(changes)
        save_json(self._promo_path(), cfg)
        return cfg

    def _promo_default_text(self):
        e = self._eco_cfg()
        return (
            "🎧 رادیو رویال — با توکن آهنگ بذار!\n"
            f"💰 هر {e['earn_minutes']} دقیقه ماندن توی روم = {e['earn_amount']} توکن\n"
            f"🎤 هر آهنگ توی صف = {e['queue_cost']} توکن | لایک بگیری توکن برمی‌گرده ❤️\n"
            "📜 دستورها: !q لینک | !musiclist | !like | !token\n"
            "همه‌ی دستورها: !radiohelp"
        )

    # ─── !radiohelp ────────────────────────────────────────────
    def _promo_help_text(self):
        e = self._eco_cfg()
        return (
            "📜 راهنمای رادیو رویال\n"
            "🎵 !musiclist [صفحه] — فهرست آهنگ‌ها (شماره‌دار)\n"
            "🎵 !q شماره/لینک/اسم — آهنگ توی صف نوبتی\n"
            "🎵 !q — نمایش صف | !radio — وضعیت پخش\n"
            f"💰 !token — توکن‌هام (هر آهنگ {e['queue_cost']} توکن)\n"
            f"💰 هر {e['earn_minutes']} دقیقه ماندن توی روم = {e['earn_amount']} توکن\n"
            "❤️ !like — لایک آهنگ؛ توکن به کسی که گذاشته می‌رسه\n"
            "🏆 !djtop برترین DJها | !tokentop ثروتمندترین‌ها\n"
            f"💾 !save — ذخیره آهنگ لینکی ({e['save_cost']} توکن)\n"
            "💾 !saved — آهنگ‌های ذخیره‌شده | پخش: !q s1\n"
            "👑 مدیر: !p شماره/لینک | !next | !prev | !radio clear\n"
            "👑 مدیر: !tokengive @اسم تعداد | !tokentake @اسم تعداد\n"
            "👑 مدیر: !tokenall تعداد | !unsave شماره | !radiopromo"
        )

    async def _cmd_radiohelp(self, user, message):
        cfg = self._promo_cfg()
        await self._php_say(self._promo_help_text(), cfg["color"] or None)

    # ─── !radiopromo (مدیر) ────────────────────────────────────
    async def _promo_send(self):
        cfg = self._promo_cfg()
        text = (cfg["text"] or "").strip() or self._promo_default_text()
        await self._php_say(text, cfg["color"] or None)

    async def _cmd_radiopromo(self, user, message):
        if not self._is_admin(user):
            return await self.highrise.chat("⛔ این دستور فقط برای مدیر است.")
        parts = message.strip().split(maxsplit=2)
        sub = parts[1].lower() if len(parts) > 1 else ""
        rest = parts[2].strip() if len(parts) > 2 else ""
        cfg = self._promo_cfg()

        if not sub:
            shown = "دلخواه" if (cfg["text"] or "").strip() else "پیش‌فرض"
            return await self._php_say(
                "⚙️ لوپ تبلیغ رادیو\n"
                f"وضعیت: {'روشن ✅' if cfg['enabled'] else 'خاموش ⛔'} | هر {cfg['minutes']} دقیقه\n"
                f"رنگ: {cfg['color'] or 'بدون رنگ'} | متن: {shown}\n"
                "!radiopromo on/off | time 10 | text متن | text reset | color زرد | now"
            )
        if sub in ("on", "off"):
            self._promo_set(enabled=(sub == "on"))
            return await self.highrise.chat("✅ لوپ روشن شد." if sub == "on" else "⛔ لوپ خاموش شد.")
        if sub == "time":
            try:
                minutes = int(rest)
            except ValueError:
                return await self.highrise.chat("فرمت: !radiopromo time 10 (دقیقه)")
            if not 1 <= minutes <= 720:
                return await self.highrise.chat("عدد باید بین ۱ تا ۷۲۰ دقیقه باشد.")
            self._promo_set(minutes=minutes)
            self._promo_last = time.monotonic()
            return await self.highrise.chat(f"✅ از حالا هر {minutes} دقیقه پیام می‌دهم.")
        if sub == "text":
            if not rest:
                return await self.highrise.chat("فرمت: !radiopromo text متن | !radiopromo text reset")
            self._promo_set(text="" if rest.lower() == "reset" else rest[:400])
            return await self.highrise.chat("✅ متن پیش‌فرض برگشت." if rest.lower() == "reset" else "✅ متن لوپ عوض شد.")
        if sub == "color":
            key = rest.lower()
            if key in ("off", "none", "بدون"):
                self._promo_set(color="")
                return await self.highrise.chat("✅ رنگ خاموش شد.")
            value = _COLORS.get(key) or _COLORS.get(rest)
            if not value and len(key) == 7 and key[0] == "#" and all(c in "0123456789abcdef" for c in key[1:]):
                value = key.upper()
            if not value:
                return await self.highrise.chat("رنگ: زرد، قرمز، سبز، آبی، نارنجی، سفید، #RRGGBB یا off")
            self._promo_set(color=value)
            return await self._php_say("✅ رنگ لوپ عوض شد.", value)
        if sub == "now":
            return await self._promo_send()
        return await self.highrise.chat("دستور نامعلوم؛ !radiopromo را تنها بزن تا راهنما را ببینی.")

    # ─── لوپ ───────────────────────────────────────────────────
    async def _promo_loop(self):
        await asyncio.sleep(30)
        self._promo_last = time.monotonic()
        while True:
            try:
                cfg = self._promo_cfg()
                due = time.monotonic() - self._promo_last >= cfg["minutes"] * 60
                if cfg["enabled"] and due and self._php_ready() and not getattr(self, "_bot_silent", False):
                    self._promo_last = time.monotonic()
                    await self._promo_send()
                elif due and not cfg["enabled"]:
                    self._promo_last = time.monotonic()
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.debug(f"لوپ تبلیغ رادیو: {exc}")
            await asyncio.sleep(5)
