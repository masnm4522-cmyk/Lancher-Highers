package ir.botclient

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bot", Context.MODE_PRIVATE)
    fun wantRunning(c: Context) = sp(c).getBoolean("want", false)
    fun setWantRunning(c: Context, v: Boolean) = sp(c).edit().putBoolean("want", v).commit()
    fun get(c: Context, k: String) = sp(c).getString(k, "") ?: ""
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).commit()
}
