package ir.botclient

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.PasswordTransformationMethod
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import org.json.JSONObject
import java.io.RandomAccessFile

class MainActivity : AppCompatActivity() {
    private val GOLD = Color.parseColor("#FF2E93")
    private val GOLD_DARK = Color.parseColor("#B0125F")
    private val GOLD_SOFT = Color.parseColor("#FFD1E8")
    private val GRAY = Color.parseColor("#8A8A8A")
    private val GREEN = Color.parseColor("#4ADE80")
    private val RED = Color.parseColor("#EF4444")

    private lateinit var pill: TextView
    private lateinit var mainBtn: TextView
    private lateinit var batteryLink: TextView
    private lateinit var logView: TextView
    private lateinit var fToken: EditText
    private lateinit var fRoom: EditText
    private lateinit var fOwner: EditText
    private var tokenShown = false
    private lateinit var outfitBox: LinearLayout
    private var outfitStamp = -1L
    private val ui = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1500) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int = 0, radius: Int = 14, strokeDp: Int = 1) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(strokeDp), stroke)
        }

    private fun grad(c1: Int, c2: Int, radius: Int = 16) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
            cornerRadius = dp(radius).toFloat()
        }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(GOLD); gravity = Gravity.START
        setPadding(dp(4), dp(10), dp(4), dp(4))
    }

    private fun input(hint: String, key: String) = EditText(this).apply {
        this.hint = hint; setText(Prefs.get(this@MainActivity, key)); setSingleLine()
        setTextColor(GOLD_SOFT); setHintTextColor(Color.parseColor("#6B6B6B")); textSize = 14f
        background = box(Color.parseColor("#1A1A1A"), Color.parseColor("#5A1A3A"), 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        textDirection = View.TEXT_DIRECTION_LTR
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(28), dp(20), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#050505"), Color.parseColor("#1A0510"), Color.parseColor("#000000"))
            )
        }

        // logo
        root.addView(TextView(this).apply {
            text = "V"; textSize = 34f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(GOLD, GOLD_DARK)).apply { cornerRadius = dp(20).toFloat() }
        }, LinearLayout.LayoutParams(dp(72), dp(72)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        root.addView(TextView(this).apply {
            text = getString(R.string.app_title); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(GOLD); letterSpacing = 0.15f; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(2))
        })
        root.addView(TextView(this).apply {
            text = "لانچر ربات هایرایز 🎀"; textSize = 13f; setTextColor(GRAY); gravity = Gravity.CENTER
        })

        pill = TextView(this).apply {
            textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(16), dp(6), dp(16), dp(6))
        }
        root.addView(pill, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(14); bottomMargin = dp(14) })

        // card
        fRoom = input("آیدی روم", "mroom")
        fToken = input("توکن ربات", "mtoken").apply { transformationMethod = PasswordTransformationMethod.getInstance() }
        fOwner = input("یوزرنیم شما در هایرایز", "mowner")
        val showToken = TextView(this).apply {
            text = "👁 نمایش توکن"; textSize = 12f; setTextColor(GOLD_DARK); gravity = Gravity.START
            setPadding(dp(4), dp(6), dp(4), 0)
            setOnClickListener {
                tokenShown = !tokenShown
                fToken.transformationMethod = if (tokenShown) null else PasswordTransformationMethod.getInstance()
            }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0F0F0F"), Color.parseColor("#C2185B"), 20, 2)
            setPadding(dp(16), dp(8), dp(16), dp(18))
        }
        card.addView(label("آیدی روم (Room ID)  🏠")); card.addView(fRoom)
        card.addView(label("توکن ربات  🔑")); card.addView(fToken); card.addView(showToken)
        card.addView(label("یوزرنیم شما در هایرایز (مالک)  👑")); card.addView(fOwner)
        root.addView(card)

        // start / stop
        mainBtn = TextView(this).apply {
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(0, dp(15), 0, dp(15))
            setOnClickListener { onMainButton() }
        }
        root.addView(mainBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        batteryLink = TextView(this).apply {
            textSize = 12f; setTextColor(GOLD); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
        root.addView(batteryLink)

        // ست‌های لباس (کپی‌شده از توی بازی با !copy @user)
        val outfitCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0F0F0F"), Color.parseColor("#C2185B"), 20, 2)
            setPadding(dp(16), dp(8), dp(16), dp(14))
        }
        outfitCard.addView(label("ست‌های لباس  👗"))
        outfitBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outfitCard.addView(outfitBox)
        root.addView(outfitCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        // log panel
        val logCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.parseColor("#0A0A0A"), Color.parseColor("#5A1A3A"), 16)
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }
        logCard.addView(TextView(this).apply {
            text = "LOG  ●●●"; textSize = 11f; setTextColor(GOLD); gravity = Gravity.END
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        })
        logView = TextView(this).apply {
            textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(GOLD_SOFT)
            layoutDirection = View.LAYOUT_DIRECTION_LTR; textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true); setPadding(0, dp(8), 0, 0)
        }
        logCard.addView(logView)
        root.addView(logCard)

        fun outline(t: String, color: Int, action: () -> Unit) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(color); gravity = Gravity.CENTER
            background = box(Color.TRANSPARENT, color, 14)
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { action() }
        }
        root.addView(outline("📋 کپی لاگ", GOLD) { copyLog() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(outline("🗑 پاک کردن همه بات‌ها و اطلاعات", RED) { confirmWipe() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); isFillViewport = true; addView(root) })
    }

    override fun onResume() { super.onResume(); ui.post(poll) }
    override fun onPause() { ui.removeCallbacks(poll); super.onPause() }

    private fun onMainButton() {
        if (Prefs.wantRunning(this)) {
            stopEverything()
        } else {
            val t = fToken.text.toString().trim(); val r = fRoom.text.toString().trim(); val o = fOwner.text.toString().trim()
            if (t.isEmpty() || r.isEmpty() || o.isEmpty()) {
                Toast.makeText(this, "همه فیلدها رو پر کن", Toast.LENGTH_SHORT).show(); return
            }
            Prefs.set(this, "mtoken", t); Prefs.set(this, "mroom", r); Prefs.set(this, "mowner", o)
            File(Paths.botDir(this), "manager.log").delete()
            Prefs.setWantRunning(this, true)
            ensurePermissions()
            startForegroundService(Intent(this, ManagerService::class.java)
                .putExtra("t", t).putExtra("r", r).putExtra("o", o))
        }
        refresh()
    }

    private fun stopEverything() {
        Prefs.setWantRunning(this, false)
        SlotLauncher.stopAll(this)
        stopService(Intent(this, ManagerService::class.java))
    }

    private fun confirmWipe() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setMessage("همه بات‌ها، تنظیمات، امتیازها و لاگ‌ها پاک میشن. مطمئنی؟")
            .setPositiveButton("پاک کن") { _, _ ->
                stopEverything(); Paths.botDir(this).deleteRecursively(); refresh()
            }
            .setNegativeButton("نه", null).show()
    }

    private fun tail(f: File, bytes: Int = 16000): String {
        if (!f.exists()) return ""
        return try {
            RandomAccessFile(f, "r").use { r ->
                val len = r.length()
                val start = maxOf(0L, len - bytes)
                r.seek(start)
                val buf = ByteArray((len - start).toInt())
                r.readFully(buf)
                val s = String(buf, Charsets.UTF_8)
                if (start > 0) s.substringAfter('\n', s) else s
            }
        } catch (e: Exception) { "" }
    }

    private fun logLines(n: Int) =
        tail(File(Paths.botDir(this), "manager.log")).lines().filter { it.isNotBlank() }.takeLast(n)

    private fun copyLog() {
        val text = logLines(200).joinToString("\n")
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("log", text))
        Toast.makeText(this, "لاگ کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun setsFile() = File(Paths.botDir(this), "outfit_sets.json")

    private fun readSets(): JSONObject =
        try { if (setsFile().exists()) JSONObject(setsFile().readText()) else JSONObject() }
        catch (e: Exception) { JSONObject() }

    private fun refreshOutfits() {
        val f = setsFile()
        val stamp = if (f.exists()) f.lastModified() + f.length() else 0L
        if (stamp == outfitStamp) return
        outfitStamp = stamp
        outfitBox.removeAllViews()
        val sets = readSets()
        val names = ArrayList<String>()
        val it = sets.keys()
        while (it.hasNext()) names.add(it.next())
        if (names.isEmpty()) {
            outfitBox.addView(TextView(this).apply {
                text = "هنوز ستی ذخیره نشده.\nتوی بازی بنویس: !copy @username"
                textSize = 12f; setTextColor(GRAY); setPadding(dp(4), dp(6), dp(4), dp(4))
            })
            return
        }
        for (name in names) {
            val count = sets.optJSONObject(name)?.optJSONArray("items")?.length() ?: 0
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(TextView(this).apply {
                text = "$name  ($count)"; textSize = 14f; setTextColor(GOLD_SOFT)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = "👗 بپوش"; textSize = 12f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
                background = grad(GOLD, GOLD_DARK, 12); setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { wearSet(name) }
            })
            row.addView(TextView(this).apply {
                text = "🗑"; textSize = 14f; setTextColor(RED); gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(6), dp(8))
                setOnClickListener { confirmDeleteSet(name) }
            })
            outfitBox.addView(row)
        }
    }

    private fun wearSet(name: String) {
        try {
            File(Paths.botDir(this), "pending_outfit.json")
                .writeText(JSONObject().put("set", name).toString())
            Toast.makeText(this, "درخواست پوشیدن «$name» ارسال شد (بات باید آنلاین باشه)", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا: $e", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDeleteSet(name: String) {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setMessage("ست «$name» پاک بشه؟")
            .setPositiveButton("پاک کن") { _, _ ->
                val sets = readSets(); sets.remove(name)
                try { setsFile().writeText(sets.toString()) } catch (_: Exception) {}
                outfitStamp = -1L; refreshOutfits()
            }
            .setNegativeButton("نه", null).show()
    }

    private fun refresh() {
        refreshOutfits()
        val running = Prefs.wantRunning(this)
        val lines = logLines(30)
        val tailText = lines.joinToString("\n")

        // status pill
        val (txt, color) = if (!running) "آفلاین" to GRAY else {
            val on = tailText.lastIndexOf("آنلاین شد")
            val conn = tailText.lastIndexOf("در حال اتصال")
            val err = tailText.lastIndexOf("خطای واقعی")
            val last = maxOf(on, conn, err)
            when {
                last < 0 -> "در حال راه‌اندازی..." to GOLD
                last == on -> "آنلاین توی روم" to GREEN
                last == err -> "قطع شد، اتصال مجدد..." to RED
                else -> "در حال اتصال..." to GOLD
            }
        }
        pill.text = "●  $txt"; pill.setTextColor(color)
        pill.background = box(Color.parseColor("#0F0F0F"), color, 20)

        // main button
        if (running) {
            mainBtn.text = "■  توقف ربات"; mainBtn.setTextColor(Color.WHITE)
            mainBtn.background = grad(Color.parseColor("#B3261E"), Color.parseColor("#E05555"))
        } else {
            mainBtn.text = "استارت  ▶"; mainBtn.setTextColor(Color.BLACK)
            mainBtn.background = grad(GOLD, GOLD_DARK)
        }

        val ign = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        batteryLink.text = if (ign) "🔋 محدودیت باتری برداشته شده ✔" else "🔋 غیرفعال کردن محدودیت باتری (برای روشن موندن)"

        // log text with colors
        val sb = SpannableStringBuilder()
        if (lines.isEmpty()) sb.append("> waiting...")
        for (l in lines) {
            val start = sb.length
            sb.append(l).append('\n')
            val c = when {
                l.contains("ERROR") || l.contains("Error") || l.contains("Traceback") || l.contains("❌") || l.contains("خطا") -> RED
                l.contains("✅") || l.contains("آنلاین") || l.contains("👑") -> GREEN
                else -> GOLD_SOFT
            }
            sb.setSpan(ForegroundColorSpan(c), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (logView.text.toString() != sb.toString()) logView.text = sb
    }

    private fun ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}
