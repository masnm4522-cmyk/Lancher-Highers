package ir.botclient

import android.content.Intent
import com.chaquo.python.Python
import java.io.File

abstract class BotSlotService(private val slot: Int) : BaseService(10 + slot, "Highrise Bot #${slot + 1}") {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dir = Paths.botDir(this)
        if (!File(dir, "slots/slot$slot.json").exists()) { stopSelf(); return START_NOT_STICKY }
        if (worker?.isAlive != true) {
            Paths.installAssets(this)
            worker = Thread({
                try {
                    Python.getInstance().getModule("glue").callAttr("run_bot", dir.absolutePath, slot)
                } catch (e: Throwable) { android.util.Log.e("BotClient", "bot slot $slot crashed", e) }
            }, "bot-py-$slot").also { it.start() }
        }
        return START_STICKY
    }
}

class Slot0 : BotSlotService(0)
class Slot1 : BotSlotService(1)
class Slot2 : BotSlotService(2)
class Slot3 : BotSlotService(3)
class Slot4 : BotSlotService(4)
class Slot5 : BotSlotService(5)
