"""
سیستم راهنمای یکپارچه.

همه‌ی دستورات ربات از یک فایل متنی (commands.txt) خونده می‌شن و با
!help یا !exthelp یک‌جا (نه صفحه‌به‌صفحه) نمایش داده می‌شن. برای ویرایش
راهنما فقط کافیه commands.txt رو عوض کنی، نیازی به دست‌زدن به کد نیست.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
COMMANDS_FILE = os.path.join(BASE_DIR, "commands.txt")

_PAGE_MARKER = "===PAGE "
_PAGE_END = "===\n"


class HelpSystemMixin:

    def _load_help_pages(self):
        cached = getattr(self, "_help_pages_cache", None)
        if cached is not None:
            return cached

        pages = {}
        try:
            with open(COMMANDS_FILE, "r", encoding="utf-8") as f:
                content = f.read()
            blocks = content.split(_PAGE_MARKER)
            for block in blocks[1:]:
                header, sep, body = block.partition(_PAGE_END)
                if not sep:
                    continue
                page_id = header.strip()
                pages[page_id] = body.strip()
        except FileNotFoundError:
            pages = {}
        except Exception:
            pages = {}

        self._help_pages_cache = pages
        return pages

    async def _send_help_text(self, text: str):
        # پیام‌های چت هایرایز محدودیت طول دارن، پس تیکه‌تیکه می‌فرستیم
        # (این فقط یه محدودیت فنیه؛ برای کاربر یک راهنمای یکپارچه‌ست)
        for chunk in [text[i:i + 300] for i in range(0, len(text), 300)]:
            await self.highrise.chat(chunk)

    async def _cmd_help_unified(self, user, message: str):
        pages = self._load_help_pages()
        text = pages.get("all")
        if not text:
            await self.highrise.chat(
                "❌ فایل راهنما (commands.txt) پیدا نشد یا خالیه."
            )
            return
        await self._send_help_text(text)
