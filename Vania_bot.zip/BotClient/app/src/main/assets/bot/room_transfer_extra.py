"""
سیستم جابه‌جایی کل روم به یک روم دیگه.

⚠️ فقط مالک بات (OWNER_USERNAME) اجازه‌ی اجرای این دستورها رو داره —
نه ادمین‌ها، نه ناظرها، نه بازیکن‌های عادی. چون این کار همه‌ی افراد
حاضر در روم رو (بدون رضایت جداگانه‌ی هرکس) به یک روم دیگه می‌فرسته،
یه قابلیت حساسه و باید محدود به مالک بمونه.

از متد رسمی SDK به اسم:
    self.highrise.move_user_to_room(user_id, room_id)
استفاده می‌کنیم. خود بات جابه‌جا نمی‌شه (چون اتصال بات به همین روم
وصله و جابه‌جا کردنش یعنی قطع شدن بات)، فقط کاربرها منتقل می‌شن.

دستورها:
  !roomtp <room_id>              -> همه رو با شناسه‌ی خام روم منتقل می‌کنه
  !roomtp <room_id> @user        -> فقط یک نفر رو منتقل می‌کنه

  !move <لینک روم> all           -> همه رو با لینک کامل روم منتقل می‌کنه
  !move <لینک روم> <عدد>         -> فقط همون تعداد نفر اول رو منتقل می‌کنه
  !move <لینک روم> @user         -> فقط یک نفر رو منتقل می‌کنه
  (به‌جای لینک هم می‌شه مستقیم room_id داد، هردو کار می‌کنه)
"""

import re
from asyncio import sleep
from highrise import User

_ROOM_LINK_RE = re.compile(r"room/([A-Za-z0-9_-]+)")


class RoomTransferMixin:

    def _is_owner(self, user: User) -> bool:
        return user.username.lower() == getattr(self, "OWNER", "")

    def _extract_room_id(self, text: str) -> str:
        """از لینک کامل روم (یا حتی خودِ room_id خام) شناسه رو استخراج می‌کنه."""
        text = text.strip()
        if "highrise.game" in text or "/room/" in text:
            match = _ROOM_LINK_RE.search(text)
            if match:
                return match.group(1)
            # fallback: آخرین قسمت مسیر لینک
            segment = text.rstrip("/").split("/")[-1]
            return segment.split("?")[0]
        return text  # خودِ room_id خام بوده

    async def _move_users(self, room_id: str, usernames):
        moved, failed = 0, 0
        for username in usernames:
            target_user = self.active_users.get(username)
            if not target_user or target_user.id == getattr(self, "user_id", None):
                continue
            try:
                await self.highrise.move_user_to_room(target_user.id, room_id)
                moved += 1
                await sleep(0.3)
            except Exception:
                failed += 1
        return moved, failed

    # ── !roomtp (شناسه‌ی خام) ─────────────────────────────────────

    async def _cmd_roomtp(self, user: User, message: str):
        if not self._is_owner(user):
            await self.highrise.chat(
                "❌ این دستور فقط برای مالک باته؛ نه ادمین، نه ناظر، نه بازیکن."
            )
            return

        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.chat(
                "فرمت: !roomtp <room_id>  یا  !roomtp <room_id> @یوزرنیم\n"
                "بدون @یوزرنیم، همه‌ی افراد حاضر در روم منتقل می‌شن.\n"
                "اگه لینک کامل روم رو داری، به‌جاش از !move استفاده کن."
            )
            return

        target_room_id = self._extract_room_id(parts[1])

        if len(parts) >= 3 and parts[2].startswith("@"):
            usernames = [parts[2][1:].lower()]
        else:
            usernames = list(self.active_users.keys())
            await self.highrise.chat(
                f"🚪 مالک روم داره همه رو به روم دیگه می‌بره... ({len(usernames)} نفر)"
            )

        moved, failed = await self._move_users(target_room_id, usernames)
        summary = f"✅ {moved} نفر منتقل شدن."
        if failed:
            summary += f" ({failed} نفر ناموفق)"
        await self.highrise.chat(summary)

    # ── !move (لینک کامل روم، تعداد یا all یا @user) ───────────────

    async def _cmd_move(self, user: User, message: str):
        if not self._is_owner(user):
            await self.highrise.chat(
                "❌ این دستور فقط برای مالک باته؛ نه ادمین، نه ناظر، نه بازیکن."
            )
            return

        parts = message.strip().split()
        if len(parts) < 3:
            await self.highrise.chat(
                "فرمت:\n"
                "!move <لینک روم> all → انتقال همه\n"
                "!move <لینک روم> <عدد> → انتقال همون تعداد نفر اول\n"
                "!move <لینک روم> @یوزرنیم → انتقال یک نفر"
            )
            return

        target_room_id = self._extract_room_id(parts[1])
        selector = parts[2]

        all_usernames = [
            uname for uname, u in self.active_users.items()
            if u.id != getattr(self, "user_id", None)
        ]

        if selector.lower() == "all":
            usernames = all_usernames
        elif selector.startswith("@"):
            usernames = [selector[1:].lower()]
        elif selector.isdigit():
            count = max(1, int(selector))
            usernames = all_usernames[:count]
        else:
            await self.highrise.chat(
                "❌ بعد از لینک باید بنویسی: all یا یه عدد یا @یوزرنیم"
            )
            return

        if not usernames:
            await self.highrise.chat("❌ کسی برای انتقال پیدا نشد.")
            return

        await self.highrise.chat(
            f"🚪 در حال انتقال {len(usernames)} نفر به روم جدید..."
        )
        moved, failed = await self._move_users(target_room_id, usernames)
        summary = f"✅ {moved} نفر منتقل شدن."
        if failed:
            summary += f" ({failed} نفر ناموفق)"
        await self.highrise.chat(summary)
