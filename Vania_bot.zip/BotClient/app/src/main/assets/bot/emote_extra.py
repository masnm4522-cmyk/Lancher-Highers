"""
سیستم !emote برای اجرای مداوم ایموت روی پلیر از طریق لینک high.rs

دستورها:
  !emote https://high.rs/item?id=sit-idle-cute&type=emote
      → ایموت رو مداوم روی همون کاربر اجرا می‌کنه تا وقتی stop بزنه

  stop
      → لوپ ایموت اون کاربر رو قطع می‌کنه

این فایل کاملاً مستقله — هیچ تغییری در serve2.py یا لیست دنس‌های موجود نمیده.
"""

from urllib.parse import urlparse, parse_qs
from asyncio import create_task, sleep, CancelledError
from highrise import User


class EmoteExtraMixin:

    def _get_emote_url_tasks(self) -> dict:
        """
        دیکشنری تسک‌های لوپ ایموت به ازای هر کاربر {user_id: Task}.
        عمداً به‌صورت attribute نمونه (نه attribute کلاس) لازی ساخته می‌شه؛
        وگرنه اگه یه‌روز دو تا نمونه از این کلاس تو یه پروسه بسازیم، هر دو
        یه دیکشنری مشترک رو دستکاری می‌کردن.
        """
        if not hasattr(self, "_emote_url_tasks_store"):
            self._emote_url_tasks_store = {}
        return self._emote_url_tasks_store

    @property
    def _emote_url_tasks(self) -> dict:
        return self._get_emote_url_tasks()

    def _parse_highrs_emote_url(self, text: str):
        """
        از متن پیام لینک high.rs رو پیدا می‌کنه و emote id رو برمی‌گردونه.
        فقط لینک‌هایی که type=emote دارن معتبرن.
        """
        for word in text.split():
            try:
                parsed = urlparse(word)
                if parsed.netloc in ("high.rs", "www.high.rs") and parsed.path == "/item":
                    params = parse_qs(parsed.query)
                    emote_id = params.get("id", [None])[0]
                    item_type = params.get("type", [""])[0]
                    if emote_id and item_type == "emote":
                        return emote_id
            except Exception:
                continue
        return None

    async def _emote_loop(self, user_id: str, emote_id: str):
        """لوپ بی‌نهایت ایموت روی پلیر — تا وقتی کنسل نشه ادامه میده."""
        try:
            while True:
                try:
                    await self.highrise.send_emote(emote_id, user_id)
                    # مدت زمان ایموت رو از دیکشنری والد می‌خونیم، پیش‌فرض ۹ ثانیه
                    duration = getattr(self, "emote_durations", {}).get(emote_id, 9.0)
                    await sleep(duration)
                except CancelledError:
                    raise
                except Exception:
                    await sleep(5)
        except CancelledError:
            pass  # کنسل شد، بی‌سروصدا خارج می‌شیم

    async def on_chat(self, user: User, message: str):
        msg = message.strip()
        msg_lower = msg.lower()

        # ── دستور !emote <لینک> ──────────────────────────────────────
        if msg_lower.startswith("!emote "):
            emote_id = self._parse_highrs_emote_url(msg)
            if emote_id:
                # اگه لوپ قبلی برای این کاربر داریم، کنسلش می‌کنیم
                old_task = self._emote_url_tasks.get(user.id)
                if old_task and not old_task.done():
                    old_task.cancel()

                # اگه رقصِ عددی (1 تا 261) هم روی این کاربر در حال اجراست،
                # اونم متوقف کن تا دو تا رقص همزمان قاطی نشن
                if hasattr(self, "stop_dance"):
                    await self.stop_dance(user)

                # لوپ جدید شروع می‌کنیم
                self._emote_url_tasks[user.id] = create_task(
                    self._emote_loop(user.id, emote_id)
                )

                # 💃 اعلام رقص: فقط اسم ایموت (بدون آیدی اکانت)
                try:
                    await self.highrise.chat(f"💃 @{user.username} شروع کرد به رقصیدن: {emote_id}")
                except Exception:
                    pass
            return  # چه لینک معتبر باشه چه نباشه، پردازش همینجا تموم میشه

        # ── دستور stop ──────────────────────────────────────────────
        if msg_lower == "stop":
            task = self._emote_url_tasks.get(user.id)
            if task and not task.done():
                task.cancel()
                self._emote_url_tasks.pop(user.id, None)
            # بعد از stop، اجازه میدیم بقیه هندلرها هم چک کنن
            # (مثلاً اگه serve2.py هم stop رو مدیریت می‌کنه)
            await super().on_chat(user, message)
            return

        # ── بقیه پیام‌ها به هندلر اصلی پاس میشن ──────────────────
        await super().on_chat(user, message)
