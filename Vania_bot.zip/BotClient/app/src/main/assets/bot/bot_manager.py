import asyncio
import logging
import os
import re
import subprocess
import sys
import traceback
from asyncio import sleep
from typing import Dict
from persistent_store import load_json, save_json
import feature_flags

from highrise import BaseBot, User
from highrise.__main__ import BotDefinition

logger = logging.getLogger(__name__)

OWNER_USERNAME = os.getenv("OWNER_USERNAME", "").lower()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOT_REGISTRY_FILE = os.path.join(BASE_DIR, "bot_registry.json")
MANAGER_OWNER_FILE = os.path.join(BASE_DIR, "manager_owner.json")


class ManagedBot:
    def __init__(self, name, token, room_id, owner_username="", role="normal"):
        self.name = name
        self.token = token
        self.room_id = room_id
        self.owner_username = owner_username
        self.role = role
        self.proc = None
        self.log_file = None

    def start(self):
        if self.is_alive():
            return
        env = os.environ.copy()
        env["API_TOKEN"] = self.token
        env["ROOM_ID"] = self.room_id
        env["BOT_NAME"] = self.name
        env["BOT_ROLE"] = self.role
        if self.owner_username:
            env["OWNER_USERNAME"] = self.owner_username

        # پیش از اولین اجرا، تنظیمات این بات جدید رو «ساکت» می‌کنیم — بدون
        # پیام خوش‌آمد (نه پیام خصوصی، نه پیام تو چت روم) و بدون پیام‌های
        # لوپ خودکار — تا خودت هر چی خواستی بعداً دستی با !welcomeon /
        # !loopon اضافه کنی.
        ext_config_path = os.path.join(BASE_DIR, f"ext_config_{self.name}.json")
        if not os.path.exists(ext_config_path):
            save_json(ext_config_path, {
                "welcome_dm": False,
                "welcome_dm_enabled": False,
                "loop_enabled": False,
            })
        bot_config_path = os.path.join(BASE_DIR, f"bot_config_{self.name}.json")
        if not os.path.exists(bot_config_path):
            save_json(bot_config_path, {"welcome_enabled": False})

        import android_bridge
        android_bridge.start_slot(self.name, self.token, self.room_id, self.owner_username, self.role)
        logger.info(f"🚀 بات {self.name} ({self.role}) برای روم {self.room_id} اجرا شد.")

    def is_alive(self):
        import android_bridge
        return android_bridge.is_alive(self.name)

    def stop(self):
        import android_bridge
        android_bridge.stop_slot(self.name)


class BotManager(BaseBot):
    def __init__(self):
        super().__init__()
        self.bots: Dict[str, ManagedBot] = self._load_bots()
        self._watchdog_task = None
        # per-owner conversation state for the step-by-step !newbot wizard
        # { user_id: {"step": "username"|"token"|"room"|"owner", "data": {...}} }
        self.pending: Dict[str, dict] = {}
        # resolved once we see the owner in the room, so we can recognize
        # them in inbox DMs (on_message only gives us a user_id, no username)
        self.owner_id: str | None = None
        # مالک فعلی ربات‌ساز — از فایل ذخیره‌شده می‌خونیم (اگه قبلاً با
        # !transferowner عوض شده باشه)، وگرنه از OWNER_USERNAME تو start.sh
        saved_owner = load_json(MANAGER_OWNER_FILE, {})
        self.owner_username = (
            str(saved_owner.get("owner_username", "")).strip().lower()
            if isinstance(saved_owner, dict) and saved_owner.get("owner_username")
            else OWNER_USERNAME
        )
        # بات‌های قدیمی ممکن است قبل از ذخیره‌ی owner_username ساخته شده
        # باشند؛ مالک فعلی ربات‌ساز را برای آن‌ها هم به‌عنوان مالک پیش‌فرض
        # اعمال می‌کنیم تا در extended_serve2.py ادمین شناخته شود.
        if self.owner_username:
            changed = False
            for bot in self.bots.values():
                if not bot.owner_username:
                    bot.owner_username = self.owner_username
                    changed = True
            if changed:
                self._save_bots()
        # conversation_id -> user_id, so on_message can tell whose DM it is
        self.conversation_owners: Dict[str, str] = {}
        # conversation_id -> last processed message_id, to avoid re-running
        # a command if on_message fires again for the same message
        self.last_seen_message: Dict[str, str] = {}

    def _load_bots(self) -> Dict[str, ManagedBot]:
        saved = load_json(BOT_REGISTRY_FILE, {})
        if not isinstance(saved, dict):
            saved = {}
        bots: Dict[str, ManagedBot] = {}
        for name, data in saved.items():
            if not isinstance(data, dict):
                continue
            token = str(data.get("token", "")).strip()
            room_id = str(data.get("room_id", "")).strip()
            owner_username = str(data.get("owner_username", "")).strip()
            role = str(data.get("role", "normal")).strip().lower() or "normal"
            if token and room_id:
                bots[str(name)] = ManagedBot(
                    str(name), token, room_id, owner_username, role
                )
        # One-time migration for installations that used start_direct.sh
        # before the persistent registry existed. Once the registry is
        # created, an intentional !stopall stays intentional.
        if not os.path.exists(BOT_REGISTRY_FILE):
            direct_script = os.path.join(BASE_DIR, "start_direct.sh")
            try:
                script = open(direct_script, "r", encoding="utf-8").read()
                token_match = re.search(r'export API_TOKEN="([^"]+)"', script)
                room_match = re.search(r'export ROOM_ID="([^"]+)"', script)
                name_match = re.search(r'export BOT_NAME="([^"]+)"', script)
                if token_match and room_match:
                    name = name_match.group(1) if name_match else "Masazo"
                    bots[name] = ManagedBot(
                        name, token_match.group(1), room_match.group(1), "", "normal"
                    )
                    logger.info("📦 بات مستقیم (start_direct.sh) به bot_registry.json منتقل شد.")
            except (OSError, UnicodeError) as exc:
                logger.warning(f"⚠️ نشد بات مستقیم منتقل بشه: {exc}")
        return bots

    def _save_bots(self) -> None:
        save_json(
            BOT_REGISTRY_FILE,
            {
                name: {
                    "token": bot.token,
                    "room_id": bot.room_id,
                    "owner_username": bot.owner_username,
                    "role": bot.role,
                }
                for name, bot in self.bots.items()
            },
        )

    async def on_start(self, session_metadata):
        logger.info("🤖 ربات‌ساز آنلاین شد؛ در حال بازیابی بات‌های ثبت‌شده...")
        self._save_bots()
        # Give the manager connection a moment to settle, then restore every
        # saved bot together. This keeps the restart experience predictable.
        asyncio.create_task(self._restore_saved_bots())
        self._watchdog_task = asyncio.create_task(self._watchdog())
        await self._resolve_owner_id()

    async def _restore_saved_bots(self):
        await sleep(5)
        for name, bot in list(self.bots.items()):
            try:
                bot.start()
                logger.info(f"✅ بات {name} بعد از ۵ ثانیه از دیسک بازیابی شد.")
            except Exception as exc:
                logger.error(f"❌ نشد بات {name} بازیابی بشه: {exc}")

    async def _watchdog(self):
        while True:
            await sleep(5)
            for name, bot in list(self.bots.items()):
                if not bot.is_alive():
                    logger.warning(f"⚠️ بات {name} کرش کرد — در حال ری‌استارت...")
                    try:
                        bot.start()
                    except Exception as e:
                        logger.error(f"❌ خطا در ری‌استارت {name}: {e}")
            if not self.owner_id:
                await self._resolve_owner_id()

    async def _resolve_owner_id(self):
        try:
            resp = await self.highrise.get_room_users()
            for user, _pos in getattr(resp, "content", []):
                if user.username.lower() == self.owner_username:
                    self.owner_id = user.id
                    logger.info(f"👑 مالک شناسایی شد: {user.username} ({user.id})")
                    return
        except Exception as e:
            logger.error(f"❌ نشد آیدی مالک پیدا بشه: {e}")

    async def on_user_join(self, user: User, position=None):
        if user.username.lower() == self.owner_username:
            self.owner_id = user.id

    async def on_chat(self, user: User, message: str):
        if not feature_flags.BOT_MAKER_ENABLED:
            return  # ربات‌ساز از داخل بازی غیرفعاله
        # Public room chat is ignored on purpose. Everything happens over
        # inbox DM so bot tokens never show up in the room chat log.
        if user.username.lower() != self.owner_username:
            return
        self.owner_id = user.id
        await self.highrise.send_whisper(
            user.id, "💬 دستورات رو اینجا نفرست، از پیام خصوصی (چت شخصی) پروفایلم برام بفرست."
        )

    async def on_whisper(self, user: User, message: str):
        if not feature_flags.BOT_MAKER_ENABLED:
            return  # ربات‌ساز از داخل بازی غیرفعاله
        if user.username.lower() != self.owner_username:
            return
        self.owner_id = user.id
        await self._handle_command(user.id, message, reply=lambda text: self.highrise.send_whisper(user.id, text))

    async def on_message(self, user_id: str, conversation_id: str, is_new_conversation: bool):
        if not feature_flags.BOT_MAKER_ENABLED:
            return  # ربات‌ساز از داخل بازی غیرفعاله
        # Real private-message inbox (the "چت شخصی" from the bot's profile),
        # separate from in-room whispers.
        if not self.owner_id:
            await self._resolve_owner_id()
        # Fail closed: if we still don't know who the owner is, refuse
        # every DM instead of trusting whoever messages first.
        if self.owner_id is None or user_id != self.owner_id:
            try:
                await self.highrise.send_message(
                    conversation_id,
                    f"🤖 این بات مدیریت @{self.owner_username} هستش.\n"
                    f"🙏 لطفاً دیگه به این بات پیام ندید."
                )
            except Exception:
                pass
            return

        self.conversation_owners[conversation_id] = user_id

        try:
            resp = await self.highrise.get_messages(conversation_id)
        except Exception as e:
            logger.error(f"get_messages failed: {e}")
            return

        messages = getattr(resp, "messages", None)
        if not messages:
            return
        last = messages[0]  # most recent message first
        if last.sender_id != user_id:
            return  # last message is our own reply, nothing new to do
        if self.last_seen_message.get(conversation_id) == last.message_id:
            return  # already handled this exact message, avoid re-running it
        self.last_seen_message[conversation_id] = last.message_id

        async def reply(text: str):
            await self.highrise.send_message(conversation_id, text)

        await self._handle_command(user_id, last.content, reply=reply)

    async def _handle_command(self, uid: str, message: str, reply):
        text = message.strip()

        # If we're in the middle of the !newbot wizard, treat this message
        # as the answer to the current step instead of a command.
        if uid in self.pending:
            await self._handle_wizard_step(uid, text, reply)
            return

        parts = text.split()
        if not parts:
            return
        cmd = parts[0].lower()

        if cmd == "!newbotmusic":
            music_exists = any(
                bot.role == "music" or name.casefold() == "musicbot"
                for name, bot in self.bots.items()
            )
            if music_exists:
                await reply("🎧 فقط یک بات موزیک اجازه دارد؛ بات موزیک قبلاً ساخته شده است.")
                return
            self.pending[uid] = {
                "step": "token",
                "kind": "music",
                "data": {"name": "MusicBot"},
            }
            await reply(
                "🎧 ساخت بات موزیک شروع شد.\n"
                "🔑 اول توکن (API token) بات موزیک را بفرست.\n"
                "این بات فقط رادیو و جابه‌جایی را دارد؛ دنس آزاد ندارد و فقط ادمین با !floss فلوس می‌زند."
            )

        elif cmd == "!newbot":
            self.pending[uid] = {"step": "username", "data": {}}
            await reply("🤖 بسازیم! اول یه اسم برای بات جدید بفرست (فقط برای شناسایی، دلخواهه).")

        elif cmd == "!cancel":
            if uid in self.pending:
                del self.pending[uid]
            await reply("❌ لغو شد.")

        elif cmd == "!listbots":
            if not self.bots:
                await reply("📭 هیچ باتی ثبت نشده.\nبرای ساختن بات جدید بزن: !newbot")
                return
            lines = ["🤖 فهرست بات‌های ثبت‌شده:"]
            for i, (name, bot) in enumerate(self.bots.items(), 1):
                status = "🟢 روشن" if bot.is_alive() else "🔴 خاموش"
                kind = "🎧 موزیک" if bot.role == "music" else "🤖 معمولی"
                lines.append(f"{i}. {status} — {name} ({kind}، روم: {bot.room_id})")
            await reply("\n".join(lines))

        elif cmd == "!stopbot":
            if len(parts) < 2:
                await reply("فرمت: !stopbot <شماره>\nشماره رو از !listbots ببین.")
                return
            try:
                idx = int(parts[1]) - 1
                name = list(self.bots.keys())[idx]
                self.bots[name].stop()
                del self.bots[name]
                self._save_bots()
                await reply(f"🛑 بات «{name}» خاموش شد.")
            except (IndexError, ValueError):
                await reply("❌ شماره‌ی نامعتبر. اول !listbots بزن.")

        elif cmd == "!stopall":
            for bot in self.bots.values():
                bot.stop()
            self.bots.clear()
            self._save_bots()
            await reply("🛑 همه‌ی بات‌ها خاموش شدن.")

        elif cmd == "!restartbot":
            if len(parts) < 2:
                await reply("فرمت: !restartbot <شماره>\nشماره رو از !listbots ببین.")
                return
            try:
                idx = int(parts[1]) - 1
                name = list(self.bots.keys())[idx]
                self.bots[name].stop()
                await sleep(2)
                self.bots[name].start()
                self._save_bots()
                await reply(f"🔄 بات «{name}» ری‌استارت شد.")
            except (IndexError, ValueError):
                await reply("❌ شماره‌ی نامعتبر. اول !listbots بزن.")

        elif cmd == "!transferowner":
            if len(parts) < 2:
                await reply("فرمت: !transferowner <یوزرنیم اکانت جدید>")
                return
            new_owner = parts[1].lstrip("@").strip().lower()
            self.owner_username = new_owner
            self.owner_id = None  # دفعه‌ی بعد که پیام بده، دوباره شناسایی می‌شه
            save_json(MANAGER_OWNER_FILE, {"owner_username": new_owner})

            # مالکیت هر بات ساخته‌شده رو هم منتقل می‌کنیم: هم owner_username
            # خودش عوض می‌شه، هم به لیست ادمین‌های همون بات اضافه می‌شه. چون
            # OWNER فقط موقع روشن‌شدن بات از env خونده می‌شه، برای اینکه واقعاً
            # اعمال بشه لازمه بات‌ها ری‌استارت بشن.
            updated = 0
            for name, bot in self.bots.items():
                bot.owner_username = new_owner
                bot_config_path = os.path.join(BASE_DIR, f"bot_config_{name}.json")
                try:
                    data = load_json(bot_config_path, {})
                    if not isinstance(data, dict):
                        data = {}
                    admins = data.get("admin_usernames", [])
                    if new_owner not in admins:
                        admins.append(new_owner)
                    data["admin_usernames"] = admins
                    save_json(bot_config_path, data)
                except Exception as e:
                    logger.error(f"خطا در به‌روزرسانی کانفیگ {name}: {e}")
                    continue
                try:
                    bot.stop()
                    await sleep(1)
                    bot.start()
                    updated += 1
                except Exception as e:
                    logger.error(f"خطا در ری‌استارت {name}: {e}")
            self._save_bots()

            await reply(
                f"👑 مالکیت ربات‌ساز به @{new_owner} منتقل شد.\n"
                f"✅ از این به بعد فقط این اکانت می‌تونه دستور بده.\n"
                f"🔄 {updated} بات هم به‌روز و ری‌استارت شد تا @{new_owner} توی "
                f"روم‌ها هم مالک/ادمین باشه."
            )

        elif cmd == "!help":
            await reply(
                "✨═══════════════════════✨\n"
                "   🤖 راهنمای ربات‌ساز (فقط پیام خصوصی)\n"
                "✨═══════════════════════✨\n"
                "▸ !newbot → ساخت بات جدید، مرحله‌به‌مرحله می‌پرسه\n"
                "▸ !newbotmusic → ساخت فقط یک بات اختصاصی کنترل رادیو\n"
                "▸ !listbots → 📋 فهرست همه‌ی بات‌ها و وضعیتشون\n"
                "▸ !stopbot <شماره> → 🛑 خاموش‌کردن یک بات\n"
                "▸ !restartbot <شماره> → 🔄 ری‌استارت یک بات\n"
                "▸ !stopall → 🛑 خاموش‌کردن همه‌ی بات‌ها\n"
                "▸ !transferowner <یوزرنیم> → 👑 انتقال مالکیت ربات‌ساز\n"
                "▸ !cancel → ❌ لغو ساخت بات (وسط !newbot)\n"
                "✨═══════════════════════✨"
            )

    async def _handle_wizard_step(self, uid: str, text: str, reply):
        state = self.pending[uid]
        step = state["step"]
        data = state["data"]
        kind = state.get("kind", "normal")

        if text.lower() == "!cancel":
            del self.pending[uid]
            await reply("❌ لغو شد.")
            return

        if step == "username":
            data["name"] = text
            state["step"] = "token"
            await reply("🔑 خب حالا توکن (API token) بات رو بفرست.")

        elif step == "token":
            data["token"] = text
            state["step"] = "room"
            await reply("🚪 عالی، حالا آیدی روم (room id) رو بفرست.")

        elif step == "room":
            data["room_id"] = text
            state["step"] = "owner"
            await reply("👑 با چه آیدی (یوزرنیم) این بات مالک داشته باشه؟")

        elif step == "owner":
            data["owner"] = text.lstrip("@").strip()
            del self.pending[uid]

            if kind == "music":
                if any(
                    bot.role == "music" or existing.casefold() == "musicbot"
                    for existing, bot in self.bots.items()
                ):
                    await reply("🎧 بات موزیک قبلاً ساخته شده و فقط یکی از آن مجاز است.")
                    return
                name = "MusicBot"
            else:
                # sanitize to safe filename characters only (used for the log
                # file name), so a crafted name can't write outside the folder
                safe = re.sub(r"[^A-Za-z0-9_-]", "_", data["name"]).strip("_")
                name = safe or f"bot{len(self.bots) + 1}"
                if name in self.bots:
                    name = f"{name}_{len(self.bots) + 1}"

            bot = ManagedBot(
                name, data["token"], data["room_id"], data["owner"], kind
            )
            try:
                bot.start()
                self.bots[name] = bot
                self._save_bots()
                if kind == "music":
                    await reply(
                        f"✅ بات موزیک «{name}» توی روم {data['room_id']} روشن شد. 🎧\n"
                        f"📻 کنترل رادیو، جابه‌جایی بات و دنس اختصاصی !floss آماده است.\n"
                        f"👑 مالکش @{data['owner']} تنظیم شد."
                    )
                else:
                    await reply(
                        f"✅ بات «{name}» توی روم {data['room_id']} روشن شد. 🎉\n"
                        f"👑 مالکش @{data['owner']} تنظیم شد."
                    )
            except Exception as e:
                await reply(f"❌ خطا: {e}")


async def main():
    token = os.getenv("MANAGER_TOKEN", "")
    room_id = os.getenv("MANAGER_ROOM", "")
    if not token or not room_id or not OWNER_USERNAME:
        print("❌ خطا: مقدارهای MANAGER_TOKEN، MANAGER_ROOM و OWNER_USERNAME رو توی start.sh تنظیم کن.")
        input("برای خروج Enter بزن...")
        return

    from net_wait import wait_for_network
    logger.info("🌐 چک اینترنت...")
    bot_def = BotDefinition(room_id=room_id, api_token=token, bot=BotManager())
    attempt = 0
    while True:
        await wait_for_network()
        try:
            logger.info(f"🔌 در حال اتصال... تلاش شماره {attempt+1}")
            from highrise.__main__ import main as highrise_main
            await highrise_main([bot_def])
            attempt = 0
        except BaseException as e:
            attempt += 1
            # اگه ExceptionGroup بود (quattro TaskGroup) خطای داخلی رو نشون بده
            if hasattr(e, 'exceptions'):
                for inner in e.exceptions:
                    logger.error(f"=== خطای واقعی: {type(inner).__name__}: {inner} ===")
                    logger.error(traceback.format_exc())
            else:
                logger.error(f"=== خطای واقعی: {type(e).__name__}: {e} ===")
                logger.error(traceback.format_exc())
            logger.error("⏳ ۱ ثانیه دیگه دوباره تلاش می‌کنیم...")
            await sleep(1)


if __name__ == "__main__":
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler("manager.log", encoding="utf-8"),
            logging.StreamHandler()
        ]
    )
    asyncio.run(main())
