import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from serve2 import AdvancedBot as _BaseBot
from teleport_extra import TeleportExtraMixin
from emote_extra import EmoteExtraMixin
from friend_dances import apply_friend_dances
from tental_systems import TentalSystemsMixin
from mod_extra import ModExtraMixin
from help_system import HelpSystemMixin
from room_transfer_extra import RoomTransferMixin
from security_extra import SecurityExtraMixin
from archive_extra import ArchiveExtraMixin
from highrise import User, Position
from highrise.__main__ import BotDefinition
from asyncio import sleep, create_task, CancelledError
from datetime import datetime
import json
import logging
import random
import aiohttp
import time
import re
from persistent_store import load_json, save_json

logger = logging.getLogger(__name__)

# Unique per bot process (BOT_NAME is set by bot_manager.py). Without this,
# every child bot shared the same ext_config.json and could read back a
# different bot's saved room_id/api_token, causing it to connect to the
# wrong room.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXT_CONFIG_FILE = os.path.join(
    BASE_DIR, f"ext_config_{os.getenv('BOT_NAME', 'default')}.json"
)
EXT_DEFAULT_CONFIG = {
    "bot_home": None,
    "floors": {},
    "loop_messages": [
        "سلام عزیزم برای زدن دنس 1 تا 222 تایپ کن 😊",
        "برای راهنما !help بزنید 🔥"
    ],
    "loop_interval": 300,
    "loop_enabled": True,
    "bot_silent": False,
    "welcome_dm": True,
    "welcome_dm_message": "سلام {username} عزیز! 🌸 خوش اومدی. برای دیدن دستورات !help بزن.",
    "vip_temp_list": {},
    "warn_records": {},
    "banned_users": [],
    "welcome_dm_enabled": True,
    "welcome_dm_message": "سلام {username} عزیز! 🌸 خوش اومدی. برای دیدن دستورات !help بزن.",
    "tp_enabled": True,
    "banned_songs": [],
    "security_enabled": True,
    "raidguard_enabled": True,
    "room_peak": 0,
    "archive_events": [],
    "radio_stream_url": "",
    "radio_control_token": "",
    "radio_control_port": 8000,
    "music_playlist_index": -1,
    "runtime_state": {
        "lottery_active": False,
        "lottery_participants": [],
        "lottery_prize": "",
        "quiz_active": False,
        "quiz_answer": "",
        "quiz_asked_by": "",
        "visitors_today": {},
        "radio": {
            "tracks": {},
            "queue": [],
            "current": None,
            "playing": False,
            "votes": {},
            "favorites": {},
            "credits": {},
            "daily_claims": {}
        }
    }
}


class ExtendedBot(TentalSystemsMixin, EmoteExtraMixin, TeleportExtraMixin, ModExtraMixin, HelpSystemMixin, RoomTransferMixin, SecurityExtraMixin, ArchiveExtraMixin, _BaseBot):

    def __init__(self):
        super().__init__()
        apply_friend_dances(self)  # دنس‌های دوستت جایگزین دنس‌های عددی
        self._tental_init()  # سیستم ادمین و لباس به سبک تنتا
        self._music_bot = os.getenv("BOT_ROLE", "").strip().lower() == "music"
        # مالک اختصاصی که ربات‌ساز هنگام ساخت هر بات در OWNER_USERNAME می‌گذارد
        # باید برای همان بات ادمین باشد؛ وگرنه بات جدید قابل تنظیم نیست.
        owner = os.getenv("OWNER_USERNAME", "").strip().lower()
        if owner:
            admins = self.config.setdefault("admin_usernames", [])
            if owner not in admins:
                admins.append(owner)
                self.save_config()
        self.ext_config = self._load_ext_config()
        self.bot_home_position = None
        self.bot_home_task = None
        self.loop_task = None
        self._loop_index = 0
        self._bot_silent = self.ext_config.get("bot_silent", False)
        self._lottery_active = False
        self._lottery_participants = []
        self._lottery_prize = ""
        self._quiz_active = False
        self._quiz_answer = ""
        self._quiz_asked_by = ""
        self._countdown_task = None
        self._tempvip_tasks = {}
        runtime = self.ext_config.get("runtime_state", {})
        self._lottery_active = bool(runtime.get("lottery_active", False))
        self._lottery_participants = list(runtime.get("lottery_participants", []))
        self._lottery_prize = str(runtime.get("lottery_prize", ""))
        self._quiz_active = bool(runtime.get("quiz_active", False))
        self._quiz_answer = str(runtime.get("quiz_answer", ""))
        self._quiz_asked_by = str(runtime.get("quiz_asked_by", ""))
        self._visitors_today = {
            str(day): set(names)
            for day, names in runtime.get("visitors_today", {}).items()
            if isinstance(names, list)
        }
        radio = runtime.get("radio", {})
        self._radio_tracks = dict(radio.get("tracks", {}))
        self._radio_queue = list(radio.get("queue", []))
        self._radio_current = radio.get("current")
        self._radio_playing = bool(radio.get("playing", False))
        self._radio_votes = dict(radio.get("votes", {}))
        self._radio_favorites = {
            str(username): list(track_ids)
            for username, track_ids in radio.get("favorites", {}).items()
        }
        self._radio_credits = {
            str(username): int(amount)
            for username, amount in radio.get("credits", {}).items()
            if isinstance(amount, (int, float))
        }
        self._radio_daily_claims = dict(radio.get("daily_claims", {}))
        self._radio_search_results = {}
        self._radio_last_finish_seq = None
        self._radio_announce_task = None
        self._bot_dance_task = None
        self._bot_dance_emote = None
        self._ext_commands = {
            "!bot": self._cmd_bot,
            "!botfree": self._cmd_botfree,
            "!sethome": self._cmd_sethome,
            "!home": self._cmd_home,
            "!delhome": self._cmd_delhome,
            "!setfloor": self._cmd_setfloor,
            "!setfloorvip": self._cmd_setfloorvip,
            "!delfloor": self._cmd_delfloor,
            "!floors": self._cmd_floors,
            "!tele": self._cmd_tele_extra,
            "!summ": self._cmd_summ,
            "!setloop": self._cmd_setloop,
            "!loopon": self._cmd_loopon,
            "!loopoff": self._cmd_loopoff,
            "!pos": self._cmd_pos,
            "!lottery": self._cmd_lottery,
            "!join": self._cmd_join,
            "!quiz": self._cmd_quiz,
            "!report": self._cmd_report,
            "!tempvip": self._cmd_tempvip,
            "!untempvip": self._cmd_untempvip,
            "!visitors": self._cmd_visitors,
            "!botoff": self._cmd_botoff,
            "!boton": self._cmd_boton,
            "!countdown": self._cmd_countdown,
            "!top": self._cmd_top,
            "!dm": self._cmd_dm,
            "!exthelp": self._cmd_help_unified,
            "!botdance": self._cmd_botdance,
            "!dancereset": self._cmd_dancereset,
            "!reset": self._cmd_reset,
            "!setroom": self._cmd_setroom,
            "!roominfo": self._cmd_roominfo,
            "!warn": self._cmd_warn,
            "!warns": self._cmd_warns,
            "!clearwarn": self._cmd_clearwarn,
            "!schedule": self._cmd_schedule,
            "!stats": self._cmd_stats,
            "!alldance": self._cmd_alldance,
            "!setwelcome": self._cmd_setwelcome,
            "!welcomeon": self._cmd_welcomeon,
            "!welcomeoff": self._cmd_welcomeoff,
            "!help": self._cmd_help_unified,
            "!restart": self._cmd_restart,
            "!settoken": self._cmd_settoken,
            "!radio": self._cmd_radio,
            "!music": self._cmd_radio,
            "!song": self._cmd_radio,
            "!m": self._cmd_radio,
            "!p": self._cmd_radio,
            "!q": self._cmd_radio,
            "!n": self._cmd_radio,
            "!next": self._cmd_radio,
            "!del": self._cmd_radio,
            "!up": self._cmd_radio,
            "!promote": self._cmd_radio,
            "!vote": self._cmd_radio,
            "!effects": self._cmd_radio,
            "!e": self._cmd_radio,
            "!emote-list": self._cmd_radio,
            "!mod-list": self._cmd_mod_list_full,
            "!mod": self._cmd_mod,
            "!unmod": self._cmd_unmod,
            "!mute": self._cmd_mute,
            "!unmute": self._cmd_unmute,
            "!kick": self._cmd_kick,
            "!double": self._cmd_double,
            "!punch": self._cmd_punch,
            "!clown": self._cmd_clown,
            "!jail": self._cmd_jail,
            "!unjail": self._cmd_unjail,
            "!vip-args": self._cmd_vip_args,
            "!vip-list": self._cmd_vip_list,
            "!come": self._cmd_come,
            "!tp": self._cmd_tp_toggle,
            "!ban-music": self._cmd_ban_music,
            "!unban-music": self._cmd_unban_music,
            "!setstreamurl": self._cmd_setstreamurl,
            "!streamlink": self._cmd_streamlink,
            "!musiclist": self._cmd_musiclist,
            "!play": self._cmd_play,
            "!prev": self._cmd_prevsong,
            "!previous": self._cmd_prevsong,
            "!roomtp": self._cmd_roomtp,
            "!move": self._cmd_move,
            "!modlog": self._cmd_modlog,
            "!security": self._cmd_security_toggle,
            "!raidguard": self._cmd_raidguard_toggle,
            "!muted": self._cmd_muted_list,
            "!memories": self._cmd_memories,
            "!fav": self._cmd_radio,
            "!fav-list": self._cmd_radio,
            "!fav-play": self._cmd_radio,
            "!credit": self._cmd_radio,
            "!daily": self._cmd_radio,
            "!rsearch": self._cmd_radio,
            "!musicsearch": self._cmd_radio,
            "!searchmusic": self._cmd_radio,
            "!radiosearch": self._cmd_radio,
            "!pick": self._cmd_radio,
        }
        if self._music_bot:
            # بات موزیک فقط رادیو و ابزارهای جابه‌جایی خودش را نگه می‌دارد؛
            # دستورات دنس، بازی، افکت و مدیریت عمومی عمداً در آن فعال نیستند.
            music_commands = {
                "!bot", "!botfree", "!sethome", "!home", "!delhome",
                "!setfloor", "!setfloorvip", "!delfloor", "!floors",
                "!pos", "!come",
                "!radio", "!music", "!song", "!m", "!p", "!q", "!n",
                "!next", "!del", "!up", "!promote", "!vote",
                "!fav", "!fav-list", "!fav-play", "!credit", "!daily",
                "!rsearch", "!musicsearch", "!searchmusic", "!radiosearch",
                "!pick", "!setstreamurl", "!streamlink", "!musiclist",
                "!play", "!prev", "!previous",
            }
            self._ext_commands = {
                name: handler
                for name, handler in self._ext_commands.items()
                if name in music_commands
            }
            self._ext_commands.update({
                "!help": self._cmd_music_help,
                "!exthelp": self._cmd_music_help,
                "!floss": self._cmd_floss,
                "!فلوس": self._cmd_floss,
            })

    # ─── کانفیگ اضافی ──────────────────────────────────────────────

    def _load_ext_config(self):
        default_config = json.loads(json.dumps(EXT_DEFAULT_CONFIG))
        data = load_json(EXT_CONFIG_FILE, {})
        if not isinstance(data, dict):
            data = {}
        merged = default_config
        merged.update(data)
        merged.setdefault("runtime_state", default_config["runtime_state"])
        if not os.path.exists(EXT_CONFIG_FILE):
            # Runtime fields are initialized just below, so write the
            # initial config directly instead of calling _save_ext_config().
            save_json(EXT_CONFIG_FILE, merged)
        return merged

    def _save_ext_config(self):
        try:
            runtime_state = {
                "lottery_active": self._lottery_active,
                "lottery_participants": self._lottery_participants,
                "lottery_prize": self._lottery_prize,
                "quiz_active": self._quiz_active,
                "quiz_answer": self._quiz_answer,
                "quiz_asked_by": self._quiz_asked_by,
                "visitors_today": {
                    day: sorted(names)
                    for day, names in self._visitors_today.items()
                },
                "radio": {
                    "tracks": self._radio_tracks,
                    "queue": self._radio_queue,
                    "current": self._radio_current,
                    "playing": self._radio_playing,
                    "votes": self._radio_votes,
                    "favorites": self._radio_favorites,
                    "credits": self._radio_credits,
                    "daily_claims": self._radio_daily_claims,
                },
            }
            self.ext_config["runtime_state"] = runtime_state
            save_json(EXT_CONFIG_FILE, self.ext_config)
        except Exception as e:
            logger.error(f"خطا در ذخیره ext_config: {e}")

    def _is_admin(self, user: User) -> bool:
        return user.username.lower() in self.config.get("admin_usernames", [])

    async def _cmd_music_help(self, user: User, message: str):
        await self.highrise.chat(
            "╭──── 🎧 بات موزیک ────╮\n"
            "│ !radio — وضعیت و راهنما\n"
            "│ !radio search نام آهنگ — جستجو\n"
            "│ !radio pick 1 — پخش نتیجه\n"
            "│ !q R001 — افزودن به صف | !n — بعدی\n"
            "│ !radio pause — مکث | !radio stop — توقف\n"
            "│ !streamlink — لینک رادیوی زنده\n"
            "│ !come — آوردن بات پیش ادمین\n"
            "│ !bot here — جابه‌جایی و ذخیره جای بات\n"
            "│ !sethome / !home — تعیین و برگشت به خانه\n"
            "│ !floss — فقط دنس فلوس بات\n"
            "╰────────────────────╯"
        )

    async def _cmd_floss(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("⛔ فقط مالک/ادمین بات موزیک می‌تونه دنس فلوس اجرا کنه.")
            return
        if not self.user_id:
            await self.highrise.chat("❌ شناسه بات هنوز آماده نیست.")
            return
        try:
            await self.highrise.send_emote("dance-floss", self.user_id)
            await self.highrise.chat("🕺 دنس فلوس اجرا شد.")
        except Exception as exc:
            logger.error(f"خطا در اجرای دنس فلوس بات موزیک: {exc}")
            await self.highrise.chat("❌ اجرای دنس فلوس ناموفق بود.")

    # ─── on_start ──────────────────────────────────────────────────

    async def on_start(self, session_metadata):
        await super().on_start(session_metadata)
        # والد یک لوپ اعلان قدیمی و یک دنس پیش‌فرض راه می‌اندازد.
        # این نسخه فقط لوپ‌های خودش را نگه می‌دارد تا دو سیستم روی هم نیفتند.
        if self.base_loop_task and not self.base_loop_task.done():
            self.base_loop_task.cancel()
            self.base_loop_task = None

        # لغو دنس پیش‌فرض والد. بات موزیک فقط با !floss یک‌بار فلوس می‌زند
        # و نباید از ابتدا وارد لوپ دنس شود.
        if self.user_id and self.user_id in self.dance_tasks:
            self.dance_tasks[self.user_id].cancel()
        if self._music_bot:
            self._bot_dance_emote = None
        else:
            saved_dance = self.ext_config.get("bot_dance_emote", "dance-floss")
            if isinstance(saved_dance, str):
                linked_emote = self._parse_highrs_emote_url(saved_dance)
                if linked_emote:
                    saved_dance = linked_emote
            self._bot_dance_emote = saved_dance

        saved = self.ext_config.get("bot_home")
        if saved:
            self.bot_home_position = Position(x=saved["x"], y=saved["y"], z=saved["z"])
            # فقط یک‌بار بعد از اتصال برگرد؛ تلپورت دوره‌ای وسط دنس باعث
            # پرش، فریز ظاهری و نصفه‌ماندن انیمیشن می‌شد.
            try:
                await self.highrise.teleport(
                    user_id=self.user_id,
                    dest=self.bot_home_position,
                )
                logger.info(f"بات در شروع به موقعیت ذخیره‌شده برگشت: {saved}")
            except Exception as e:
                logger.error(f"خطا در برگشت اولیه به خانه بات: {e}")

        if self._bot_dance_emote:
            self._bot_dance_task = create_task(self._bot_dance_loop())

        self._tental_on_start()

        if self.ext_config.get("loop_enabled", True):
            self.loop_task = create_task(self._announcement_loop_ext())

        if self._music_bot:
            self._radio_announce_task = create_task(
                self._radio_finish_announcement_loop()
            )

        # 🤖 اعلام آنلاین‌شدن بات توی چت روم
        try:
            if self._music_bot:
                await self.highrise.chat(
                    "🎧 بات موزیک آنلاین شد و رادیو آماده‌ست! ✨\n"
                    "برای راهنمای رادیو !radio help بزن."
                )
            else:
                await self.highrise.chat(
                    "🤖 بات آنلاین شد و آماده‌ست! ✨\n"
                    "برای دیدن دستورات !help بزن."
                )
        except Exception:
            pass

    def _radio_server_settings(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        settings_path = os.path.join(base_dir, "radio_server_config.json")
        settings = load_json(settings_path, {})
        if not isinstance(settings, dict):
            settings = {}
        try:
            port = int(settings.get("port", self.ext_config.get("radio_control_port", 8000)))
        except (TypeError, ValueError):
            port = 8000
        token = str(settings.get("control_token", "")).strip()
        if not token:
            bot_name = os.getenv("BOT_NAME", "Vania")
            cfg_path = os.path.join(base_dir, f"ext_config_{bot_name}.json")
            fresh_cfg = load_json(cfg_path, {})
            if isinstance(fresh_cfg, dict):
                token = str(fresh_cfg.get("radio_control_token", "")).strip()
        public_url = str(settings.get("public_url", "")).strip()
        return port, token, public_url

    async def _radio_finish_announcement_loop(self):
        await sleep(8)
        while True:
            try:
                port, token, _public_url = self._radio_server_settings()
                if token:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(
                            f"http://127.0.0.1:{port}/status",
                            timeout=aiohttp.ClientTimeout(total=5),
                        ) as response:
                            if response.status == 200:
                                status = await response.json()
                                seq = status.get("finished_seq")
                                if seq is not None:
                                    if self._radio_last_finish_seq is None:
                                        self._radio_last_finish_seq = seq
                                    elif seq != self._radio_last_finish_seq:
                                        self._radio_last_finish_seq = seq
                                        finished = status.get("finished_title") or "آهنگ قبلی"
                                        next_title = (
                                            status.get("now_playing_title")
                                            or status.get("next_title")
                                            or "آهنگ بعدی"
                                        )
                                        duration = status.get("finished_duration_seconds")
                                        next_duration = status.get("next_duration_seconds")
                                        duration_text = (
                                            f" ({int(duration)} ثانیه)"
                                            if isinstance(duration, (int, float))
                                            else ""
                                        )
                                        next_duration_text = (
                                            f" — زمان: {int(next_duration)} ثانیه"
                                            if isinstance(next_duration, (int, float))
                                            else ""
                                        )
                                        await self.highrise.chat(
                                            f"✅ آهنگ «{finished}» تمام شد{duration_text}.\n"
                                            f"▶️ میرم سراغ آهنگ بعدی: «{next_title}»{next_duration_text}"
                                        )
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.debug(f"رادیو فعلاً قابل دسترسی نیست: {exc}")
            await sleep(3)

    # ─── on_user_join ───────────────────────────────────────────────

    async def on_user_join(self, user: User, position: Position):
        await super().on_user_join(user, position)
        today = datetime.now().strftime("%Y-%m-%d")
        self._visitors_today.setdefault(today, set()).add(user.username)
        self._save_ext_config()
        if hasattr(self, "_check_room_record"):
            await self._check_room_record()

        is_staff = self._is_admin(user) or (hasattr(self, "_is_mod") and self._is_mod(user))
        if is_staff:
            role = "👑 مالک/ادمین" if self._is_admin(user) else "🛡 ناظر"
            try:
                await self.highrise.chat(f"{role} @{user.username} وارد روم شد! خوش اومدی 🌟")
            except Exception:
                pass
        elif self.ext_config.get("welcome_dm", True):
            try:
                dm_text = self.ext_config.get(
                    "welcome_dm_message",
                    "سلام {username} عزیز! خوش اومدی 🌸"
                ).replace("{username}", user.username)
                await self.highrise.send_message(
                    conversation_id="",
                    content=dm_text,
                    type="text",
                )
            except Exception as e:
                logger.error(f"خطا در ارسال DM خوش‌آمد به {user.username}: {e}")

    # ─── on_chat ───────────────────────────────────────────────────

    async def on_chat(self, user: User, message: str):
        if self._bot_silent:
            pass

        # کاربر ساکت‌شده (!mute) رو تا وقتی سکوتش تموم نشده نادیده می‌گیریم
        # (به‌جز خود دستورهای !unmute/!mute که ادمین/ناظر می‌زنه، اونا از
        # طرف کاربر ساکت‌شده نمیان چون فقط ادمین/ناظر اجازه‌ی زدنشون رو داره)
        if self.is_muted(user.username.lower()):
            return

        # سیستم ادمین و لباس تنتا (قبل از بقیه‌ی دستورها)
        if await self._tental_on_chat(user, message):
            return

        # آنتی‌اسپم خودکار: اگه پیام زیادی توی بازه‌ی کوتاه فرستاده بشه،
        # قبل از پردازش دستور یا چت، کاربر خودکار میوت می‌شه
        if await self._check_spam(user, message):
            return

        if await self._check_room_poaching(user, message):
            return

        msg = message.strip()
        msg_lower = msg.lower()

        cmd = msg_lower.split()[0] if msg_lower.startswith("!") else None
        if cmd and cmd in self._ext_commands:
            await self._ext_commands[cmd](user, msg)
            return

        if self._quiz_active and msg_lower == self._quiz_answer.lower():
            self._quiz_active = False
            pts = self.user_scores.get(user.username.lower(), 0) + 50
            self.user_scores[user.username.lower()] = pts
            self._quiz_answer = ""
            self._quiz_asked_by = ""
            self.save_memory()
            self._save_ext_config()
            await self.highrise.chat(
                f"🎉 @{user.username} جواب درست داد! +50 امتیاز\n"
                f"جواب درست ثبت شد."
            )
            return

        if msg_lower in self.ext_config.get("floors", {}):
            floor = self.ext_config["floors"][msg_lower]
            if floor.get("vip") and not self._is_admin(user):
                await self.highrise.chat(
                    f"⛔ @{user.username} طبقه‌ی '{msg_lower}' فقط برای ادمینه، نمی‌تونی بری اونجا."
                )
                return
            dest = Position(x=floor["x"], y=floor["y"], z=floor["z"])
            try:
                await self.highrise.teleport(user_id=user.id, dest=dest)
            except Exception as e:
                await self.highrise.chat(f"❌ خطا در رفتن به طبقه: {e}")
            return

        # دنس هدف‌دار برای همه‌ی کاربران: 222@username
        if self._music_bot:
            return
        if await self._handle_targeted_dance(user, msg):
            return

        await super().on_chat(user, message)

    # ══════════════════════════════════════════════════════════════
    # سیستم دنس بات 💃
    # ══════════════════════════════════════════════════════════════

    async def _bot_dance_loop(self):
        try:
            while True:
                if self._bot_dance_emote and self.user_id:
                    try:
                        duration = self.emote_durations.get(self._bot_dance_emote, 9.0)
                        await self.highrise.send_emote(self._bot_dance_emote, self.user_id)
                        # کمی حاشیه می‌دهیم تا درخواست بعدی، انیمیشن قبلی را
                        # قبل از تمام شدن قطع نکند.
                        await sleep(max(float(duration), 0.5) + 0.2)
                    except Exception as e:
                        logger.error(f"خطا در دنس بات: {e}")
                        await sleep(5)
                else:
                    await sleep(5)
        except CancelledError:
            logger.info("لوپ دنس بات لغو شد.")

    async def _handle_targeted_dance(self, user: User, message: str) -> bool:
        """پردازش فرم عمومی 222@username (و 222 @username)."""
        text = message.strip()
        if not text or text.startswith("!"):
            return False

        dance_key = None
        target_names = []

        # فرم کوتاه: 222@x11q یا 222@x11q@friend
        compact = re.fullmatch(r"([0-9۰-۹]+)((?:@[A-Za-z0-9_.-]+)+)", text)
        if compact:
            dance_key = compact.group(1)
            target_names = re.findall(r"@([A-Za-z0-9_.-]+)", compact.group(2))
        else:
            # فرم خواناتر: 222 @x11q @friend
            parts = text.split()
            if len(parts) >= 2 and re.fullmatch(r"[0-9۰-۹]+", parts[0]):
                mentions = []
                for part in parts[1:]:
                    if not re.fullmatch(r"@[A-Za-z0-9_.-]+", part):
                        mentions = []
                        break
                    mentions.append(part[1:])
                if mentions:
                    dance_key = parts[0]
                    target_names = mentions

        if not dance_key or not target_names:
            return False

        emote = self._resolve_emote(dance_key)
        if not emote:
            await self.highrise.chat(f"❌ دنس شماره {dance_key} پیدا نشد.")
            return True

        started = []
        missing = []
        seen = set()
        for target_name in target_names:
            target_key = target_name.lower()
            if target_key in seen:
                continue
            seen.add(target_key)
            target_user = self.active_users.get(target_key)
            if not target_user:
                missing.append(target_name)
                continue
            if target_user.id == self.user_id:
                missing.append(target_name)
                continue
            # start_dance خودش تسک مستقل می‌سازد؛ بنابراین همه‌ی هدف‌ها
            # بدون منتظر شدن برای تمام شدن دنس، تقریباً هم‌زمان شروع می‌شوند.
            await self.start_dance(target_user, emote)
            started.append(target_user.username)

        if started:
            text_started = "، ".join(f"@{name}" for name in started)
            response = f"💃 دنس {dance_key} برای {text_started} شروع شد."
            if missing:
                response += "\n⚠️ پیدا نشد: " + "، ".join(f"@{name}" for name in missing)
            await self.highrise.chat(response)
        else:
            await self.highrise.chat(
                "❌ هیچ‌کدام از کاربرهای گفته‌شده در روم نیستند. "
                "فرمت: 222@username"
            )
        return True

    def _resolve_emote(self, name_or_number: str):
        # لینک‌های high.rs مثل:
        # https://high.rs/item?id=dance-floss&type=emote
        linked_emote = self._parse_highrs_emote_url(name_or_number.strip())
        if linked_emote:
            return linked_emote
        key = name_or_number.lower()
        # اگه توی دیکشنری emotes باشه (شماره یا اسم مستعار)
        if key in self.emotes:
            return self.emotes[key]
        # اگه مستقیم اسم emote باشه
        if key in self.emote_durations:
            return key
        # اگه با پیشوندهای معمول شروع بشه
        for prefix in ("dance-", "emote-", "idle-", "idle_", "emoji-", "sit-"):
            if key.startswith(prefix):
                return key
        return None

    # ─── لوپ قفل موقعیت بات ───────────────────────────────────────

    async def _bot_home_loop(self):
        """سازگاری با تنظیمات قدیمی؛ عمداً دیگر تلپورت دوره‌ای انجام نمی‌دهد."""
        try:
            if self.bot_home_position and self.user_id:
                await self.highrise.teleport(
                    user_id=self.user_id,
                    dest=self.bot_home_position,
                )
        except CancelledError:
            logger.info("لوپ قفل موقعیت بات لغو شد.")
        except Exception as e:
            logger.error(f"خطا در برگشت یک‌باره‌ی بات به خانه: {e}")

    # ─── لوپ اعلان اضافی ──────────────────────────────────────────

    async def _announcement_loop_ext(self):
        try:
            first_message = True
            while True:
                interval = self.ext_config.get("loop_interval", 300)
                if not self.ext_config.get("loop_enabled", True):
                    await sleep(2)
                    continue
                if not first_message:
                    await sleep(max(float(interval), 5.0))
                first_message = False
                if self._bot_silent:
                    continue
                messages = self.ext_config.get("loop_messages", [])
                if messages:
                    msg = messages[self._loop_index % len(messages)]
                    self._loop_index += 1
                    try:
                        await self.highrise.chat(msg)
                    except Exception as e:
                        logger.error(f"خطا در ارسال پیام لوپ: {e}")
        except CancelledError:
            logger.info("لوپ اعلان اضافی لغو شد.")
        except Exception as e:
            logger.error(f"خطا در لوپ اعلان: {e}")

    # ══════════════════════════════════════════════════════════════
    # سیستم قفل موقعیت بات
    # ══════════════════════════════════════════════════════════════

    async def _cmd_bot(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split()
        try:
            dest = None
            if len(parts) == 2 and parts[1].lower() == "here":
                pos = self.user_positions.get(user.username.lower())
                if not pos:
                    await self.highrise.chat("❌ موقعیت شما پیدا نشد، یه کم حرکت کن.")
                    return
                dest = pos
            elif len(parts) == 4:
                dest = Position(x=float(parts[1]), y=float(parts[2]), z=float(parts[3]))
            else:
                await self.highrise.chat("فرمت: !bot here | !bot x y z")
                return
            await self.highrise.teleport(user_id=self.user_id, dest=dest)
            self.bot_home_position = dest
            self.ext_config["bot_home"] = {"x": dest.x, "y": dest.y, "z": dest.z}
            self._save_ext_config()
            if self.bot_home_task and not self.bot_home_task.done():
                self.bot_home_task.cancel()
            self.bot_home_task = None
            await self.highrise.chat(
                f"📍 جای بات ذخیره شد و همین‌جا می‌مونه! "
                f"x={round(dest.x,1)} y={round(dest.y,1)} z={round(dest.z,1)} | لغو: !botfree"
            )
        except ValueError:
            await self.highrise.chat("❌ مختصات باید عدد باشن!")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا: {e}")

    async def _cmd_botfree(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        self.bot_home_position = None
        self.ext_config["bot_home"] = None
        self._save_ext_config()
        if self.bot_home_task and not self.bot_home_task.done():
            self.bot_home_task.cancel()
            self.bot_home_task = None
        await self.highrise.chat("🔓 قفل موقعیت بات برداشته شد!")

    # ══════════════════════════════════════════════════════════════
    # سیستم خونه بات
    # ══════════════════════════════════════════════════════════════

    async def _cmd_sethome(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        pos = self.user_positions.get(user.username.lower())
        if not pos:
            await self.highrise.chat("❌ موقعیت شما پیدا نشد.")
            return
        self.ext_config["bot_home"] = {"x": pos.x, "y": pos.y, "z": pos.z}
        self.bot_home_position = pos
        self._save_ext_config()
        if self.bot_home_task and not self.bot_home_task.done():
            self.bot_home_task.cancel()
        self.bot_home_task = None
        await self.highrise.chat(
            f"🏠 خونه بات ذخیره شد! x={round(pos.x,1)} y={round(pos.y,1)} z={round(pos.z,1)}"
        )

    async def _cmd_home(self, user: User, message: str):
        saved = self.ext_config.get("bot_home")
        if not saved:
            await self.highrise.chat("❌ خونه‌ای ذخیره نشده. اول !sethome بزن.")
            return
        dest = Position(x=saved["x"], y=saved["y"], z=saved["z"])
        try:
            await self.highrise.teleport(user_id=self.user_id, dest=dest)
            await self.highrise.chat("🏠 بات به خونه برگشت!")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا: {e}")

    async def _cmd_delhome(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        self.ext_config["bot_home"] = None
        self.bot_home_position = None
        self._save_ext_config()
        if self.bot_home_task and not self.bot_home_task.done():
            self.bot_home_task.cancel()
            self.bot_home_task = None
        await self.highrise.chat("🗑 خونه بات پاک شد.")

    # ══════════════════════════════════════════════════════════════
    # سیستم طبقه
    # ══════════════════════════════════════════════════════════════

    async def _cmd_setfloor(self, user: User, message: str):
        await self._setfloor_common(user, message, is_vip=False)

    async def _cmd_setfloorvip(self, user: User, message: str):
        await self._setfloor_common(user, message, is_vip=True)

    async def _setfloor_common(self, user: User, message: str, is_vip: bool):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            cmd_name = "!setfloorvip" if is_vip else "!setfloor"
            await self.highrise.chat(f"فرمت: {cmd_name} اسم | {cmd_name} اسم x y z")
            return

        name = parts[1].lower()
        if len(parts) == 5:
            try:
                x, y, z = float(parts[2]), float(parts[3]), float(parts[4])
            except ValueError:
                await self.highrise.chat("❌ مختصات باید عدد باشن!")
                return
        else:
            pos = self.user_positions.get(user.username.lower())
            if not pos:
                await self.highrise.chat("❌ موقعیت شما پیدا نشد، یه کم حرکت کن.")
                return
            x, y, z = pos.x, pos.y, pos.z

        floor_data = {"x": x, "y": y, "z": z}
        if is_vip:
            floor_data["vip"] = True
        self.ext_config.setdefault("floors", {})[name] = floor_data
        self._save_ext_config()

        vip_note = "\n🔒 این طبقه VIP هست — فقط ادمین می‌تونه با تایپ اسمش بره اونجا." if is_vip else ""
        await self.highrise.chat(
            f"✅ طبقه '{name}' ذخیره شد!\n"
            f"x={round(x,1)} y={round(y,1)} z={round(z,1)}\n"
            f"کاربرا '{name}' رو تایپ کنن تا برن اونجا.{vip_note}"
        )

    async def _cmd_delfloor(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.chat("فرمت: !delfloor اسم")
            return
        name = parts[1].lower()
        floors = self.ext_config.get("floors", {})
        if name not in floors:
            await self.highrise.chat(f"❌ طبقه '{name}' وجود نداره.")
            return
        del floors[name]
        self._save_ext_config()
        await self.highrise.chat(f"🗑 طبقه '{name}' پاک شد.")

    async def _cmd_floors(self, user: User, message: str):
        floors = self.ext_config.get("floors", {})
        if not floors:
            await self.highrise.chat("هیچ طبقه‌ای ذخیره نشده.")
            return
        lines = ["📋 طبقه‌های موجود:"]
        for name, p in floors.items():
            tag = " 🔒(VIP)" if p.get("vip") else ""
            lines.append(f"• {name}{tag}")
        await self.highrise.chat("\n".join(lines))

    # ══════════════════════════════════════════════════════════════
    # سیستم لوپ اعلان
    # ══════════════════════════════════════════════════════════════

    async def _cmd_setloop(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split(maxsplit=2)
        if len(parts) < 2:
            await self.highrise.chat(
                "📢 دستورات لوپ:\n"
                "!setloop ثانیه متن — ساخت/تغییر لوپ جدا\n"
                "!setloop دقیقه — تنظیم بازه‌ی قدیمی\n"
                "!setloop add پیام — اضافه کردن پیام\n"
                "!setloop clear — پاک کردن همه\n"
                "!setloop status — وضعیت\n"
                "!loopon / !loopoff"
            )
            return
        sub = parts[1].lower()
        if sub == "status":
            msgs = self.ext_config.get("loop_messages", [])
            interval = self.ext_config.get("loop_interval", 300)
            enabled = self.ext_config.get("loop_enabled", True)
            await self.highrise.chat(
                f"📊 وضعیت لوپ:\n"
                f"{'فعال ✅' if enabled else 'غیرفعال ❌'}\n"
                f"بازه: {interval} ثانیه\n"
                f"تعداد پیام: {len(msgs)}"
            )
        elif sub == "clear":
            self.ext_config["loop_messages"] = []
            self._save_ext_config()
            await self.highrise.chat("🗑 همه پیام‌های لوپ پاک شدن.")
        elif sub == "add":
            if len(parts) < 3:
                await self.highrise.chat("پیام رو بنویس: !setloop add متن پیام")
                return
            self.ext_config.setdefault("loop_messages", []).append(parts[2])
            self.ext_config["loop_enabled"] = True
            self._save_ext_config()
            if not self.loop_task or self.loop_task.done():
                self.loop_task = create_task(self._announcement_loop_ext())
            await self.highrise.chat(f"✅ پیام اضافه شد. ({len(self.ext_config['loop_messages'])} پیام)")
        else:
            try:
                amount = float(parts[1])
                if amount < 1:
                    raise ValueError
                # حالت جدید: !setloop ثانیه متن
                # حالت قدیمیِ فقط عدد: !setloop دقیقه
                if len(parts) >= 3:
                    if amount < 5:
                        raise ValueError
                    self.ext_config["loop_interval"] = int(amount)
                    self.ext_config["loop_messages"] = [parts[2]]
                    self.ext_config["loop_enabled"] = True
                    if self.loop_task and not self.loop_task.done():
                        self.loop_task.cancel()
                    self.loop_task = create_task(self._announcement_loop_ext())
                    await self.highrise.chat(
                        f"✅ لوپ جدا فعال شد: هر {int(amount)} ثانیه\n"
                        f"متن: {parts[2]}"
                    )
                    return
                self.ext_config["loop_interval"] = int(amount * 60)
                self.ext_config["loop_enabled"] = True
                self._save_ext_config()
                if self.loop_task and not self.loop_task.done():
                    self.loop_task.cancel()
                self.loop_task = create_task(self._announcement_loop_ext())
                await self.highrise.chat(f"✅ بازه لوپ: {amount:g} دقیقه")
            except ValueError:
                await self.highrise.chat(
                    "❌ فرمت درست:\n"
                    "!setloop 10 متن پیام (هر ۱۰ ثانیه)\n"
                    "یا !setloop 2 (هر ۲ دقیقه)"
                )

    async def _cmd_loopon(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        self.ext_config["loop_enabled"] = True
        self._save_ext_config()
        if self.loop_task and not self.loop_task.done():
            self.loop_task.cancel()
        self.loop_task = create_task(self._announcement_loop_ext())
        await self.highrise.chat("✅ لوپ اعلان روشن شد.")

    async def _cmd_loopoff(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        self.ext_config["loop_enabled"] = False
        self._save_ext_config()
        if self.loop_task and not self.loop_task.done():
            self.loop_task.cancel()
            self.loop_task = None
        await self.highrise.chat("🔇 لوپ اعلان خاموش شد.")

    # ══════════════════════════════════════════════════════════════
    # سیستم موقعیت
    # ══════════════════════════════════════════════════════════════

    async def _cmd_pos(self, user: User, message: str):
        pos = self.user_positions.get(user.username.lower())
        if not pos:
            await self.highrise.chat("❌ موقعیت شما پیدا نشد.")
            return
        await self.highrise.chat(
            f"📍 @{user.username}\n"
            f"x={round(pos.x,2)} y={round(pos.y,2)} z={round(pos.z,2)}\n"
            f"برای ساخت طبقه: !setfloor اسم"
        )

    # ══════════════════════════════════════════════════════════════
    # سیستم لاتاری 🎰
    # !lottery start جایزه — شروع
    # !lottery end — قرعه‌کشی و اعلام برنده
    # !lottery cancel — لغو
    # !join — شرکت در لاتاری
    # ══════════════════════════════════════════════════════════════

    async def _cmd_lottery(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split(maxsplit=2)
        sub = parts[1].lower() if len(parts) > 1 else ""

        if sub == "start":
            if self._lottery_active:
                await self.highrise.chat("❌ یه لاتاری در جریانه! اول !lottery end یا !lottery cancel بزن.")
                return
            prize = parts[2] if len(parts) > 2 else "جایزه ویژه"
            self._lottery_active = True
            self._lottery_participants = []
            self._lottery_prize = prize
            self._save_ext_config()
            await self.highrise.chat(
                f"🎰 لاتاری شروع شد!\n"
                f"🎁 جایزه: {prize}\n"
                f"برای شرکت !join بزنید!"
            )

        elif sub == "end":
            if not self._lottery_active:
                await self.highrise.chat("❌ هیچ لاتاری فعالی نیست.")
                return
            self._lottery_active = False
            if not self._lottery_participants:
                self._save_ext_config()
                await self.highrise.chat("😔 هیچکس شرکت نکرد!")
                return
            winner = random.choice(self._lottery_participants)
            self.user_scores[winner.lower()] = self.user_scores.get(winner.lower(), 0) + 100
            self.save_memory()
            await self.highrise.chat(
                f"🎉 قرعه‌کشی انجام شد!\n"
                f"🏆 برنده: @{winner}\n"
                f"🎁 جایزه: {self._lottery_prize}\n"
                f"تعداد شرکت‌کننده: {len(self._lottery_participants)}"
            )
            self._lottery_participants = []
            self._save_ext_config()

        elif sub == "cancel":
            if not self._lottery_active:
                await self.highrise.chat("❌ هیچ لاتاری فعالی نیست.")
                return
            self._lottery_active = False
            self._lottery_participants = []
            self._save_ext_config()
            await self.highrise.chat("🚫 لاتاری لغو شد.")

        elif sub == "list":
            if not self._lottery_active:
                await self.highrise.chat("❌ هیچ لاتاری فعالی نیست.")
                return
            if not self._lottery_participants:
                await self.highrise.chat("هنوز کسی شرکت نکرده.")
                return
            await self.highrise.chat(
                f"👥 شرکت‌کنندگان ({len(self._lottery_participants)}):\n" +
                ", ".join(f"@{u}" for u in self._lottery_participants[:15])
            )
        else:
            await self.highrise.chat(
                "🎰 دستورات لاتاری:\n"
                "!lottery start جایزه\n"
                "!lottery end\n"
                "!lottery cancel\n"
                "!lottery list"
            )

    async def _cmd_join(self, user: User, message: str):
        if not self._lottery_active:
            await self.highrise.chat("❌ لاتاری فعالی نیست.")
            return
        if user.username in self._lottery_participants:
            await self.highrise.chat(f"❌ @{user.username} قبلاً شرکت کردی!")
            return
        self._lottery_participants.append(user.username)
        self._save_ext_config()
        await self.highrise.chat(
            f"✅ @{user.username} وارد لاتاری شد! ({len(self._lottery_participants)} نفر)"
        )

    # ══════════════════════════════════════════════════════════════
    # سیستم Quiz ❓
    # !quiz سوال | جواب — ادمین سوال می‌ذاره
    # هر کسی جواب درست بزنه +50 امتیاز می‌گیره
    # ══════════════════════════════════════════════════════════════

    async def _cmd_quiz(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه سوال بذاره.")
            return
        parts = message.strip().split("|", 1)
        if len(parts) < 2:
            if self._quiz_active:
                await self.highrise.chat(
                    f"❓ سوال فعلی در جریانه!\n"
                    f"سوال رو با !quiz cancel لغو کن یا صبر کن کسی جواب بده."
                )
            else:
                await self.highrise.chat("فرمت: !quiz سوال | جواب\nمثال: !quiz پایتخت ایران چیه | تهران")
            return

        question_part = parts[0].replace("!quiz", "").strip()
        answer = parts[1].strip()

        if not question_part or not answer:
            await self.highrise.chat("فرمت: !quiz سوال | جواب")
            return

        if message.strip().split()[1].lower() == "cancel":
            self._quiz_active = False
            self._quiz_answer = ""
            self._quiz_asked_by = ""
            self._save_ext_config()
            await self.highrise.chat("🚫 سوال لغو شد.")
            return

        self._quiz_active = True
        self._quiz_answer = answer
        self._quiz_asked_by = user.username
        self._save_ext_config()
        await self.highrise.chat(
            f"❓ سوال از @{user.username}:\n"
            f"{question_part}\n"
            f"اولین نفری که جواب درست بزنه +50 امتیاز می‌گیره! 🏆"
        )

    # ══════════════════════════════════════════════════════════════
    # سیستم گزارش 🚨
    # !report @username دلیل
    # ══════════════════════════════════════════════════════════════

    async def _cmd_report(self, user: User, message: str):
        parts = message.strip().split(maxsplit=2)
        if len(parts) < 3:
            await self.highrise.chat("فرمت: !report @username دلیل")
            return
        target = parts[1].lstrip("@")
        reason = parts[2]
        now = datetime.now().strftime("%H:%M")
        await self.highrise.chat(
            f"🚨 گزارش دریافت شد!\n"
            f"از: @{user.username}\n"
            f"کاربر: @{target}\n"
            f"دلیل: {reason}\n"
            f"⏰ {now} — ادمین بررسی می‌کنه."
        )
        try:
            admins = self.config.get("admin_usernames", [])
            if admins:
                dm_text = (
                    f"🚨 گزارش جدید!\n"
                    f"از @{user.username} درباره @{target}:\n"
                    f"دلیل: {reason}"
                )
                await self.highrise.send_message(
                    conversation_id="",
                    content=dm_text,
                    type="text",
                )
        except Exception as e:
            logger.error(f"خطا در ارسال DM گزارش: {e}")

    # ══════════════════════════════════════════════════════════════
    # سیستم VIP موقت ⭐
    # !tempvip @username دقیقه
    # ══════════════════════════════════════════════════════════════

    async def _cmd_tempvip(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 3:
            await self.highrise.chat("فرمت: !tempvip @username دقیقه")
            return
        target = parts[1].lstrip("@").lower()
        try:
            minutes = int(parts[2])
            if minutes < 1:
                raise ValueError
        except ValueError:
            await self.highrise.chat("❌ دقیقه باید عدد مثبت باشه!")
            return

        vips = self.config.setdefault("vip_usernames", [])
        if target not in vips:
            vips.append(target)
            self.save_config()

        await self.highrise.chat(
            f"⭐ @{target} برای {minutes} دقیقه VIP شد!"
        )

        async def _remove_vip():
            try:
                await sleep(minutes * 60)
                if target in self.config.get("vip_usernames", []):
                    self.config["vip_usernames"].remove(target)
                    self.save_config()
                await self.highrise.chat(f"⌛ VIP موقت @{target} به پایان رسید.")
                self._tempvip_tasks.pop(target, None)
            except CancelledError:
                pass

        if target in self._tempvip_tasks and not self._tempvip_tasks[target].done():
            self._tempvip_tasks[target].cancel()
        self._tempvip_tasks[target] = create_task(_remove_vip())

    async def _cmd_untempvip(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.chat("فرمت: !untempvip @username")
            return
        target = parts[1].lstrip("@").lower()
        if target in self._tempvip_tasks and not self._tempvip_tasks[target].done():
            self._tempvip_tasks[target].cancel()
            self._tempvip_tasks.pop(target, None)
        vips = self.config.get("vip_usernames", [])
        if target in vips:
            vips.remove(target)
            self.save_config()
        await self.highrise.chat(f"❌ VIP @{target} برداشته شد.")

    # ══════════════════════════════════════════════════════════════
    # سیستم بازدیدکنندگان 👥
    # ══════════════════════════════════════════════════════════════

    async def _cmd_visitors(self, user: User, message: str):
        today = datetime.now().strftime("%Y-%m-%d")
        visitors = self._visitors_today.get(today, set())
        if not visitors:
            await self.highrise.chat("امروز هنوز کسی نیومده.")
            return
        await self.highrise.chat(
            f"👥 بازدیدکنندگان امروز ({len(visitors)} نفر):\n" +
            ", ".join(f"@{u}" for u in list(visitors)[:20])
        )

    # ══════════════════════════════════════════════════════════════
    # سیستم خاموش/روشن بات 🔇
    # ══════════════════════════════════════════════════════════════

    async def _cmd_botoff(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        self._bot_silent = True
        self.ext_config["bot_silent"] = True
        self._save_ext_config()
        await self.highrise.chat("🔇 بات وارد مد سکوت شد.")

    async def _cmd_boton(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        self._bot_silent = False
        self.ext_config["bot_silent"] = False
        self._save_ext_config()
        await self.highrise.chat("🔊 بات از مد سکوت خارج شد!")

    # ══════════════════════════════════════════════════════════════
    # سیستم Countdown ⏳
    # !countdown عدد پیام — مثال: !countdown 10 مسابقه شروع میشه
    # ══════════════════════════════════════════════════════════════

    async def _cmd_countdown(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split(maxsplit=2)
        if len(parts) < 2:
            await self.highrise.chat("فرمت: !countdown عدد پیام\nمثال: !countdown 10 مسابقه شروع میشه")
            return
        if parts[1].lower() == "stop":
            if self._countdown_task and not self._countdown_task.done():
                self._countdown_task.cancel()
                await self.highrise.chat("🚫 تایمر متوقف شد.")
            else:
                await self.highrise.chat("❌ تایمری فعال نیست.")
            return
        try:
            seconds = int(parts[1])
            if seconds < 1 or seconds > 300:
                raise ValueError
        except ValueError:
            await self.highrise.chat("❌ عدد باید بین 1 تا 300 باشه!")
            return
        final_msg = parts[2] if len(parts) > 2 else "⏰ وقت تموم شد!"

        if self._countdown_task and not self._countdown_task.done():
            self._countdown_task.cancel()

        async def _run_countdown():
            try:
                await self.highrise.chat(f"⏳ تایمر شروع شد: {seconds} ثانیه")
                checkpoints = [s for s in [seconds, 30, 20, 10, 5, 3, 2, 1] if s < seconds]
                remaining = seconds
                for cp in sorted(checkpoints, reverse=True):
                    wait = remaining - cp
                    if wait > 0:
                        await sleep(wait)
                        remaining = cp
                        await self.highrise.chat(f"⏳ {cp} ثانیه مونده...")
                await sleep(remaining)
                await self.highrise.chat(f"🎯 {final_msg}")
            except CancelledError:
                pass
            except Exception as e:
                logger.error(f"خطا در countdown: {e}")

        self._countdown_task = create_task(_run_countdown())

    # ══════════════════════════════════════════════════════════════
    # سیستم Top امتیاز 🏆
    # ══════════════════════════════════════════════════════════════

    async def _cmd_top(self, user: User, message: str):
        scores = self.user_scores
        if not scores:
            await self.highrise.chat("هنوز کسی امتیازی نگرفته!")
            return
        top = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:10]
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        lines = ["🏆 برترین کاربرا:"]
        for i, (uname, score) in enumerate(top):
            lines.append(f"{medals[i]} {uname}: {score} امتیاز")
        await self.highrise.chat("\n".join(lines))

    # ══════════════════════════════════════════════════════════════
    # DM به کاربر خاص 📩
    # !dm @username پیام
    # ══════════════════════════════════════════════════════════════

    async def _cmd_dm(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split(maxsplit=2)
        if len(parts) < 3:
            await self.highrise.chat("فرمت: !dm @username پیام")
            return
        target = parts[1].lstrip("@")
        msg_text = parts[2]
        try:
            await self.highrise.send_message(
                conversation_id="",
                content=msg_text,
                type="text",
            )
            await self.highrise.chat(f"📩 پیام به @{target} ارسال شد.")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا در ارسال پیام: {e}")

    # ══════════════════════════════════════════════════════════════
    # راهنمای سیستم‌های اضافی
    # ══════════════════════════════════════════════════════════════

    # ══════════════════════════════════════════════════════════════
    # دستور !botdance
    # !botdance شماره/اسم/لینک high.rs  — تغییر دنس بات
    # !botdance stop        — متوقف کردن دنس بات
    # !botdance current     — دنس فعلی
    # ══════════════════════════════════════════════════════════════

    async def _cmd_botdance(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split(maxsplit=1)
        if len(parts) < 2:
            current = self._bot_dance_emote or "ندارد"
            await self.highrise.chat(
                f"💃 دستورات دنس بات:\n"
                f"!botdance شماره — مثال: !botdance 222\n"
                f"!botdance اسم — مثال: !botdance dance-floss\n"
                f"!botdance لینک — مثال: لینک high.rs دنس\n"
                f"!botdance stop — متوقف کردن\n"
                f"!botdance current — دنس فعلی\n"
                f"دنس الان: {current}"
            )
            return

        arg = parts[1].strip()

        if arg.lower() == "stop":
            self._bot_dance_emote = None
            self.ext_config["bot_dance_emote"] = None
            self._save_ext_config()
            if self._bot_dance_task and not self._bot_dance_task.done():
                self._bot_dance_task.cancel()
                self._bot_dance_task = None
            await self.highrise.chat("⏹ دنس بات متوقف شد.")
            return

        if arg.lower() == "current":
            current = self._bot_dance_emote or "ندارد"
            await self.highrise.chat(f"💃 دنس فعلی بات: {current}")
            return

        emote = self._resolve_emote(arg)
        if not emote:
            await self.highrise.chat(
                f"❌ دنس '{arg}' پیدا نشد!\n"
                f"می‌تونی شماره، اسم یا لینک high.rs دنس بزنی.\n"
                f"مثال: !botdance 222 یا !botdance dance-floss"
            )
            return

        self._bot_dance_emote = emote
        self.ext_config["bot_dance_emote"] = emote
        self._save_ext_config()

        if self._bot_dance_task and not self._bot_dance_task.done():
            self._bot_dance_task.cancel()
        self._bot_dance_task = create_task(self._bot_dance_loop())
        await self.highrise.chat(f"💃 دنس بات تغییر کرد به: {emote}")

    # ══════════════════════════════════════════════════════════════
    # سیستم تغییر روم 🚪 — فقط مالک بات
    # ══════════════════════════════════════════════════════════════

    OWNER = os.getenv("OWNER_USERNAME", "").strip().lower()

    async def _cmd_setroom(self, user: User, message: str):
        if user.username.lower() != self.OWNER:
            await self.highrise.chat("❌ فقط مالک می‌تونه روم رو عوض کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            current = self.ext_config.get("room_id", "پیش‌فرض")
            await self.highrise.chat(
                f"فرمت: !setroom [room_id]\n"
                f"روم فعلی: {current}\n"
                f"بعد از تغییر، بات ریستارت می‌کنه."
            )
            return
        new_room = parts[1].strip()
        old_room = self.ext_config.get("room_id", "نامشخص")
        self.ext_config["room_id"] = new_room
        self._save_ext_config()
        await self.highrise.chat(
            f"✅ آیدی روم ذخیره شد!\n"
            f"قبلی: {old_room}\n"
            f"جدید: {new_room}\n"
            f"🔄 بات داره میره روم جدید..."
        )
        await sleep(1.5)
        raise SystemExit("switch_room")

    async def _cmd_roominfo(self, user: User, message: str):
        if user.username.lower() != self.OWNER:
            await self.highrise.chat("❌ فقط مالک می‌تونه این رو ببینه.")
            return
        room_id = self.ext_config.get("room_id") or os.getenv("ROOM_ID", "از env")
        await self.highrise.chat(
            f"🏠 اطلاعات روم:\n"
            f"Room ID: {room_id}\n"
            f"برای تغییر: !setroom [room_id]"
        )

    async def _cmd_dancereset(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه از این دستور استفاده کنه.")
            return
        default = "dance-floss"
        self._bot_dance_emote = default
        self.ext_config["bot_dance_emote"] = default
        self._save_ext_config()
        if self._bot_dance_task and not self._bot_dance_task.done():
            self._bot_dance_task.cancel()
        self._bot_dance_task = create_task(self._bot_dance_loop())
        await self.highrise.chat(f"🔄 دنس بات ریست شد! برگشت به: {default}")

    async def _cmd_reset(self, user: User, message: str):
        username = user.username.lower()
        if username in self.dance_tasks and not self.dance_tasks[username].done():
            self.dance_tasks[username].cancel()
            self.dance_tasks.pop(username, None)
        self.user_dances.pop(username, None)
        self.party_dances.pop(username, None)
        await self.highrise.chat(f"🔄 @{user.username} دنست ریست شد!")

    # ══════════════════════════════════════════════════════════════
    # ⚠️ سیستم اخطار
    # ══════════════════════════════════════════════════════════════

    async def _cmd_warn(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه اخطار بده.")
            return
        parts = message.strip().split(None, 2)
        if len(parts) < 2:
            await self.highrise.chat("فرمت: !warn @username [دلیل]")
            return
        target = parts[1].lstrip("@").lower()
        reason = parts[2] if len(parts) > 2 else "بدون دلیل"
        warns = self.ext_config.setdefault("warn_records", {})
        warns[target] = warns.get(target, 0) + 1
        count = warns[target]
        self._save_ext_config()
        if count >= 5:
            warns[target] = 0
            self._save_ext_config()
            target_user = self.active_users.get(target)
            kicked = False
            if target_user:
                try:
                    await self.highrise.moderate_room(target_user.id, "kick", 0)
                    kicked = True
                except Exception:
                    pass
            if kicked:
                await self.highrise.chat(
                    f"👢 @{target} بعد از {count} اخطار همون لحظه اخراج شد!\n"
                    f"دلیل آخر: {reason}"
                )
            else:
                banned = self.ext_config.setdefault("banned_users", [])
                if target not in banned:
                    banned.append(target)
                    self._save_ext_config()
                await self.highrise.chat(
                    f"🚫 @{target} بعد از {count} اخطار بن شد (اخراج مستقیم پشتیبانی نشد)!\n"
                    f"دلیل آخر: {reason}"
                )
        else:
            await self.highrise.chat(
                f"⚠️ اخطار {count}/5 به @{target}\n"
                f"دلیل: {reason}"
            )
        if hasattr(self, "_mod_log"):
            await self._mod_log("اخطار", target, user.username, reason)

    async def _cmd_warns(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه کارنامه ببینه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.chat("فرمت: !warns @username")
            return
        target = parts[1].lstrip("@").lower()
        warns = self.ext_config.get("warn_records", {})
        count = warns.get(target, 0)
        banned = self.ext_config.get("banned_users", [])
        status = "🚫 بن شده" if target in banned else "✅ فعال"
        await self.highrise.chat(
            f"📋 کارنامه @{target}\n"
            f"اخطار: {count}/5\n"
            f"وضعیت: {status}"
        )

    async def _cmd_clearwarn(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه اخطار پاک کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.chat("فرمت: !clearwarn @username")
            return
        target = parts[1].lstrip("@").lower()
        self.ext_config.setdefault("warn_records", {}).pop(target, None)
        banned = self.ext_config.setdefault("banned_users", [])
        if target in banned:
            banned.remove(target)
        self._save_ext_config()
        await self.highrise.chat(f"✅ اخطارهای @{target} پاک شد.")

    # ══════════════════════════════════════════════════════════════
    # ⏰ سیستم پیام زمانبندی
    # ══════════════════════════════════════════════════════════════

    async def _cmd_schedule(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه پیام زمانبندی بذاره.")
            return
        parts = message.strip().split(None, 2)
        if len(parts) < 3:
            await self.highrise.chat("فرمت: !schedule [دقیقه] [پیام]")
            return
        try:
            minutes = float(parts[1])
        except ValueError:
            await self.highrise.chat("❌ عدد دقیقه درست نیست.")
            return
        scheduled_msg = parts[2]
        await self.highrise.chat(
            f"⏰ پیام بعد از {minutes:.0f} دقیقه ارسال میشه."
        )
        async def _send_later():
            await sleep(minutes * 60)
            await self.highrise.chat(f"📢 {scheduled_msg}")
        create_task(_send_later())

    # ══════════════════════════════════════════════════════════════
    # 📊 سیستم آمار
    # ══════════════════════════════════════════════════════════════

    async def _cmd_stats(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه آمار ببینه.")
            return
        today = datetime.now().strftime("%Y-%m-%d")
        visitors_today = len(self._visitors_today.get(today, set()))
        total_visitors = sum(len(v) for v in self._visitors_today.values())
        banned_count = len(self.ext_config.get("banned_users", []))
        warned_count = len(self.ext_config.get("warn_records", {}))
        admin_list = self.config.get("admin_usernames", [])
        vip_list = self.config.get("vip_usernames", [])
        floors_count = len(self.ext_config.get("floors", {}))
        await self.highrise.chat(
            f"📊 آمار اتاق:\n"
            f"👥 بازدیدکننده امروز: {visitors_today}\n"
            f"🗓 کل بازدید: {total_visitors}\n"
            f"🚫 بن‌شده: {banned_count}\n"
            f"⚠️ اخطارخورده: {warned_count}\n"
            f"👑 ادمین: {len(admin_list)}\n"
            f"⭐ VIP: {len(vip_list)}\n"
            f"🏠 طبقه: {floors_count}"
        )

    # ══════════════════════════════════════════════════════════════
    # 👥 سیستم همه‌کسی‌دنس
    # ══════════════════════════════════════════════════════════════

    async def _cmd_alldance(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه همه رو به دنس وادار کنه.")
            return
        parts = message.strip().split()
        emote_key = parts[1] if len(parts) > 1 else "dance-floss"
        emote = self._resolve_emote(emote_key)
        if not emote:
            await self.highrise.chat(f"❌ دنس '{emote_key}' پیدا نشد.")
            return
        try:
            room_users = await self.highrise.get_room_users()
            users = room_users.content if hasattr(room_users, "content") else []
        except Exception as e:
            await self.highrise.chat(f"❌ خطا در گرفتن لیست کاربران: {e}")
            return
        count = 0
        for u, _ in users:
            if u.id == self.user_id:
                continue
            try:
                await self.highrise.send_emote(emote, u.id)
                count += 1
                await sleep(0.3)
            except Exception:
                pass
        await self.highrise.chat(f"🕺 {count} نفر دنس '{emote_key}' زدن!")

    # ══════════════════════════════════════════════════════════════
    # 🔔 سیستم خوش‌آمد سفارشی
    # ══════════════════════════════════════════════════════════════

    async def _cmd_setwelcome(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه خوش‌آمد رو تنظیم کنه.")
            return
        parts = message.strip().split(None, 1)
        if len(parts) < 2:
            current = self.ext_config.get("welcome_dm_message", "")
            await self.highrise.chat(
                f"پیام فعلی:\n{current}\n\n"
                f"فرمت: !setwelcome [پیام]\n"
                f"از {{username}} برای نام کاربر استفاده کن."
            )
            return
        new_msg = parts[1]
        self.ext_config["welcome_dm_message"] = new_msg
        self.ext_config["welcome_dm"] = True
        self._save_ext_config()
        await self.highrise.chat(
            f"✅ پیام خوش‌آمد ذخیره شد:\n{new_msg}"
        )

    async def _cmd_welcomeon(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه.")
            return
        self.ext_config["welcome_dm"] = True
        self._save_ext_config()
        self.config["welcome_enabled"] = True
        self.save_config()
        await self.highrise.chat("✅ خوش‌آمد (پیام خصوصی + پیام تو چت روم) روشن شد.")

    async def _cmd_welcomeoff(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه.")
            return
        self.ext_config["welcome_dm"] = False
        self._save_ext_config()
        self.config["welcome_enabled"] = False
        self.save_config()
        await self.highrise.chat("🔕 خوش‌آمد (پیام خصوصی + پیام تو چت روم) خاموش شد.")

    async def _cmd_settoken(self, user: User, message: str):
        if user.username.lower() != self.OWNER:
            await self.highrise.chat("❌ فقط مالک می‌تونه توکن رو عوض کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.chat(
                "فرمت: !settoken [api_token]\n"
                "توکن جدید رو از Developer Portal بگیر."
            )
            return
        new_token = parts[1].strip()
        self.ext_config["api_token"] = new_token
        self._save_ext_config()
        await self.highrise.chat(
            "✅ توکن ذخیره شد!\n"
            "حالا !restart بزن تا با توکن جدید وصل بشه."
        )

    # ══════════════════════════════════════════════════════════════
    # رادیو روم اختصاصی 🎧
    #
    # این سیستم مدیریت کاتالوگ، صف و تعامل کاربران است. Highrise SDK فعلی
    # خروجی پخش فایل صوتی در روم را ارائه نمی‌کند؛ بنابراین منبع هر ترک به
    # شکل امن ذخیره می‌شود و مدیر رادیو از همین‌جا آن را کنترل می‌کند.
    # ══════════════════════════════════════════════════════════════

    def _radio_track_text(self, track_id: str) -> str:
        track = self._radio_tracks.get(track_id)
        if not track:
            return f"ترک {track_id} پیدا نشد."
        return f"🎧 [{track_id}] {track['title']}"

    def _radio_new_id(self) -> str:
        numbers = []
        for track_id in self._radio_tracks:
            if str(track_id).upper().startswith("R"):
                try:
                    numbers.append(int(str(track_id)[1:]))
                except ValueError:
                    pass
        return f"R{(max(numbers, default=0) + 1):03d}"

    def _radio_save(self):
        self._save_ext_config()

    def _looks_like_link(self, text: str) -> bool:
        t = text.strip().lower()
        return t.startswith("http://") or t.startswith("https://")

    def _looks_like_local_path(self, text: str) -> bool:
        """
        اگه دقیقاً یه فایل واقعی روی همین گوشی/Termux باشه، به‌عنوان
        منبع محلی قبولش می‌کنیم (بدون حدس‌زدن، فقط اگه واقعاً وجود داشته
        باشه) — اینجوری اشتباهی یه پیام معمولی رو به‌عنوان مسیر فایل
        قبول نمی‌کنیم. هم مسیر کامل هم فقط اسم فایل (توی پوشه‌ی music/
        کنار خود بات) رو قبول می‌کنه.
        """
        return self._resolve_local_music_path(text) is not None

    def _resolve_local_music_path(self, text: str):
        """
        اگه فقط اسم فایل داده بشه (مثلاً song.mp3)، اول توی پوشه‌ی
        music/ کنار خود بات می‌گرده؛ اگه پیدا نشد، مسیر کامل داده‌شده
        رو مستقیم چک می‌کنه. اگه هیچ‌کدوم نبود None برمی‌گردونه.
        """
        path = text.strip()
        if not path or self._looks_like_link(path):
            return None
        base_dir = os.path.dirname(os.path.abspath(__file__))
        music_path = os.path.join(base_dir, "music", path)
        if os.path.isfile(music_path):
            return music_path
        if os.path.isfile(path):
            return path
        return None

    async def _cmd_musiclist(self, user: User, message: str):
        files = self._music_files_sorted()
        if not files:
            await self.highrise.chat(
                "📭 پوشه‌ی music/ خالیه. فایل mp3 خودتو اونجا بریز، بعد !play بزن."
            )
            return
        lines = "\n".join(f"  {i+1}. {f}" for i, f in enumerate(files[:30]))
        await self.highrise.chat(f"🎵 آهنگ‌های محلی موجود:\n{lines}")

    def _music_files_sorted(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        folder = os.path.join(base_dir, "music")
        try:
            return sorted(
                f for f in os.listdir(folder)
                if os.path.isfile(os.path.join(folder, f))
                and not f.startswith(".")
                and f.lower() != "readme.txt"
            )
        except Exception:
            return []

    async def _play_music_index(self, idx: int):
        """
        اسمشو صدا نمی‌زنیم، فقط شماره‌ی ترتیبیشو تو پوشه‌ی music/ می‌گیریم
        و پخشش می‌کنیم — برای !play/!next/!prev که کاربر لازم نیست هیچ
        اسمی تایپ کنه.
        """
        files = self._music_files_sorted()
        if not files:
            await self.highrise.chat(
                "📭 پوشه‌ی music/ خالیه. اول یه آهنگ mp3 اونجا بریز (به INSTALL.txt نگاه کن)."
            )
            return
        idx = idx % len(files)
        filename = files[idx]
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, "music", filename)

        track_id = self._radio_add_from_local_file(full_path, added_by="playlist")
        if track_id in self.ext_config.get("banned_songs", []):
            await self.highrise.chat("🚫 این آهنگ توسط مدیریت بن شده و قابل پخش نیست.")
            return

        self.ext_config["music_playlist_index"] = idx
        self._save_ext_config()
        self._radio_current = track_id
        self._radio_playing = True
        self._radio_save()
        await self._radio_broadcast_sync(track_id)

    async def _cmd_play(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("⛔ این بخش فقط برای مدیر رادیو فعال است.")
            return
        idx = self.ext_config.get("music_playlist_index", -1)
        if idx < 0:
            idx = 0
        await self._play_music_index(idx)

    async def _cmd_prevsong(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("⛔ این بخش فقط برای مدیر رادیو فعال است.")
            return
        idx = self.ext_config.get("music_playlist_index", 0)
        await self._play_music_index(idx - 1)

    def _radio_guess_title(self, url: str) -> str:
        low = url.lower()
        if "youtu.be" in low or "youtube.com" in low:
            source = "یوتیوب"
        elif "soundcloud.com" in low:
            source = "ساندکلاود"
        elif "spotify.com" in low:
            source = "اسپاتیفای"
        else:
            source = "لینک"
        return f"آهنگ {source}"

    def _radio_add_from_local_file(self, path: str, added_by: str) -> str:
        """
        همون کار _radio_add_from_link رو می‌کنه ولی برای فایل‌های محلی
        روی گوشی (نه لینک). عنوان از روی اسم فایل ساخته می‌شه.
        """
        for track_id, track in self._radio_tracks.items():
            if track.get("source") == path:
                return track_id
        track_id = self._radio_new_id()
        self._radio_tracks[track_id] = {
            "title": f"🎵 {os.path.basename(path)}",
            "source": path,
            "added_by": added_by,
            "created_at": int(time.time()),
        }
        self._radio_save()
        return track_id

    def _radio_add_from_link(self, url: str, added_by: str) -> str:
        """
        اگه همین لینک قبلاً به کاتالوگ اضافه شده باشه، همون شناسه‌ی قبلی رو
        برمی‌گردونه؛ وگرنه یه ترک جدید می‌سازه و شناسه‌ش رو برمی‌گردونه.
        """
        for track_id, track in self._radio_tracks.items():
            if track.get("source") == url:
                return track_id
        track_id = self._radio_new_id()
        self._radio_tracks[track_id] = {
            "title": self._radio_guess_title(url),
            "source": url,
            "added_by": added_by,
            "created_at": int(time.time()),
        }
        self._radio_save()
        return track_id

    async def _radio_push_to_stream(self, source_url: str, title: str = "") -> bool:
        """
        اگه یه سرور رادیوی محلی (radio_server.py) روشن باشه، بهش می‌گه
        الان این لینک رو پخش کنه. True برمی‌گردونه یعنی موفق بود.
        اگه سرور روشن نبود یا خطا داد، فقط False برمی‌گردونه (بدون کرش)
        تا بات همیشه با روش قدیمی (لینک+شمارش‌معکوس) هم کار کنه.

        نکته‌ی مهم: توکن رو هر بار مستقیم از روی فایل تنظیمات دیسک
        می‌خونیم، نه از self.ext_config (که فقط موقع روشن‌شدن بات یه‌بار
        لود می‌شه). چون radio_server.py معمولاً کمی دیرتر از خود بات
        بالا میاد و توکن رو تازه اون‌موقع می‌سازه، اگه از حافظه‌ی قدیمی
        بات می‌خوندیم همیشه یه توکن خالی/قدیمی می‌گرفتیم و رد می‌شد.
        """
        # radio_server.py هم‌زمان با بات از start.bat اجرا می‌شود و ممکن است
        # چند ثانیه دیرتر آماده شود. قبلاً اولین تلاشِ ناموفق فوراً به حالت
        # قدیمیِ ارسال لینک برمی‌گشت و در روم پیام «سرور جواب نداد» دیده می‌شد.
        # فقط خطاهای اتصال/آماده‌نبودن را دوباره امتحان می‌کنیم؛ خطای HTTP
        # معتبر را بی‌دلیل تکرار نمی‌کنیم.
        timeout = aiohttp.ClientTimeout(total=5)
        try:
            async with aiohttp.ClientSession() as session:
                for attempt in range(6):
                    # سرور در اولین اجرا توکن را داخل radio_server_config.json
                    # می‌سازد؛ بنابراین تنظیمات را در هر تلاش تازه می‌خوانیم.
                    port, token, _public_url = self._radio_server_settings()
                    endpoint = f"http://127.0.0.1:{port}/control/play"
                    headers = {"X-Control-Token": token} if token else {}
                    try:
                        async with session.post(
                            endpoint,
                            json={"url": source_url, "title": title},
                            headers=headers,
                            timeout=timeout,
                        ) as resp:
                            if resp.status == 200:
                                return True
                            if resp.status not in {401, 403, 408, 425, 429, 500, 502, 503, 504}:
                                return False
                    except (aiohttp.ClientConnectionError, asyncio.TimeoutError):
                        pass
                    if attempt < 5:
                        await sleep(1)
        except Exception as exc:
            logger.warning(f"ارسال آهنگ به سرور رادیو ناموفق بود: {exc}")
        return False

    async def _radio_search_server(self, query: str):
        port, token, _public_url = self._radio_server_settings()
        if not query.strip():
            return []
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"X-Control-Token": token} if token else {}
                async with session.post(
                    f"http://127.0.0.1:{port}/control/search",
                    json={"query": query.strip(), "limit": 5},
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=25),
                ) as response:
                    if response.status != 200:
                        return []
                    data = await response.json()
                    results = data.get("results", [])
                    return results if isinstance(results, list) else []
        except Exception as exc:
            logger.warning(f"جستجوی رادیو ناموفق بود: {exc}")
            return []

    async def _radio_status(self):
        port, _token, _public_url = self._radio_server_settings()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"http://127.0.0.1:{port}/status",
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as response:
                    if response.status == 200:
                        return await response.json()
        except Exception:
            pass
        return {}

    async def _radio_broadcast_sync(self, track_id: str):
        """
        اگه یه لینک استریم ثابت تنظیم شده باشه (!setstreamurl)، فقط آهنگ رو
        پشت صحنه عوض می‌کنیم و یه پیام کوتاه می‌دیم — چون کسایی که از قبل
        استریم رو باز کردن خودکار آهنگ جدید رو می‌شنون، نیازی به لینک/شمارش
        معکوس نیست.

        اگه استریم تنظیم نشده، مثل قبل عمل می‌کنیم: لینک آهنگ رو می‌فرستیم
        و یه شمارش معکوس کوتاه می‌زنیم تا همه تقریباً هم‌زمان بازش کنن.
        """
        track = self._radio_tracks.get(track_id, {})
        title = track.get("title", track_id)
        source = track.get("source", "")
        is_local_file = bool(source) and not self._looks_like_link(source)

        _port, _token, configured_public_url = self._radio_server_settings()
        stream_url = self.ext_config.get("radio_stream_url", "") or configured_public_url
        if stream_url and source:
            pushed = await self._radio_push_to_stream(source, title)
            if pushed:
                await self.highrise.chat(f"🎶 آهنگ عوض شد: {title}")
                await self.highrise.chat(f"📻 اگه هنوز استریم رو باز نکردی: {stream_url}")
                return
            await self.highrise.chat(
                "⚠️ سرور رادیوی محلی جواب نداد؛ لطفاً radio_server.py رو چک کن."
            )
            if is_local_file:
                # مسیر فایل محلی برای بقیه‌ی کاربرا هیچ فایده‌ای نداره؛
                # بدون سرور رادیو راهی برای پخشش نیست
                return

        if is_local_file:
            await self.highrise.chat(
                "❌ این یه فایل محلی روی گوشیه، فقط از طریق سرور رادیو قابل پخشه.\n"
                "اول radio_server.py رو روشن کن و !setstreamurl رو بزن."
            )
            return

        await self.highrise.chat(f"🎶 آهنگ روم عوض شد: {title}")
        if source:
            await self.highrise.chat(f"🔗 {source}")
        await self.highrise.chat("⏳ همه آماده باشید... ۳")
        await sleep(1)
        await self.highrise.chat("۲")
        await sleep(1)
        await self.highrise.chat("۱")
        await sleep(1)
        await self.highrise.chat("▶️ پلی کنید! خوش بگذره 🎧")

    async def _cmd_setstreamurl(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه این تنظیم رو تغییر بده.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("http"):
            await self.highrise.chat(
                "فرمت: !setstreamurl <لینک عمومی>/stream\n"
                "لینک پیش‌فرض این سرور: http://141.11.21.75:15226/stream"
            )
            return
        self.ext_config["radio_stream_url"] = parts[1].strip()
        self._save_ext_config()
        await self.highrise.chat(
            f"✅ لینک استریم ثابت تنظیم شد: {parts[1].strip()}\n"
            f"از این به بعد !p/!q فقط آهنگ رو عوض می‌کنن، دیگه لینک جدید نمی‌فرستن."
        )

    async def _cmd_streamlink(self, user: User, message: str):
        _port, _token, configured_public_url = self._radio_server_settings()
        stream_url = self.ext_config.get("radio_stream_url", "") or configured_public_url
        if not stream_url:
            await self.highrise.chat(
                "📭 هنوز لینک استریم ثابتی تنظیم نشده. ادمین باید !setstreamurl بزنه."
            )
            return
        await self.highrise.chat(f"📻 لینک رادیوی زنده‌ی روم: {stream_url}")

    async def _cmd_radio(self, user: User, message: str):
        """Handle the original command and all short radio aliases."""
        parts = message.strip().split(maxsplit=2)
        command = parts[0].lower() if parts else "!radio"

        # برای دستورایی که یه آرگومان دارن (شناسه/لینک/اسم فایل)، کل باقی‌ی
        # پیام رو به‌عنوان یه رشته می‌گیریم، نه فقط اولین کلمه — وگرنه اسم
        # فایل‌هایی که فاصله دارن (مثل "Ahoora - Ghamginam.mp3") قطع می‌شدن
        single_split = message.strip().split(maxsplit=1)
        full_argument = single_split[1].strip() if len(single_split) > 1 else ""

        if command in {"!m"}:
            action = "play"
            argument = full_argument
            if argument and argument.upper() not in self._radio_tracks:
                matching = next(
                    (
                        track_id
                        for track_id, track in self._radio_tracks.items()
                        if track.get("title", "").casefold() == argument.casefold()
                    ),
                    None,
                )
                argument = matching or argument
        elif command in {"!p"}:
            action = "play"
            argument = full_argument
        elif command in {"!q"}:
            action = "queue" if full_argument else "queue-list"
            argument = full_argument
        elif command in {"!n"}:
            action = "next"
            argument = ""
        elif command in {"!next"}:
            action = "next"
            argument = ""
        elif command in {"!del"}:
            action = "dequeue"
            argument = full_argument
        elif command in {"!promote"}:
            action = "promote"
            argument = full_argument
        elif command in {"!effects", "!e"}:
            action = "effects"
            argument = full_argument
        elif command == "!emote-list":
            action = "emote-list"
            argument = ""
        elif command == "!mod-list":
            action = "mod-list"
            argument = ""
        elif command == "!fav-play":
            action = "favplay"
            argument = ""
        elif command in {"!fav-list"}:
            action = "favlist"
            argument = ""
        elif command in {"!daily"}:
            action = "daily"
            argument = ""
        elif command in {"!fav"}:
            action = "fav"
            argument = full_argument
        elif command in {"!credit"}:
            action = "credit"
            argument = ""
        elif command in {"!vote", "!up"}:
            action = "vote"
            argument = full_argument
        elif command in {"!rsearch", "!musicsearch", "!searchmusic", "!radiosearch"}:
            action = "search"
            argument = full_argument
        elif command == "!pick":
            action = "pick"
            argument = full_argument
        elif command in {"!music", "!song"} and full_argument:
            action = "search"
            argument = full_argument
        else:
            action = parts[1].lower() if len(parts) > 1 else "status"
            argument = parts[2] if len(parts) > 2 else ""

        admin_only = {
            "add", "del", "play", "pause", "stop", "next", "clear",
            "rename", "dequeue", "promote",
        }
        if action in admin_only and not self._is_admin(user):
            await self.highrise.chat("⛔ این بخش فقط برای مدیر رادیو فعال است.")
            return

        if action in {"help", "status", "current"}:
            current = self._radio_track_text(self._radio_current) if self._radio_current else "هنوز آهنگی انتخاب نشده"
            queue = "، ".join(self._radio_queue[:8]) or "خالی"
            await self.highrise.chat(
                "╭─ 🎧 رادیو نئون روم ─╮\n"
                f"│ وضعیت: {'▶️ در حال پخش' if self._radio_playing else '⏸ متوقف'}\n"
                f"│ ترک فعلی: {current}\n"
                f"│ صف: {queue}\n"
                "│ جستجو: !radio search نام آهنگ\n"
                "│ انتخاب نتیجه: !radio pick 1\n"
                "│ لینک ثابت: !streamlink\n"
                "╰─ مدیر: !p لینک | !q لینک | !next ─╯"
            )
            return

        if action == "queue-list":
            queue = [
                f"{index}. {self._radio_track_text(track_id)}"
                for index, track_id in enumerate(self._radio_queue, 1)
                if track_id in self._radio_tracks
            ]
            await self.highrise.chat(
                "🧾 صف پخش رادیو:\n" + ("\n".join(queue) or "صف خالی است.")
            )
            return

        if action == "list":
            if not self._radio_tracks:
                await self.highrise.chat("📚 کاتالوگ رادیو هنوز خالی است. مدیر با !radio add ترک | منبع اضافه کند.")
                return
            lines = ["📚 کاتالوگ رادیو:"]
            for track_id, track in list(self._radio_tracks.items())[:30]:
                lines.append(f"• {track_id} — {track['title']}")
            await self.highrise.chat("\n".join(lines))
            return

        if action == "search":
            query = argument.strip()
            if len(query) < 2:
                await self.highrise.chat(
                    "🔎 فرمت جستجو: !radio search نام آهنگ\n"
                    "مثال: !radio search محسن چاوشی کجایی"
                )
                return
            await self.highrise.chat(f"🔎 دارم دنبال «{query}» می‌گردم...")
            results = await self._radio_search_server(query)
            if not results:
                await self.highrise.chat(
                    "❌ نتیجه‌ای پیدا نشد یا ابزار جستجو آماده نیست.\n"
                    "لینک مستقیم آهنگ را با !radio play <link> بفرست."
                )
                return
            self._radio_search_results[user.username.lower()] = results
            lines = ["🎵 نتیجه‌های جستجو:"]
            for index, result in enumerate(results, 1):
                title = str(result.get("title", "بدون عنوان"))[:90]
                duration = result.get("duration")
                duration_text = f" — {int(duration)}ث" if isinstance(duration, (int, float)) else ""
                lines.append(f"{index}. {title}{duration_text}")
            lines.append("برای پخش/صف‌کردن یکی از نتیجه‌ها: !radio pick 1")
            await self.highrise.chat("\n".join(lines))
            return

        if action == "pick":
            try:
                index = int(argument.strip()) - 1
            except ValueError:
                await self.highrise.chat("فرمت: !radio pick <شماره نتیجه>")
                return
            results = self._radio_search_results.get(user.username.lower(), [])
            if index < 0 or index >= len(results):
                await self.highrise.chat("❌ نتیجه‌ای با این شماره پیدا نشد؛ اول !radio search بزن.")
                return
            result = results[index]
            source = str(result.get("webpage_url") or result.get("url") or "").strip()
            title = str(result.get("title") or "آهنگ جستجوشده").strip()
            if not source:
                await self.highrise.chat("❌ لینک نتیجه قابل پخش نیست.")
                return
            track_id = self._radio_add_from_link(source, user.username)
            self._radio_tracks[track_id]["title"] = title[:80]
            if track_id not in self._radio_queue and track_id != self._radio_current:
                self._radio_queue.append(track_id)
            if not self._radio_current or not self._radio_playing:
                self._radio_queue = [item for item in self._radio_queue if item != track_id]
                self._radio_current = track_id
                self._radio_playing = True
                await self._radio_broadcast_sync(track_id)
                self._radio_save()
                await self.highrise.chat(f"▶️ در حال پخش: {self._radio_track_text(track_id)}")
            else:
                self._radio_save()
                await self.highrise.chat(
                    f"✅ به صف رادیو اضافه شد: {self._radio_track_text(track_id)}"
                )
            return

        if action == "add":
            if "|" not in argument:
                await self.highrise.chat("فرمت: !radio add نام آهنگ | لینک یا منبع")
                return
            title, source = [item.strip() for item in argument.split("|", 1)]
            if not title or not source or len(title) > 80 or len(source) > 500:
                await self.highrise.chat("نام آهنگ یا منبع معتبر نیست.")
                return
            track_id = self._radio_new_id()
            self._radio_tracks[track_id] = {
                "title": title,
                "source": source,
                "added_by": user.username,
                "created_at": int(time.time()),
            }
            self._radio_save()
            await self.highrise.chat(f"✅ ترک اضافه شد: {self._radio_track_text(track_id)}\nبرای صف: !q {track_id}")
            return

        if action == "del":
            track_id = argument.strip().upper()
            if track_id not in self._radio_tracks:
                await self.highrise.chat("❌ شناسه ترک پیدا نشد.")
                return
            self._radio_tracks.pop(track_id)
            self._radio_queue = [item for item in self._radio_queue if item != track_id]
            if self._radio_current == track_id:
                self._radio_current = None
                self._radio_playing = False
            self._radio_save()
            await self.highrise.chat(f"🗑 ترک {track_id} از رادیو حذف شد.")
            return

        if action == "queue":
            raw_argument = argument.strip()
            track_id = raw_argument.upper()
            if track_id not in self._radio_tracks and self._looks_like_link(raw_argument):
                track_id = self._radio_add_from_link(raw_argument, user.username)
            elif track_id not in self._radio_tracks and self._looks_like_local_path(raw_argument):
                track_id = self._radio_add_from_local_file(
                    self._resolve_local_music_path(raw_argument), user.username
                )
            if track_id not in self._radio_tracks:
                await self.highrise.chat("❌ اول ترک را از !radio list انتخاب کن یا مستقیم لینک/مسیر فایل آهنگ رو بفرست.")
                return
            if track_id in self.ext_config.get("banned_songs", []):
                await self.highrise.chat("🚫 این آهنگ توسط مدیریت بن شده و قابل پخش نیست.")
                return
            if track_id in self._radio_queue:
                await self.highrise.chat("ℹ️ این ترک همین حالا در صف است.")
                return
            self._radio_queue.append(track_id)
            self._radio_save()
            await self.highrise.chat(f"✅ به صف اضافه شد: {self._radio_track_text(track_id)}")
            return

        if action == "dequeue":
            track_id = argument.strip().upper()
            if track_id not in self._radio_queue:
                await self.highrise.chat("❌ این ترک در صف نیست.")
                return
            self._radio_queue.remove(track_id)
            self._radio_save()
            await self.highrise.chat(f"🗑 از صف حذف شد: {self._radio_track_text(track_id)}")
            return

        if action == "promote":
            track_id = argument.strip().upper()
            if track_id not in self._radio_queue:
                await self.highrise.chat("❌ این ترک در صف نیست.")
                return
            self._radio_queue.remove(track_id)
            self._radio_queue.insert(0, track_id)
            self._radio_save()
            await self.highrise.chat(f"⬆️ ترک به ابتدای صف آمد: {self._radio_track_text(track_id)}")
            return

        if action == "effects":
            if argument:
                effect = self._resolve_emote(argument)
                if not effect:
                    await self.highrise.chat("❌ این افکت پیدا نشد. از !emote-list استفاده کن.")
                    return
                try:
                    await self.highrise.send_emote(effect, user.id)
                    await self.highrise.chat(f"✨ افکت اجرا شد: {effect}")
                except Exception as exc:
                    logger.error(f"Radio effect failed: {exc}")
                    await self.highrise.chat("❌ اجرای افکت ناموفق بود.")
                return
            emotes = list(self.emotes.items())[:40]
            await self.highrise.chat(
                "✨ افکت‌های آماده روم:\n"
                + " | ".join(f"{number}:{name}" for number, name in emotes)
                + "\nبرای اجرای افکت از دستورهای دنس فعلی استفاده کن."
            )
            return

        if action == "emote-list":
            names = list(self.emote_durations.keys())[:60]
            await self.highrise.chat(
                "✨ فهرست افکت‌ها:\n" + " | ".join(names)
            )
            return

        if action == "mod-list":
            admins = self.config.get("admin_usernames", [])
            await self.highrise.chat(
                "🛡 مدیران فعال روم:\n"
                + ("\n".join(f"• @{name}" for name in admins) or "مدیری ثبت نشده.")
            )
            return

        if action in {"play", "pause", "stop", "next"}:
            if action == "play":
                if argument:
                    raw_argument = argument.strip()
                    track_id = raw_argument.upper()
                    if track_id not in self._radio_tracks and self._looks_like_link(raw_argument):
                        # آهنگ با لینک مستقیم — به‌صورت خودکار به کاتالوگ اضافه میشه
                        track_id = self._radio_add_from_link(raw_argument, user.username)
                    elif track_id not in self._radio_tracks and self._looks_like_local_path(raw_argument):
                        # آهنگ محلی روی گوشی — بدون پخش صدا از خود گوشی
                        track_id = self._radio_add_from_local_file(
                            self._resolve_local_music_path(raw_argument), user.username
                        )
                    if track_id not in self._radio_tracks:
                        await self.highrise.chat("❌ شناسه ترک پیدا نشد. یا شناسه‌ی درست بزن، یا لینک آهنگ، یا مسیر فایل روی گوشی بفرست.")
                        return
                    if track_id in self.ext_config.get("banned_songs", []):
                        await self.highrise.chat("🚫 این آهنگ توسط مدیریت بن شده و قابل پخش نیست.")
                        return
                    self._radio_current = track_id
                    await self._radio_broadcast_sync(track_id)
                elif not self._radio_current and self._radio_queue:
                    self._radio_current = self._radio_queue.pop(0)
                if not self._radio_current:
                    await self.highrise.chat("❌ ابتدا یک ترک به رادیو اضافه یا وارد صف کن.")
                    return
                self._radio_playing = True
                self._radio_save()
                await self.highrise.chat(
                    f"▶️ رادیو روشن شد: {self._radio_track_text(self._radio_current)}"
                )
            elif action == "pause":
                self._radio_playing = False
                self._radio_save()
                await self.highrise.chat("⏸ رادیو موقتاً متوقف شد.")
            elif action == "stop":
                self._radio_playing = False
                self._radio_current = None
                self._radio_save()
                await self.highrise.chat("⏹ رادیو متوقف شد.")
            else:
                if self._radio_queue:
                    self._radio_current = self._radio_queue.pop(0)
                    self._radio_playing = True
                    self._radio_save()
                    await self.highrise.chat(f"⏭ ترک بعدی: {self._radio_track_text(self._radio_current)}")
                else:
                    # صف دستی خالیه — اگه پلی‌لیست محلی (پوشه‌ی music/) در
                    # حال استفاده‌ست، به‌جاش برو سراغ ترک بعدی همون پوشه
                    idx = self.ext_config.get("music_playlist_index", -1)
                    if idx >= 0 and self._music_files_sorted():
                        await self._play_music_index(idx + 1)
                    else:
                        self._radio_current = None
                        self._radio_playing = False
                        self._radio_save()
                        await self.highrise.chat("⏭ صف خالی است؛ ترک بعدی نداریم.")
            return

        if action == "clear":
            self._radio_queue.clear()
            self._radio_votes.clear()
            self._radio_save()
            await self.highrise.chat("🧹 صف رادیو پاک شد.")
            return

        if action == "vote":
            track_id = argument.strip().upper()
            if track_id not in self._radio_tracks:
                await self.highrise.chat("❌ شناسه ترک پیدا نشد.")
                return
            voters = self._radio_votes.setdefault(track_id, [])
            username = user.username.lower()
            if username in voters:
                await self.highrise.chat("ℹ️ رأی تو قبلاً ثبت شده.")
                return
            voters.append(username)
            self._radio_save()
            await self.highrise.chat(f"👍 رأی ثبت شد: {self._radio_track_text(track_id)} ({len(voters)} رأی)")
            return

        if action in {"fav", "favorite"}:
            track_id = argument.strip().upper()
            if track_id not in self._radio_tracks:
                await self.highrise.chat("❌ شناسه ترک پیدا نشد.")
                return
            username = user.username.lower()
            favorites = self._radio_favorites.setdefault(username, [])
            if track_id in favorites:
                favorites.remove(track_id)
                text = "از علاقه‌مندی‌ها حذف شد."
            else:
                favorites.append(track_id)
                text = "به علاقه‌مندی‌ها اضافه شد."
            self._radio_save()
            await self.highrise.chat(f"⭐ {self._radio_track_text(track_id)} {text}")
            return

        if action == "favlist":
            favorites = self._radio_favorites.get(user.username.lower(), [])
            names = [self._radio_track_text(track_id) for track_id in favorites if track_id in self._radio_tracks]
            await self.highrise.chat("⭐ علاقه‌مندی‌های تو:\n" + ("\n".join(names) or "هنوز چیزی ذخیره نکردی."))
            return

        if action == "favplay":
            favorites = self._radio_favorites.get(user.username.lower(), [])
            added = 0
            for track_id in favorites:
                if track_id in self._radio_tracks and track_id not in self._radio_queue:
                    self._radio_queue.append(track_id)
                    added += 1
            self._radio_save()
            await self.highrise.chat(f"⭐ {added} آهنگ از علاقه‌مندی‌ها وارد صف شد.")
            return

        if action == "credit":
            amount = self._radio_credits.get(user.username.lower(), 0)
            await self.highrise.chat(f"💳 اعتبار رادیو @{user.username}: {amount}")
            return

        if action == "daily":
            username = user.username.lower()
            today = datetime.now().strftime("%Y-%m-%d")
            if self._radio_daily_claims.get(username) == today:
                await self.highrise.chat("⏳ پاداش امروزت را قبلاً گرفتی.")
                return
            self._radio_daily_claims[username] = today
            self._radio_credits[username] = self._radio_credits.get(username, 0) + 50
            self._radio_save()
            await self.highrise.chat("🎁 پاداش روزانه: ۵۰ اعتبار رادیو به حسابت اضافه شد.")
            return

        await self.highrise.chat(
            "فرمان رادیو شناخته نشد. راهنمای سریع:\n"
            "!radio list | !q R001 | !p R001 | !n\n"
            "!vote R001 | !fav R001 | !fav-list | !credit | !daily"
        )

    async def _cmd_restart(self, user: User, message: str):
        if user.username.lower() != self.OWNER and not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه بات رو ریستارت کنه.")
            return
        await self.highrise.chat("🔄 بات داره ریستارت می‌شه...")
        await sleep(1.5)
        raise SystemExit("restart")

    async def _cmd_help_override(self, user: User, message: str):
        await self.highrise.chat(
            "╭──────────────╮\n"
            "│ 🎧 نئون روم | راهنمای سریع │\n"
            "╰──────────────╯\n"
            "🎵 رادیو: !radio help\n"
            "💃 دنس و افکت: !botdance  |  !effects\n"
            "📍 رفت‌وآمد: !floors  |  !tele @user\n"
            "🎲 سرگرمی: !lottery  |  !quiz  |  !top\n"
            "🛡 مدیریت: !exthelp 2\n"
            "📚 راهنمای کامل: !exthelp 1"
        )

    async def _cmd_exthelp(self, user: User, message: str):
        parts = message.strip().split()
        page = parts[1] if len(parts) > 1 else "1"

        if page == "1":
            await self.highrise.chat(
                "╭──── 🎧 نئون روم | رادیو ────╮\n"
                "│ !radio / !music — وضعیت و راهنما\n"
                "│ !radio list — کاتالوگ آهنگ‌ها\n"
                "│ !q R001 — افزودن به صف | !q — صف\n"
                "│ !p R001 — شروع | !n — آهنگ بعدی\n"
                "│ !radio pause — مکث | !radio stop — توقف\n"
                "│ !vote R001 — رأی به آهنگ\n"
                "│ !fav R001 — ذخیره | !fav-list — فهرست\n"
                "│ !fav-play — آوردن علاقه‌مندی‌ها به صف\n"
                "│ !credit — اعتبار | !daily — پاداش روزانه\n"
                "│ مدیر: !radio add نام | منبع\n"
                "╰────────────────────────╯\n"
                "برای مدیریت روم: !exthelp 2\n"
                "برای ابزارهای سرگرمی و اتاق: !exthelp 3"
            )
        elif page == "2":
            await self.highrise.chat(
                "╭──── 🛡 نئون روم | مدیریت ────╮\n"
                "│ !botoff / !boton — خاموش و روشن کردن\n"
                "│ !setloop 10 متن | !loopon | !loopoff\n"
                "│ !sethome | !home | !delhome | !pos\n"
                "│ !setfloor نام | !delfloor | !floors\n"
                "│ !setroom [id] | !roominfo\n"
                "│ !tempvip @user [دقیقه]\n"
                "│ !untempvip @user\n"
                "│ !restart — راه‌اندازی دوباره\n"
                "│ !mod-list — فهرست مدیران\n"
                "╰────────────────────────╯\n"
                "صفحه رادیو: !exthelp 1\n"
                "صفحه ابزارها: !exthelp 3"
            )
        elif page == "3":
            await self.highrise.chat(
                "╭──── 🎲 نئون روم | ابزارها ────╮\n"
                "│ !lottery start [جایزه] | !lottery list\n"
                "│ !lottery end | !lottery cancel | !join\n"
                "│ !quiz سوال | جواب — مسابقه امتیازی\n"
                "│ !top — جدول امتیازها\n"
                "│ !visitors — بازدیدکنندگان\n"
                "│ !countdown [ثانیه] [پیام]\n"
                "│ !report @user [دلیل] | !dm @user [متن]\n"
                "│ !warn @user [دلیل] | !warns @user\n"
                "│ !clearwarn @user | !stats\n"
                "│ !schedule [دقیقه] [پیام]\n"
                "│ !botdance [نام/شماره] | !dancereset\n"
                "│ !effects [نام] | !emote-list | !alldance\n"
                "╰────────────────────────╯\n"
                "صفحه رادیو: !exthelp 1\n"
                "صفحه مدیریت: !exthelp 2"
            )
        else:
            await self.highrise.chat(
                "📚 صفحه پیدا نشد.\n"
                "از !exthelp 1 برای رادیو، !exthelp 2 برای مدیریت، "
                "یا !exthelp 3 برای ابزارهای روم استفاده کن."
            )


def _get_room_id():
    try:
        if os.path.exists(EXT_CONFIG_FILE):
            with open(EXT_CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("room_id"):
                return data["room_id"]
    except Exception:
        pass
    return os.getenv("ROOM_ID", "")


def _get_api_token():
    try:
        if os.path.exists(EXT_CONFIG_FILE):
            with open(EXT_CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("api_token"):
                return data["api_token"]
    except Exception:
        pass
    return os.getenv("API_TOKEN", "")


async def main():
    api_token = _get_api_token()

    if not api_token or not _get_room_id():
        logger.error("API_TOKEN یا ROOM_ID تنظیم نشده. برنامه متوقف شد.")
        return

    from net_wait import wait_for_network
    max_attempts = 10**9  # never give up
    attempt = 0
    while attempt < max_attempts:
        await wait_for_network()
        room_id = _get_room_id()
        bot = ExtendedBot()
        bot_def = BotDefinition(room_id=room_id, api_token=api_token, bot=bot)
        logger.info(f"اتصال به روم: {room_id}")
        try:
            from highrise.__main__ import main as highrise_main
            await highrise_main([bot_def])
        except SystemExit as e:
            reason = str(e)
            logger.info(f"SystemExit دریافت شد: {reason}")
            attempt = 0
            await sleep(2)
            continue
        except BaseException as e:
            if "ClientConnectionReset" in type(e).__name__:
                logger.error(f"اتصال قطع شد: {e}")
                try:
                    await bot_def.bot.cleanup_tasks()
                except Exception:
                    pass
                attempt += 1
                logger.info(f"تلاش مجدد ({attempt}) بعد از ۱ ثانیه...")
                await sleep(1)
            else:
                logger.error(f"خطای ناشناخته: {type(e).__name__}: {e}")
                attempt += 1
                await sleep(1)
        else:
            attempt = 0
    logger.error("حداکثر تلاش‌های اتصال به پایان رسید.")


if __name__ == "__main__":
    import asyncio
    import sys as _sys
    for _stream in (_sys.stdout, _sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.FileHandler("bot_ext.log", encoding="utf-8"), logging.StreamHandler()]
    )
    try:
        asyncio.run(main())
    except Exception as e:
        logger.error(f"خطا در اجرای اولیه: {e}", exc_info=True)
