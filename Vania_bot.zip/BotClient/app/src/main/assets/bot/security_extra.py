"""
سیستم امنیت و نظارت خودکار روم.

سه تا قابلیت مستقل اینجاست، هر سه با الگوی «اول اخطار متنی، دوباره
تکرار کرد میوت» کار می‌کنن:

۱) آنتی‌اسپم خودکار
   دفعه‌ی اول که یه کاربر توی چند ثانیه پیام‌های زیاد بفرسته، فقط یه
   اخطار متنی می‌گیره. اگه دوباره تکرار کرد، خودکار برای چند دقیقه
   میوت می‌شه (از همون سیستم !mute موجود توی mod_extra.py استفاده
   می‌کنه).

۲) لاگ نظارتی
   هر بار یکی بن/کیک/میوت/فریز/زندان/اخطار بشه (چه دستی چه خودکار)،
   یه خط توی فایل mod_log.txt ذخیره می‌شه. با !modlog می‌شه آخرین
   اتفاق‌ها رو توی چت روم دید (فقط ادمین/ناظر).

۳) محافظ در برابر تبلیغ روم دیگه (raid guard)
   دفعه‌ی اول که کسی لینک یه روم دیگه (نه همین روم) بفرسته یا با
   جمله‌هایی مثل «بریم روم من» بقیه رو به یه روم دیگه دعوت کنه، فقط
   اخطار متنی می‌گیره. دوباره تکرار کرد، خودکار میوت می‌شه. با
   !raidguard on/off قابل کنترله.

با !muted هم می‌شه لیست کاربرهایی که الان خودکار یا دستی میوت هستن
رو دید، تا راحت‌تر بشه با !unmute آزادشون کرد.
"""

import os
import re
import time
from asyncio import create_task, sleep, CancelledError
from collections import deque, defaultdict

from highrise import User

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MOD_LOG_FILE = os.path.join(BASE_DIR, "mod_log.txt")

# تنظیمات آنتی‌اسپم
SPAM_WINDOW_SECONDS = 8      # این بازه‌ی زمانی رو بررسی می‌کنیم
SPAM_MAX_MESSAGES = 5        # اگه توی این بازه بیشتر از این تعداد پیام بفرسته
SPAM_MUTE_MINUTES = 3        # این‌قدر خودکار میوت می‌شه

# تنظیمات محافظ در برابر تبلیغ روم دیگه (raid guard)
RAID_MUTE_MINUTES = 10
_ROOM_LINK_RE = re.compile(r"highrise\.game/room/([A-Za-z0-9_-]+)")
_RAID_PHRASES = [
    "بریم روم", "بریم اتاق", "بیا بریم", "بیاید بریم", "بیایین بریم",
    "بیاین بریم", "روم من", "اتاق من", "بیا این روم", "بیا این اتاق",
    "join my room", "come to my room", "come to this room", "join this room",
]


class SecurityExtraMixin:

    def _init_security_state(self):
        if not hasattr(self, "_chat_history"):
            self._chat_history = defaultdict(deque)  # username -> deque[(ts, text)]
        if not hasattr(self, "_mod_log_buffer"):
            self._mod_log_buffer = deque(maxlen=50)
        if not hasattr(self, "_auto_warnings"):
            self._auto_warnings = defaultdict(int)  # username -> تعداد اخطار خودکار

    # ── لاگ نظارتی ──────────────────────────────────────────────

    async def _mod_log(self, action: str, target: str, by: str, reason: str = ""):
        self._init_security_state()
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{stamp}] {action} | هدف: @{target} | توسط: @{by}"
        if reason:
            line += f" | دلیل: {reason}"
        self._mod_log_buffer.append(line)
        try:
            with open(MOD_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

        owner = getattr(self, "OWNER", "")
        if owner:
            owner_user = self.active_users.get(owner)
            if owner_user:
                try:
                    await self.highrise.chat(f"🛡 (لاگ) {action}: @{target} توسط @{by}")
                except Exception:
                    pass

    async def _cmd_modlog(self, user: User, message: str):
        self._init_security_state()
        if not (self._is_admin(user) or self._is_mod(user)):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه لاگ رو ببینه.")
            return
        if not self._mod_log_buffer:
            await self.highrise.chat("📭 هنوز هیچ اقدام نظارتی ثبت نشده.")
            return
        lines = list(self._mod_log_buffer)[-10:]
        await self.highrise.chat("🛡 آخرین اقدامات نظارتی:\n" + "\n".join(lines))

    async def _cmd_security_toggle(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه این تنظیم رو تغییر بده.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or parts[1].lower() not in ("on", "off"):
            await self.highrise.chat("فرمت: !security on  یا  !security off")
            return
        enabled = parts[1].lower() == "on"
        self.ext_config["security_enabled"] = enabled
        self._save_ext_config()
        await self.highrise.chat(
            "🛡 آنتی‌اسپم خودکار فعال شد." if enabled else "⛔ آنتی‌اسپم خودکار غیرفعال شد."
        )

    # ── لیست کاربرهای میوت‌شده + کمک برای unmute ─────────────────

    async def _cmd_muted_list(self, user: User, message: str):
        self._init_security_state()
        if hasattr(self, "_init_mod_state"):
            self._init_mod_state()
        muted = getattr(self, "_muted_users", {})
        active = [name for name, task in muted.items() if task and not task.done()]
        if not active:
            await self.highrise.chat("📭 الان هیچ‌کس میوت نیست.")
            return
        lines = "\n".join(f"  • @{name}" for name in active)
        await self.highrise.chat(
            "🔇 کاربرهای میوت‌شده‌ی الان:\n" + lines +
            "\nبرای آزادکردن: !unmute @یوزرنیم"
        )

    # ── هسته‌ی مشترک: اخطار متنی، دوباره تکرار شد میوت ────────────

    async def _warn_then_mute(self, user: User, key: str, warn_text: str,
                               mute_minutes: int, mute_reason: str) -> bool:
        """
        دفعه‌ی اول فقط اخطار متنی می‌ده و True برمی‌گردونه (چون پیام
        پردازش شد و دیگه نباید ادامه پیدا کنه). دفعه‌ی بعد که همون
        کاربر دوباره خطا کنه، میوتش می‌کنه و شمارنده رو صفر می‌کنه.
        """
        self._init_security_state()
        username = user.username.lower()
        warn_key = f"{key}:{username}"
        count = self._auto_warnings[warn_key]

        if count == 0:
            self._auto_warnings[warn_key] = 1
            await self.highrise.chat(f"⚠️ {warn_text}")
            await self._mod_log("اخطار خودکار", username, "ربات", mute_reason)
            return True

        # دفعه‌ی دوم به بعد → میوت واقعی
        self._auto_warnings[warn_key] = 0

        if hasattr(self, "_init_mod_state"):
            self._init_mod_state()

        target_user = self.active_users.get(username)
        try:
            if target_user:
                await self.highrise.moderate_room(target_user.id, "mute", mute_minutes * 60)
        except Exception:
            pass

        old_task = self._muted_users.get(username)
        if old_task and not old_task.done():
            old_task.cancel()

        async def _unmute_later():
            try:
                await sleep(mute_minutes * 60)
                self._muted_users.pop(username, None)
            except CancelledError:
                pass

        self._muted_users[username] = create_task(_unmute_later())
        await self.highrise.chat(
            f"🤖 @{user.username} چون بعد از اخطار بازم تکرار کرد، برای "
            f"{mute_minutes} دقیقه خودکار ساکت شد."
        )
        await self._mod_log(f"{mute_reason} (میوت خودکار بعد از اخطار)", username, "ربات")
        return True

    # ── آنتی‌اسپم خودکار ────────────────────────────────────────

    async def _check_spam(self, user: User, message: str) -> bool:
        """اگه اسپم تشخیص داد True برمی‌گردونه (یعنی پیام دیگه پردازش نشه)."""
        self._init_security_state()

        if not self.ext_config.get("security_enabled", True):
            return False

        # ادمین و ناظر هیچ‌وقت خودکار میوت نمی‌شن
        if self._is_admin(user) or self._is_mod(user):
            return False

        if hasattr(self, "_init_mod_state"):
            self._init_mod_state()

        username = user.username.lower()
        now = time.time()
        history = self._chat_history[username]
        history.append((now, message.strip().lower()))

        while history and now - history[0][0] > SPAM_WINDOW_SECONDS:
            history.popleft()

        if len(history) < SPAM_MAX_MESSAGES:
            return False

        # اگه توی این بازه بیش از حد پیام فرستاده (چه تکراری چه نه) → اسپمه
        history.clear()

        if self.is_muted(username):
            return True  # از قبل میوته، فقط جلوی پردازش رو بگیر

        return await self._warn_then_mute(
            user,
            key="spam",
            warn_text=f"@{user.username} لطفاً پیام‌های زیادی پشت‌سرهم نفرست، "
                      f"دفعه‌ی بعد خودکار میوت می‌شی.",
            mute_minutes=SPAM_MUTE_MINUTES,
            mute_reason="اسپم",
        )

    # ── محافظ در برابر تبلیغ روم دیگه (raid guard) ─────────────────

    async def _cmd_raidguard_toggle(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه این تنظیم رو تغییر بده.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or parts[1].lower() not in ("on", "off"):
            await self.highrise.chat("فرمت: !raidguard on  یا  !raidguard off")
            return
        enabled = parts[1].lower() == "on"
        self.ext_config["raidguard_enabled"] = enabled
        self._save_ext_config()
        await self.highrise.chat(
            "🛡 محافظ تبلیغ روم دیگه روشن شد." if enabled else "⛔ محافظ تبلیغ روم دیگه خاموش شد."
        )

    async def _check_room_poaching(self, user: User, message: str) -> bool:
        """
        اگه کسی لینک یه روم دیگه (نه همین روم) بفرسته، یا با جمله‌هایی
        مثل «بریم روم من» بقیه رو به روم دیگه دعوت کنه، دفعه‌ی اول فقط
        اخطار می‌گیره؛ دفعه‌ی بعد میوت می‌شه.
        True برمی‌گردونه یعنی پیام دیگه پردازش نشه.
        """
        self._init_security_state()

        if not self.ext_config.get("raidguard_enabled", True):
            return False

        if self._is_admin(user) or (hasattr(self, "_is_mod") and self._is_mod(user)):
            return False

        text = message.strip()
        text_lower = text.lower()

        own_room_id = os.getenv("ROOM_ID", "")
        found_other_room_link = False
        for match in _ROOM_LINK_RE.finditer(text):
            if match.group(1) != own_room_id:
                found_other_room_link = True
                break

        found_phrase = any(phrase in text_lower for phrase in _RAID_PHRASES)

        if not found_other_room_link and not found_phrase:
            return False

        reason = "لینک روم دیگه" if found_other_room_link else "دعوت به روم دیگه"
        return await self._warn_then_mute(
            user,
            key="raid",
            warn_text=f"@{user.username} تبلیغ روم دیگه اینجا مجاز نیست، "
                      f"دفعه‌ی بعد خودکار میوت می‌شی.",
            mute_minutes=RAID_MUTE_MINUTES,
            mute_reason=reason,
        )
