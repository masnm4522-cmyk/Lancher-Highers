"""
سیستم نظارت، VIP و افکت‌های گروهی (الهام‌گرفته از دستورات ربات‌های موزیک/نظارتی روم)

این فایل مستقل از serve2.py و extended_serve2.py هست (مثل teleport_extra.py و
emote_extra.py) تا دستورهای جدید تمیز و جدا بمونن.

دستورهای «نظارت» (ادمین یا ناظر):
  !mod @user            -> افزودن ناظر (فقط ادمین)
  !unmod @user          -> حذف ناظر (فقط ادمین)
  !mod-list              -> فهرست ادمین‌ها و ناظرها
  !mute @user دقیقه      -> سکوت موقت کاربر (ربات دستورها/پیام‌هاش رو نادیده می‌گیره)
  !unmute @user          -> رفع سکوت
  !kick @user            -> اخراج کاربر از روم (best effort)
  !double @user [شماره]  -> اجرای یک ایموت دوبار پشت‌سرهم روی کاربر
  !punch @user           -> یک مشت (ایموت) به کاربر
  !punch all             -> مشت به همه‌ی روم (فقط ادمین)
  !clown @user           -> ایموت مسخره/دلقک روی کاربر
  !jail @user دقیقه      -> تبعید موقت به مکان زندان
  !unjail @user          -> بازگردوندن زودتر از زندان

دستورهای VIP:
  !vip-args              -> نمایش مزایای VIP
  !vip-list               -> فهرست کاربران VIP (دائمی و موقت)

دستورهای ادمین:
  !come                  -> احضار بات به موقعیت ادمین (مثل !set ولی اسم متفاوت)
  !tp on / !tp off        -> فعال/غیرفعال کردن سیستم تلپورت (!tele/!summ/!jail)
  !ban-music <شناسه یا نام> -> اضافه کردن آهنگ به لیست سیاه رادیو
  !unban-music <شناسه>   -> خارج کردن آهنگ از لیست سیاه
"""

from asyncio import create_task, sleep, CancelledError
from highrise import User, Position


class ModExtraMixin:

    # ── دسترسی‌ها ──────────────────────────────────────────────────

    def _is_mod(self, user: User) -> bool:
        return user.username.lower() in self.config.get("mod_usernames", [])

    def _is_staff(self, user: User) -> bool:
        return self._is_admin(user) or self._is_mod(user)

    def _tp_enabled(self) -> bool:
        return self.ext_config.get("tp_enabled", True)

    # ── سکوت (mute) ────────────────────────────────────────────────

    def _init_mod_state(self):
        if not hasattr(self, "_muted_users"):
            self._muted_users = {}   # username -> Task
        if not hasattr(self, "_jailed_users"):
            self._jailed_users = {}  # username -> Task

    def is_muted(self, username: str) -> bool:
        self._init_mod_state()
        return username.lower() in self._muted_users

    async def _cmd_mod(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه ناظر اضافه کنه.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !mod @username")
            return
        target = parts[1][1:].lower()
        mods = self.config.setdefault("mod_usernames", [])
        if target in mods:
            await self.highrise.chat(f"@{target} از قبل ناظره.")
            return
        mods.append(target)
        self.save_config()
        await self.highrise.chat(f"🛡 @{target} به‌عنوان ناظر اضافه شد.")

    async def _cmd_unmod(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه ناظر حذف کنه.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !unmod @username")
            return
        target = parts[1][1:].lower()
        mods = self.config.get("mod_usernames", [])
        if target not in mods:
            await self.highrise.chat(f"@{target} ناظر نیست.")
            return
        mods.remove(target)
        self.save_config()
        await self.highrise.chat(f"🛡 @{target} از لیست ناظرها حذف شد.")

    async def _cmd_mod_list_full(self, user: User, message: str):
        admins = self.config.get("admin_usernames", [])
        mods = self.config.get("mod_usernames", [])
        lines = ["🛡 مدیران:"]
        lines += [f"  • @{n}" for n in admins] or ["  (خالی)"]
        lines.append("👮 ناظرها:")
        lines += [f"  • @{n}" for n in mods] or ["  (خالی)"]
        await self.highrise.chat("\n".join(lines))

    async def _cmd_mute(self, user: User, message: str):
        self._init_mod_state()
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه سکوت بده.")
            return
        parts = message.strip().split()
        if len(parts) < 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !mute @username [دقیقه]")
            return
        target = parts[1][1:].lower()
        minutes = 5
        if len(parts) >= 3 and parts[2].isdigit():
            minutes = max(1, int(parts[2]))

        target_user = self.active_users.get(target)
        if target_user:
            try:
                await self.highrise.moderate_room(target_user.id, "mute", minutes * 60)
            except Exception:
                pass  # SDK ممکنه ساپورت نکنه، به روش نرم ادامه می‌دیم

        old_task = self._muted_users.get(target)
        if old_task and not old_task.done():
            old_task.cancel()

        async def _unmute_later():
            try:
                await sleep(minutes * 60)
                self._muted_users.pop(target, None)
                await self.highrise.chat(f"🔊 سکوت @{target} تموم شد.")
            except CancelledError:
                pass

        self._muted_users[target] = create_task(_unmute_later())
        await self.highrise.chat(f"🔇 @{target} برای {minutes} دقیقه ساکت شد.")
        if hasattr(self, "_mod_log"):
            await self._mod_log("میوت", target, user.username, f"{minutes} دقیقه")

    async def _cmd_unmute(self, user: User, message: str):
        self._init_mod_state()
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه رفع سکوت کنه.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !unmute @username")
            return
        target = parts[1][1:].lower()
        task = self._muted_users.pop(target, None)
        if task and not task.done():
            task.cancel()
        target_user = self.active_users.get(target)
        if target_user:
            try:
                await self.highrise.moderate_room(target_user.id, "unmute", 0)
            except Exception:
                pass
        await self.highrise.chat(f"🔊 @{target} رفع سکوت شد.")

    async def _cmd_kick(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه اخراج کنه.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !kick @username")
            return
        target = parts[1][1:].lower()
        target_user = self.active_users.get(target)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target} توی روم نیست.")
            return
        try:
            await self.highrise.moderate_room(target_user.id, "kick", 0)
            await self.highrise.chat(f"👢 @{target} از روم اخراج شد.")
            if hasattr(self, "_mod_log"):
                await self._mod_log("کیک", target, user.username)
        except Exception as e:
            await self.highrise.chat(
                f"⚠️ اخراج مستقیم پشتیبانی نشد ({e}); به‌جاش @{target} به زندان تبعید شد."
            )
            await self._jail_user(user, target, 3)

    # ── ایموت‌های شوخی روی کاربر ─────────────────────────────────────

    async def _cmd_double(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه این دستور رو بزنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !double @username [شماره ایموت]")
            return
        target = parts[1][1:].lower()
        target_user = self.active_users.get(target)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target} توی روم نیست.")
            return
        emote_key = parts[2] if len(parts) > 2 else "56"  # پیش‌فرض: emote-laughing
        emote_id = self.emotes.get(emote_key, "emote-laughing")
        try:
            for _ in range(2):
                await self.highrise.send_emote(emote_id, target_user.id)
                await sleep(1.0)
            await self.highrise.chat(f"🎭 ایموت دوتایی روی @{target} اجرا شد.")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا در اجرای ایموت: {e}")

    async def _cmd_punch(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه مشت بزنه.")
            return
        parts = message.strip().split()
        if len(parts) == 2 and parts[1].lower() == "all":
            if not self._is_admin(user):
                await self.highrise.chat("❌ !punch all فقط برای ادمینه.")
                return
            count = 0
            for username, target_user in list(self.active_users.items()):
                if target_user.id == self.user_id:
                    continue
                try:
                    await self.highrise.send_emote("emote-superpunch", target_user.id)
                    count += 1
                    await sleep(0.4)
                except Exception:
                    continue
            await self.highrise.chat(f"👊 مشت به {count} نفر زده شد.")
            return

        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !punch @username  یا  !punch all")
            return
        target = parts[1][1:].lower()
        target_user = self.active_users.get(target)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target} توی روم نیست.")
            return
        try:
            await self.highrise.send_emote("emote-superpunch", target_user.id)
            await self.highrise.chat(f"👊 @{target} مشت خورد!")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا: {e}")

    async def _cmd_clown(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !clown @username")
            return
        target = parts[1][1:].lower()
        target_user = self.active_users.get(target)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target} توی روم نیست.")
            return
        try:
            await self.highrise.send_emote("emote-laughing2", target_user.id)
            await self.highrise.chat(f"🤡 @{target} دلقک شد!")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا: {e}")

    # ── زندان (jail) ───────────────────────────────────────────────

    async def _jail_user(self, admin: User, target: str, minutes: int):
        self._init_mod_state()
        target_user = self.active_users.get(target)
        if not target_user:
            await self.highrise.chat(f"❌ کاربر @{target} توی روم نیست.")
            return
        jail_loc = self.config.get("teleport_locations", {}).get("jail")
        if not jail_loc:
            await self.highrise.chat(
                "❌ مکان زندان تنظیم نشده. اول با !addtele jail یه مکان ذخیره کن."
            )
            return
        try:
            dest = Position(x=jail_loc["x"], y=jail_loc["y"], z=jail_loc["z"])
            await self.highrise.teleport(user_id=target_user.id, dest=dest)
        except Exception as e:
            await self.highrise.chat(f"❌ خطا در تبعید: {e}")
            return

        old_task = self._jailed_users.get(target)
        if old_task and not old_task.done():
            old_task.cancel()

        async def _release_later():
            try:
                await sleep(minutes * 60)
                self._jailed_users.pop(target, None)
                await self.highrise.chat(f"⛓️ زمان زندان @{target} تموم شد.")
            except CancelledError:
                pass

        self._jailed_users[target] = create_task(_release_later())
        await self.highrise.chat(f"⛓️ @{target} برای {minutes} دقیقه به زندان تبعید شد.")
        if hasattr(self, "_mod_log"):
            await self._mod_log("زندان", target, admin.username, f"{minutes} دقیقه")

    async def _cmd_jail(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه تبعید کنه.")
            return
        parts = message.strip().split()
        if len(parts) < 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !jail @username [دقیقه]")
            return
        target = parts[1][1:].lower()
        minutes = 5
        if len(parts) >= 3 and parts[2].isdigit():
            minutes = max(1, int(parts[2]))
        await self._jail_user(user, target, minutes)

    async def _cmd_unjail(self, user: User, message: str):
        self._init_mod_state()
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه آزاد کنه.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or not parts[1].startswith("@"):
            await self.highrise.chat("فرمت: !unjail @username")
            return
        target = parts[1][1:].lower()
        task = self._jailed_users.pop(target, None)
        if task and not task.done():
            task.cancel()
        await self.highrise.chat(f"⛓️ @{target} زودتر از زندان آزاد شد.")

    # ── VIP ───────────────────────────────────────────────────────

    async def _cmd_vip_args(self, user: User, message: str):
        await self.highrise.chat(
            "⭐ مزایای VIP:\n"
            "• تلپورت آزاد به مکان‌های VIP (!vip، !vip1)\n"
            "• اولویت در صف رادیو نئون\n"
            "• نشان ⭐ در راهنما و اعلان‌ها\n"
            "برای گرفتن VIP موقت با ادمین صحبت کن."
        )

    async def _cmd_vip_list(self, user: User, message: str):
        vips = self.config.get("vip_usernames", [])
        temp = list(getattr(self, "_tempvip_tasks", {}).keys())
        lines = ["⭐ کاربران VIP:"]
        lines += [f"  • @{n}" for n in vips] or ["  (خالی)"]
        if temp:
            lines.append("⏳ VIP موقت:")
            lines += [f"  • @{n}" for n in temp]
        await self.highrise.chat("\n".join(lines))

    # ── ابزارهای ادمین ────────────────────────────────────────────

    async def _cmd_come(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه بات رو احضار کنه.")
            return
        admin_pos = self.user_positions.get(user.username.lower())
        if not admin_pos:
            await self.highrise.chat("❌ موقعیت شما در دسترس نیست.")
            return
        try:
            dest = Position(x=admin_pos.x, y=admin_pos.y, z=admin_pos.z)
            await self.highrise.teleport(user_id=self.user_id, dest=dest)
            await self.highrise.chat(f"🤖 بات پیش @{user.username} اومد.")
        except Exception as e:
            await self.highrise.chat(f"❌ خطا: {e}")

    async def _cmd_tp_toggle(self, user: User, message: str):
        if not self._is_admin(user):
            await self.highrise.chat("❌ فقط ادمین می‌تونه این تنظیم رو تغییر بده.")
            return
        parts = message.strip().split()
        if len(parts) != 2 or parts[1].lower() not in ("on", "off"):
            await self.highrise.chat("فرمت: !tp on  یا  !tp off")
            return
        enabled = parts[1].lower() == "on"
        self.ext_config["tp_enabled"] = enabled
        self._save_ext_config()
        await self.highrise.chat(
            "✅ سیستم تلپورت فعال شد." if enabled else "⛔ سیستم تلپورت غیرفعال شد."
        )

    async def _cmd_ban_music(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه آهنگ بن کنه.")
            return
        parts = message.strip().split(maxsplit=1)
        if len(parts) != 2:
            await self.highrise.chat("فرمت: !ban-music <شناسه یا نام آهنگ>")
            return
        song = parts[1].strip()
        banned = self.ext_config.setdefault("banned_songs", [])
        song_key = song.upper() if song.upper() in self._radio_tracks else song
        if song_key not in banned:
            banned.append(song_key)
            self._save_ext_config()
        # اگه همین الان توی صفه، حذفش کن
        self._radio_queue = [t for t in self._radio_queue if t != song_key]
        if self._radio_current == song_key:
            self._radio_current = None
            self._radio_playing = False
        self._save_ext_config()
        await self.highrise.chat(f"🚫 آهنگ «{song}» به لیست سیاه رادیو اضافه شد.")

    async def _cmd_unban_music(self, user: User, message: str):
        if not self._is_staff(user):
            await self.highrise.chat("❌ فقط ادمین/ناظر می‌تونه از این دستور استفاده کنه.")
            return
        parts = message.strip().split(maxsplit=1)
        if len(parts) != 2:
            await self.highrise.chat("فرمت: !unban-music <شناسه یا نام آهنگ>")
            return
        song = parts[1].strip()
        banned = self.ext_config.setdefault("banned_songs", [])
        song_key = song.upper() if song.upper() in banned else song
        if song_key in banned:
            banned.remove(song_key)
            self._save_ext_config()
            await self.highrise.chat(f"✅ آهنگ «{song}» از لیست سیاه خارج شد.")
        else:
            await self.highrise.chat("این آهنگ توی لیست سیاه نیست.")
