"""
دنس‌های بات دوستت (۴۰۶ دنس) جایگزین دنس‌های عددی قبلی می‌شن.
- شماره ۱ تا ۴۰۶  → دنس دوستت
- اسم دنس هم کار می‌کنه (مثلاً: tiktok)
- کلیدهای اسمیِ قبلی که بخش‌های دیگه‌ی بات لازم دارن (مثل posing) دست‌نخورده می‌مونن
- سیستم !emote <لینک high.rs> هم مثل قبل کار می‌کنه
"""
import json
import os

_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "friend_dances.json")


def apply_friend_dances(bot) -> int:
    try:
        with open(_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return 0  # اگه فایل خونده نشد، دنس‌های قبلی سر جاشون می‌مونن

    # دنس‌های عددی قبلی رو حذف کن، کلیدهای اسمی (مورد نیاز بقیه‌ی سیستم‌ها) بمونن
    kept = {k: v for k, v in bot.emotes.items() if not str(k).isdigit()}
    new_emotes = {}
    durations = {}
    for num, item in data.items():
        emote_id = item.get("id")
        if not emote_id:
            continue
        new_emotes[str(num)] = emote_id
        try:
            durations[emote_id] = float(item.get("duration", 7.5))
        except Exception:
            durations[emote_id] = 7.5

    names = {}
    for item in data.values():
        name = str(item.get("name", "")).strip().lower()
        if name and name != "stop" and name not in kept and name not in names \
                and not name.isdigit() and item.get("id"):
            names[name] = item["id"]

    bot.emotes = {**kept, **new_emotes}
    for name, emote_id in names.items():
        bot.emotes.setdefault(name, emote_id)
    bot.emote_durations = durations  # مدت‌ها هم مال دنس‌های دوستته
    bot.friend_dance_count = len(new_emotes)
    return len(new_emotes)
