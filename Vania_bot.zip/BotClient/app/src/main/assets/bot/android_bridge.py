"""Runs each managed bot in its own Android process ("slot") instead of a subprocess."""
import json
import os
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SLOT_DIR = os.path.join(BASE_DIR, "slots")
MAX_SLOTS = 6
_ctx = None


def set_context(ctx):
    global _ctx
    _ctx = ctx
    os.makedirs(SLOT_DIR, exist_ok=True)


def _assign_path(i):
    return os.path.join(SLOT_DIR, f"slot{i}.json")


def _hb_path(i):
    return os.path.join(SLOT_DIR, f"slot{i}.hb")


def _read(i):
    try:
        with open(_assign_path(i), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def find_slot(name):
    for i in range(MAX_SLOTS):
        d = _read(i)
        if d and d.get("name") == name:
            return i
    return None


def _free_slot():
    for i in range(MAX_SLOTS):
        if _read(i) is None:
            return i
    return None


def _launcher():
    from java import jclass
    return jclass("ir.botclient.SlotLauncher")


def start_slot(name, token, room_id, owner, role="normal"):
    i = find_slot(name)
    if i is None:
        i = _free_slot()
        if i is None:
            raise RuntimeError(f"All {MAX_SLOTS} bot slots are in use")
    tmp = _assign_path(i) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"name": name, "token": token, "room_id": room_id, "owner": owner, "role": role}, f)
    os.replace(tmp, _assign_path(i))
    _launcher().start(_ctx, i)


def is_alive(name):
    i = find_slot(name)
    if i is None:
        return False
    try:
        return time.time() - os.path.getmtime(_hb_path(i)) < 25
    except OSError:
        return False


def stop_slot(name):
    i = find_slot(name)
    if i is None:
        return
    for p in (_assign_path(i), _hb_path(i)):
        try:
            os.remove(p)
        except OSError:
            pass
    _launcher().stop(_ctx, i)
