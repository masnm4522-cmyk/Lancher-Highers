package ir.botclient

import android.content.Intent
import com.chaquo.python.Python

/** One foreground Python runtime hosts the launcher's dynamically sized bot list. */
class FleetService : BaseService(2, "Highrise Bot Fleet") {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (worker?.isAlive != true) {
            try {
                Paths.installAssets(this)
                val dir = Paths.botDir(this).absolutePath
                val service = this
                worker = Thread({
                    try {
                        Python.getInstance().getModule("glue").callAttr("run_fleet", dir)
                    } catch (e: Throwable) {
                        android.util.Log.e("BotClient", "fleet crashed", e)
                        Diag.log(service, "❌ خطای سرویس بات‌ها: ${e.javaClass.simpleName}")
                    }
                }, "fleet-py").also { it.start() }
            } catch (e: Throwable) {
                Diag.log(this, "❌ خطا در آماده‌سازی سرویس بات‌ها: ${e.javaClass.simpleName}")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }
}
