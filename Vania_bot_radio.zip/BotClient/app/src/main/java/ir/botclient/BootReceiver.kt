package ir.botclient

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Prefs.wantRunning(ctx)) ctx.startForegroundService(Intent(ctx, ManagerService::class.java))
        if (Prefs.wantFleet(ctx)) ctx.startForegroundService(Intent(ctx, FleetService::class.java))
    }
}
