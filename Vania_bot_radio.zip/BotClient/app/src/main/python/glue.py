"""Entry points called from Kotlin (Chaquopy)."""
import asyncio
import json
import logging
import os
import sys
import threading
import time
from logging.handlers import RotatingFileHandler


def _prepare(bot_dir):
    os.makedirs(bot_dir, exist_ok=True)
    os.chdir(bot_dir)
    if bot_dir not in sys.path:
        sys.path.insert(0, bot_dir)
    # asyncio signal handlers only work on the main thread; we run in a worker thread.
    try:
        import asyncio.unix_events as ue
        ue._UnixSelectorEventLoop.add_signal_handler = lambda self, *a, **k: None
    except Exception:
        pass


def _setup_logging(path):
    handler = RotatingFileHandler(path, maxBytes=1_000_000, backupCount=1, encoding="utf-8")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[handler],
        force=True,
    )


def _dump(bot_dir, name):
    import traceback
    try:
        with open(os.path.join(bot_dir, name), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " [PY] ❌ خطا:\n" + traceback.format_exc() + "\n")
    except Exception:
        pass


def _log_versions(log):
    try:
        from importlib import metadata
        names = ["highrise-bot-sdk", "aiohttp", "aiosignal", "typing-extensions", "pendulum",
                 "frozenlist", "multidict", "yarl", "websockets", "quattro", "attrs", "cattrs"]
        out = []
        for n in names:
            try:
                out.append(f"{n}=={metadata.version(n)}")
            except Exception:
                out.append(f"{n}=?")
        log.info("📦 " + ", ".join(out))
    except Exception:
        pass


def run_manager(bot_dir, token, room, owner, ctx):
    try:
        _prepare(bot_dir)
        os.environ["MANAGER_TOKEN"] = token
        os.environ["MANAGER_ROOM"] = room
        os.environ["OWNER_USERNAME"] = owner
        _setup_logging(os.path.join(bot_dir, "manager.log"))
        log = logging.getLogger("glue")
        log.info("▶ پایتون بالا اومد، در حال بارگذاری مدیر...")
        _log_versions(log)
        import android_bridge
        android_bridge.set_context(ctx)
        import feature_flags
        if not feature_flags.BOT_MAKER_ENABLED:
            # ربات‌ساز غیرفعاله: توکنِ لانچر مستقیم همون بات اصلی (Vania) رو اجرا می‌کنه
            os.environ["API_TOKEN"] = token
            os.environ["ROOM_ID"] = room
            os.environ["BOT_NAME"] = "Vania"
            os.environ["BOT_ROLE"] = "normal"
            log.info("▶ ربات‌ساز غیرفعاله؛ بات اصلی Vania مستقیم اجرا می‌شه...")
            import extended_serve2
            log.info("✔ بات بارگذاری شد")
            asyncio.run(extended_serve2.main())
            log.error("❌ بات بدون خطا تموم شد (نباید اتفاق بیفته)")
            return
        import bot_manager
        log.info("✔ مدیر بارگذاری شد")
        asyncio.run(bot_manager.main())
        log.error("❌ مدیر بدون خطا تموم شد (نباید اتفاق بیفته)")
    except BaseException:
        _dump(bot_dir, "manager.log")
        raise


def run_fleet(bot_dir):
    """Run every enabled launcher profile in one independently managed service."""
    try:
        _prepare(bot_dir)
        _setup_logging(os.path.join(bot_dir, "fleet.log"))
        logger = logging.getLogger("fleet")
        logger.info("▶ سرویس بات‌های لانچر آماده است.")
        import asyncio
        import fleet
        asyncio.run(fleet.run_fleet(bot_dir))
    except BaseException:
        _dump(bot_dir, "fleet.log")
        raise


def run_bot(bot_dir, slot):
    try:
        _prepare(bot_dir)
        slots = os.path.join(bot_dir, "slots")
        with open(os.path.join(slots, f"slot{slot}.json"), "r", encoding="utf-8") as f:
            a = json.load(f)
        os.environ["API_TOKEN"] = a["token"]
        os.environ["ROOM_ID"] = a["room_id"]
        os.environ["BOT_NAME"] = a["name"]
        os.environ["BOT_ROLE"] = a.get("role", "normal")
        if a.get("owner"):
            os.environ["OWNER_USERNAME"] = a["owner"]
        _setup_logging(os.path.join(bot_dir, f"{a['name']}.log"))
        logging.getLogger("glue").info("Starting bot %s...", a["name"])

        hb = os.path.join(slots, f"slot{slot}.hb")

        def beat():
            while True:
                try:
                    with open(hb, "w") as f:
                        f.write(str(time.time()))
                except OSError:
                    pass
                time.sleep(5)

        threading.Thread(target=beat, daemon=True).start()
        try:
            import extended_serve2
            asyncio.run(extended_serve2.main())
        except BaseException:
            logging.getLogger("glue").exception("ERROR bot crashed")
            raise
    except BaseException:
        _dump(bot_dir, "slot_error.log")
        raise
