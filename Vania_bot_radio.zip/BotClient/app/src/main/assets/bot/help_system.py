"""
سیستم راهنمای یکپارچه.

همه‌ی دستورات ربات از یک فایل متنی (commands.txt) خونده می‌شن و با
!help یا !exthelp یک‌جا (نه صفحه‌به‌صفحه) نمایش داده می‌شن. برای ویرایش
راهنما فقط کافیه commands.txt رو عوض کنی، نیازی به دست‌زدن به کد نیست.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
COMMANDS_FILE = os.path.join(BASE_DIR, "commands.txt")

_PAGE_MARKER = "===PAGE "
_PAGE_END = "===\n"
_HELP_MESSAGE_LIMIT = 300


def _split_help_text(text: str, limit: int = _HELP_MESSAGE_LIMIT) -> list[str]:
    """Split help at line boundaries and repeat the active section on continuation."""
    chunks = []
    current_lines = []
    current_length = 0
    section_heading = None

    def flush():
        nonlocal current_lines, current_length
        chunk = "\n".join(current_lines).strip()
        if chunk:
            chunks.append(chunk)
        current_lines = []
        current_length = 0

    def add_line(line: str, repeat_section: bool = True):
        nonlocal current_length
        if not line.strip():
            return
        parts = [line[i:i + limit] for i in range(0, len(line), limit)] or [""]
        for part in parts:
            if not part and not current_lines:
                continue
            needed = len(part) + (1 if current_lines else 0)
            if current_lines and current_length + needed > limit:
                flush()
                if repeat_section and section_heading and part.strip():
                    continuation = f"{section_heading} (ادامه)"
                    current_lines.append(continuation)
                    current_length = len(continuation)
                    needed = len(part) + 1
            if current_lines:
                current_length += 1 + len(part)
            else:
                current_length = len(part)
            current_lines.append(part)

    for line in text.splitlines():
        if "˚ˑ˚" in line and "✨" not in line:
            flush()
            section_heading = line.strip()
            add_line(line, repeat_section=False)
        else:
            add_line(line)
    flush()
    return chunks


class HelpSystemMixin:

    def _load_help_pages(self):
        cached = getattr(self, "_help_pages_cache", None)
        if cached is not None:
            return cached

        pages = {}
        try:
            with open(COMMANDS_FILE, "r", encoding="utf-8") as f:
                content = f.read()
            blocks = content.split(_PAGE_MARKER)
            for block in blocks[1:]:
                header, sep, body = block.partition(_PAGE_END)
                if not sep:
                    continue
                page_id = header.strip()
                pages[page_id] = body.strip()
        except FileNotFoundError:
            pages = {}
        except Exception:
            pages = {}

        self._help_pages_cache = pages
        return pages

    async def _send_help_text(self, text: str):
        # متن را روی مرز خطوط می‌بریم تا دستور نصف نشود؛ عنوان دسته در ادامه تکرار می‌شود.
        for chunk in _split_help_text(text):
            await self.highrise.chat(chunk)

    async def _cmd_help_unified(self, user, message: str):
        pages = self._load_help_pages()
        text = pages.get("all")
        if not text:
            await self.highrise.chat(
                "❌ فایل راهنما (commands.txt) پیدا نشد یا خالیه."
            )
            return
        await self._send_help_text(text)
