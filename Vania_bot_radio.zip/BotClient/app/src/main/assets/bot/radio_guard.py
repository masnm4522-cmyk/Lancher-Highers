# -*- coding: utf-8 -*-
"""
🛡️ حالت نگهبان: بات مثل یک آدم توی روم می‌چرخد.

  • به بازیکن‌ها سلام می‌دهد (کنارشان می‌رود، دست تکان می‌دهد، اسمشان را می‌نویسد)
  • این‌ور و آن‌ور قدم می‌زند (فقط جاهایی که بازیکن‌ها ایستاده‌اند؛ پس توی دیوار نمی‌رود)
  • گاهی می‌نشیند، گاهی دنس می‌کند
  • هر چند دقیقه اعلام می‌کند «من نگهبان روم‌ام»

  !guard                    وضعیت
  !guard on | off           روشن/خاموش
  !guard speed slow|normal|fast   سرعت حرکت
  !guard greet on | off     سلام‌کردن به بازیکن‌ها
  !guard text <متن>         متن اعلام نگهبان (text reset ← پیش‌فرض)
  !guard now                همین الان اعلام کن
"""
import os
import random
import time
import asyncio
import logging

from highrise import Position
from persistent_store import load_json, save_json

logger = logging.getLogger(__name__)

_GUARD_COMMANDS = ("!guard", "!نگهبان")

_DEFAULTS = {"enabled": None, "speed": "normal", "greet": True, "text": "", "intro_minutes": 12, "greet_minutes": 5}
_PACE = {"slow": (25, 45), "normal": (14, 30), "fast": (8, 16)}

_GREETINGS = [
    "👋 سلام @{n} خوش اومدی! من نگهبان روم‌ام 🛡️",
    "سلام @{n} ✨ اگه سوالی داشتی از من بپرس، نگهبان روم‌ام 🛡️",
    "🛡️ @{n} عزیز سلام! با !radiohelp دستورهای رادیو رو ببین 🎧",
    "چطوری @{n}؟ خوش می‌گذره؟ 😎",
    "@{n} سلام! امشب هم سر پام، مشکلی بود بگو 🛡️",
]
_INTROS = [
    "🛡️ من نگهبان این روم‌م! مشکلی بود بگو، حواسم به همه هست 😎",
    "🛡️ نگهبان روم اینجاست؛ احترام و آرامش یادتون نره ✨",
    "👀 دارم روم رو چک می‌کنم... همه‌چیز آرومه! 🛡️",
]
_HELLO = ("emote-hello", "emote-wave")
_SALUTE = ("emote-salute", "emote-cutesalute", "emote-bow")
_SIT = ("idle-loop-sitfloor",)
_DANCES = ("dance-floss", "dance-macarena", "dance-tiktok2", "dance-shoppingcart",
           "dance-blackpink", "dance-handsup", "dance-aerobics")


class RadioGuardMixin:
    # ─── تنظیمات ───────────────────────────────────────────────
    def _guard_path(self):
        return os.path.join(os.path.dirname(os.path.abspath(self.ext_config_file)), "radio_guard.json")

    def _guard_cfg(self):
        cfg = dict(_DEFAULTS)
        data = load_json(self._guard_path(), {})
        if isinstance(data, dict):
            cfg.update({k: data[k] for k in _DEFAULTS if k in data})
        if cfg["enabled"] is None:
            cfg["enabled"] = not getattr(self, "_music_bot", False)   # بات موزیک پیش‌فرض نمی‌چرخد
        if cfg["speed"] not in _PACE:
            cfg["speed"] = "normal"
        for key, lo, hi, dflt in (("intro_minutes", 2, 120, 12), ("greet_minutes", 1, 240, 5)):
            try:
                cfg[key] = min(hi, max(lo, int(cfg[key])))
            except (TypeError, ValueError):
                cfg[key] = dflt
        return cfg

    def _guard_set(self, **changes):
        cfg = self._guard_cfg()
        cfg.update(changes)
        save_json(self._guard_path(), cfg)
        self._guard_active = bool(cfg["enabled"])
        return cfg

    # ─── ابزارهای حرکت ─────────────────────────────────────────
    def _guard_emote_ok(self, emote):
        known = getattr(self, "emote_durations", None) or {}
        return (not known) or emote in known

    async def _guard_emote(self, choices, default_wait=4.0):
        options = [e for e in choices if self._guard_emote_ok(e)] or list(choices)
        emote = random.choice(options)
        try:
            await self.highrise.send_emote(emote, self.user_id)
        except Exception as exc:
            logger.debug(f"نگهبان: ایموت {emote} اجرا نشد: {exc}")
            return 0.0
        wait = (getattr(self, "emote_durations", None) or {}).get(emote, default_wait)
        return min(float(wait), 15.0)

    async def _guard_users(self):
        resp = await self.highrise.get_room_users()
        users = []
        for user, pos in (resp.content if hasattr(resp, "content") else []):
            if user.id == self.user_id:
                if hasattr(pos, "x"):
                    self._guard_me = pos
                continue
            users.append((user, pos))
            if hasattr(pos, "x"):                       # نشسته‌ها (AnchorPosition) x ندارند
                key = (round(pos.x), round(pos.z))
                self._guard_points[key] = (pos.x, pos.y, pos.z)
                if len(self._guard_points) > 80:
                    self._guard_points.pop(next(iter(self._guard_points)))
        return users

    async def _guard_walk(self, x, y, z):
        me = getattr(self, "_guard_me", None)
        dist = ((me.x - x) ** 2 + (me.z - z) ** 2) ** 0.5 if me is not None else 6.0
        try:
            await self.highrise.walk_to(Position(x=x, y=y, z=z, facing="FrontRight"))
        except Exception as exc:
            logger.debug(f"نگهبان: راه رفتن ناموفق: {exc}")
            return
        self._guard_me = Position(x=x, y=y, z=z)
        await asyncio.sleep(min(10.0, max(1.5, dist / 3.5 + 0.8)))

    async def _guard_say(self, text):
        if not getattr(self, "_bot_silent", False):
            await self.highrise.chat(text)

    # ─── کارها ─────────────────────────────────────────────────
    async def _guard_greet(self, user, pos):
        if hasattr(pos, "x"):
            dx, dz = random.choice([(1.2, 0), (-1.2, 0), (0, 1.2), (0, -1.2), (0.9, 0.9), (-0.9, -0.9)])
            await self._guard_walk(pos.x + dx, pos.y, pos.z + dz)
        wait = await self._guard_emote(_HELLO)
        self._guard_greeted[user.username.lower()] = time.monotonic()
        await self._guard_say(random.choice(_GREETINGS).format(n=user.username))
        await asyncio.sleep(wait)

    async def _guard_patrol(self):
        points = list(self._guard_points.values())
        me = getattr(self, "_guard_me", None)
        if me is not None:
            far = [p for p in points if (p[0] - me.x) ** 2 + (p[2] - me.z) ** 2 > 4]
            points = far or points
        if not points:
            return
        x, y, z = random.choice(points)
        await self._guard_walk(x, y, z)
        if random.random() < 0.35:
            await asyncio.sleep(await self._guard_emote(_SALUTE))

    async def _guard_dance(self):
        for _ in range(random.choice((1, 1, 2))):
            await asyncio.sleep(await self._guard_emote(_DANCES, 9.0) + 0.3)

    async def _guard_sit(self):
        await self._guard_emote(_SIT, 3.0)
        await asyncio.sleep(random.uniform(20, 40))
        me = getattr(self, "_guard_me", None)
        if me is not None:                               # با یک قدم کوچک بلند می‌شود
            await self._guard_walk(me.x + 0.5, me.y, me.z)

    async def _guard_intro(self, cfg):
        await self._guard_patrol()
        await asyncio.sleep(await self._guard_emote(_SALUTE))
        await self._guard_say((cfg["text"] or "").strip() or random.choice(_INTROS))
        self._guard_last_intro = time.monotonic()

    async def _guard_step(self, cfg):
        users = await self._guard_users()
        if not users:
            return
        now = time.monotonic()
        seen = self._guard_greeted
        never = [(u, p) for u, p in users if u.username.lower() not in seen]
        stale = [(u, p) for u, p in users if now - seen.get(u.username.lower(), now) > cfg["greet_minutes"] * 60]
        roll = random.random()
        if cfg["greet"] and never and roll < 0.9:
            return await self._guard_greet(*random.choice(never))
        if now - self._guard_last_intro > cfg["intro_minutes"] * 60:
            return await self._guard_intro(cfg)
        if cfg["greet"] and stale and roll < 0.7:
            return await self._guard_greet(*random.choice(stale))
        action = random.choices(("patrol", "dance", "sit"), weights=(60, 25, 15))[0]
        await getattr(self, "_guard_" + action)()

    # ─── لوپ ───────────────────────────────────────────────────
    async def _guard_loop(self):
        await asyncio.sleep(25)
        self._guard_points, self._guard_greeted = {}, {}
        self._guard_last_intro = time.monotonic()
        while True:
            pace = _PACE["normal"]
            try:
                cfg = self._guard_cfg()
                self._guard_active = bool(cfg["enabled"])
                pace = _PACE[cfg["speed"]]
                if cfg["enabled"] and self.user_id:
                    await self._guard_step(cfg)
            except asyncio.CancelledError:
                self._guard_active = False
                return
            except Exception as exc:
                logger.debug(f"لوپ نگهبان: {exc}")
            await asyncio.sleep(random.uniform(*pace))

    # ─── دستور !guard (مدیر) ───────────────────────────────────
    async def _cmd_guard(self, user, message):
        if not self._is_admin(user):
            return await self.highrise.chat("⛔ این دستور فقط برای مدیر است.")
        parts = message.strip().split(maxsplit=2)
        sub = parts[1].lower() if len(parts) > 1 else ""
        rest = parts[2].strip() if len(parts) > 2 else ""
        cfg = self._guard_cfg()

        if not sub:
            return await self.highrise.chat(
                f"🛡️ نگهبان: {'روشن ✅' if cfg['enabled'] else 'خاموش ⛔'} | سرعت: {cfg['speed']} | "
                f"سلام: {'روشن' if cfg['greet'] else 'خاموش'}\n"
                "!guard on/off | speed slow/normal/fast | greet on/off | greettime 5 | text متن | now"
            )
        if sub in ("on", "off"):
            self._guard_set(enabled=(sub == "on"))
            return await self.highrise.chat(
                "🛡️ نگهبان روشن شد؛ می‌رم دور بزنم!" if sub == "on" else "🛡️ نگهبان خاموش شد."
            )
        if sub == "speed":
            if rest.lower() not in _PACE:
                return await self.highrise.chat("سرعت: slow (آرام) | normal | fast (تند)")
            self._guard_set(speed=rest.lower())
            return await self.highrise.chat(f"✅ سرعت نگهبان: {rest.lower()}")
        if sub == "greet":
            if rest.lower() not in ("on", "off"):
                return await self.highrise.chat("فرمت: !guard greet on | off")
            self._guard_set(greet=(rest.lower() == "on"))
            return await self.highrise.chat("✅ سلام‌کردن " + ("روشن شد." if rest.lower() == "on" else "خاموش شد."))
        if sub == "greettime":
            try:
                minutes = int(rest)
            except ValueError:
                return await self.highrise.chat("فرمت: !guard greettime 5 (دقیقه)")
            if not 1 <= minutes <= 240:
                return await self.highrise.chat("عدد باید بین ۱ تا ۲۴۰ دقیقه باشد.")
            self._guard_set(greet_minutes=minutes)
            return await self.highrise.chat(f"✅ هر نفر را هر {minutes} دقیقه دوباره سلام می‌کنم.")
        if sub == "text":
            if not rest:
                return await self.highrise.chat("فرمت: !guard text متن | !guard text reset")
            self._guard_set(text="" if rest.lower() == "reset" else rest[:200])
            return await self.highrise.chat("✅ متن نگهبان عوض شد." if rest.lower() != "reset" else "✅ متن پیش‌فرض برگشت.")
        if sub == "now":
            if not hasattr(self, "_guard_points"):
                self._guard_points, self._guard_greeted, self._guard_last_intro = {}, {}, 0
            await self._guard_users()
            return await self._guard_intro(cfg)
        return await self.highrise.chat("دستور نامعلوم؛ !guard را تنها بزن.")
