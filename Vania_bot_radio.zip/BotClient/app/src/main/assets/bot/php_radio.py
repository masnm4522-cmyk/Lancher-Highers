# -*- coding: utf-8 -*-
"""
کنترل رادیوی srsamp.ir (stream.php) از داخل بات.

  !p  <لینک | شماره | اسم>   پخش فوری           (ادمین)
  !q  <لینک | شماره | اسم>   رفتن به صف          (همه) — بدون ورودی: نمایش صف
  !next / !n                 آهنگ بعدی            (ادمین)
  !prev / !previous          آهنگ قبلی            (ادمین)
  !musiclist [صفحه]          فهرست آهنگ‌های حافظه‌ی سرور (شماره‌دار)
  !radio [status|clear|...]  وضعیت، پاک‌کردن صف و ...

وقتی صف خالی باشد خود stream.php آهنگ‌های پوشه‌ی سرور را پشت‌سرهم پخش می‌کند.
اگر radio_config.json تنظیم نشده باشد، همه‌چیز مثل قبل (روش قدیمی) کار می‌کند.
"""
import os
import time
import asyncio
import logging

import aiohttp
from persistent_store import load_json

logger = logging.getLogger(__name__)

_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_FILE = os.path.join(_DIR, "radio_config.json")
_PLACEHOLDER = "PUT_YOUR_TOKEN_HERE"

_PHP_COMMANDS = (
    "!radio", "!music", "!song", "!p", "!q", "!n", "!next",
    "!play", "!prev", "!previous", "!musiclist",
)


def _mmss(sec):
    try:
        sec = max(0, int(sec))
    except (TypeError, ValueError):
        return "؟"
    return f"{sec // 60}:{sec % 60:02d}"


class PhpRadioMixin:
    # ─── تنظیمات ───────────────────────────────────────────────
    def _php_cfg(self):
        data = load_json(CFG_FILE, {})
        if not isinstance(data, dict):
            data = {}
        api = str(data.get("api_url", "")).strip()
        token = str(data.get("token", "")).strip()
        if token == _PLACEHOLDER:
            token = ""
        return {
            "api_url": api,
            "token": token,
            "stream_url": str(data.get("stream_url", "")).strip() or api,
        }

    def _php_ready(self):
        cfg = self._php_cfg()
        return bool(cfg["api_url"] and cfg["token"])

    def _php_quiet(self, secs=8):
        self._php_quiet_until = time.time() + secs

    # ─── ارتباط با API ─────────────────────────────────────────
    async def _php_api(self, api, payload=None, timeout=20):
        """(http_status, dict|None) — خطای شبکه یعنی (0, None)."""
        cfg = self._php_cfg()
        if not (cfg["api_url"] and cfg["token"]):
            return 0, None
        headers = {"X-Control-Token": cfg["token"]}
        try:
            async with aiohttp.ClientSession() as session:
                kwargs = {"headers": headers, "timeout": aiohttp.ClientTimeout(total=timeout)}
                if payload is None:
                    req = session.get(cfg["api_url"], params={"api": api}, **kwargs)
                else:
                    req = session.post(cfg["api_url"], params={"api": api}, json=payload, **kwargs)
                async with req as resp:
                    try:
                        data = await resp.json(content_type=None)
                    except Exception:
                        data = None
                    return resp.status, data if isinstance(data, dict) else None
        except Exception as exc:
            logger.warning(f"رادیو: ارتباط با {api} ناموفق بود: {exc}")
            return 0, None

    async def _php_say(self, text):
        """چت هایرایز حداکثر ۲۵۶ کاراکتر است؛ متن را خط‌به‌خط تکه می‌کنیم."""
        chunk = ""
        for line in str(text).split("\n"):
            if chunk and len(chunk) + len(line) + 1 > 230:
                await self.highrise.chat(chunk)
                chunk = ""
            chunk = f"{chunk}\n{line}" if chunk else line[:230]
        if chunk:
            await self.highrise.chat(chunk)

    async def _php_status_data(self):
        code, data = await self._php_api("status", timeout=8)
        return data if code == 200 and data else {}

    # ─── کارهای سطح‌پایین (برای کدهای قدیمی بات هم استفاده می‌شود) ──
    async def _php_search(self, query):
        code, data = await self._php_api("search", {"query": query, "limit": 5}, timeout=15)
        results = (data or {}).get("results", [])
        return results if code == 200 and isinstance(results, list) else []

    async def _php_wait_job(self, job, timeout=90):
        """منتظر می‌ماند تا آهنگ لینکی دانلود و تبدیل شود. True = آماده شد."""
        end = time.time() + timeout
        while time.time() < end:
            await asyncio.sleep(2)
            st = await self._php_status_data()
            state = ((st.get("jobs") or {}).get(job) or {}).get("state")
            if state == "ready":
                return True
            if state == "error":
                return False
        return False

    async def _php_push(self, source, title="", mode="play"):
        """پخش/صف‌کردن یک لینک (یا lib://id). خروجی: (ok, عنوان، پیام خطا)."""
        body = {"url": source}
        if title:
            body["title"] = title
        code, data = await self._php_api(mode, body)
        if code != 200 or not data or not data.get("ok"):
            err = (data or {}).get("error") or "سرور رادیو جواب نداد"
            return False, title, err
        name = data.get("title") or title or "آهنگ"
        if data.get("state") == "preparing":
            await self._php_say(f"⏳ دارم «{name}» را آماده می‌کنم...")
            if not await self._php_wait_job(data.get("job", "")):
                return False, name, "دانلود یا تبدیل آهنگ ناموفق بود (لینک مستقیم mp3 بهتر است)"
        return True, name, ""

    # ─── کمک‌های دستورها ───────────────────────────────────────
    async def _php_resolve(self, arg):
        """لینک ← url ، عدد ← شماره‌ی کتابخانه ، متن ← جستجو. None = پیدا نشد."""
        arg = arg.strip()
        if self._looks_like_link(arg):
            return {"url": arg}
        if arg.isdigit():
            return {"n": int(arg)}
        results = await self._php_search(arg)
        if results:
            first = results[0]
            return {"url": first.get("url") or first.get("webpage_url"), "title": first.get("title", "")}
        return None

    async def _php_start(self, mode, arg):
        target = await self._php_resolve(arg)
        if not target:
            await self.highrise.chat("❌ آهنگی با این نام پیدا نشد. لینک بفرست یا !musiclist بزن.")
            return
        code, data = await self._php_api(mode, target)
        if code != 200 or not data or not data.get("ok"):
            await self.highrise.chat(f"❌ {(data or {}).get('error') or 'سرور رادیو جواب نداد'}")
            return
        name = data.get("title") or target.get("title") or "آهنگ"
        if data.get("state") == "preparing":
            await self._php_say(f"⏳ دارم «{name}» را آماده می‌کنم...")
            if not await self._php_wait_job(data.get("job", "")):
                await self.highrise.chat("❌ دانلود یا تبدیل آهنگ ناموفق بود؛ لینک مستقیم mp3 امتحان کن.")
                return
        self._php_quiet()
        await self.highrise.chat(
            f"🎶 الان پخش می‌شود: {name}" if mode == "play" else f"✅ به صف اضافه شد: {name}"
        )

    async def _php_show_status(self):
        st = await self._php_status_data()
        if not st:
            await self.highrise.chat("⚠️ سرور رادیو جواب نداد.")
            return
        lines = []
        if st.get("playing"):
            lines.append(
                f"🎧 در حال پخش: {st.get('now_playing_title')} "
                f"({_mmss(st.get('elapsed_seconds'))}/{_mmss(st.get('now_playing_duration_seconds'))})"
            )
        else:
            lines.append("⏸ الان چیزی پخش نمی‌شود.")
        if st.get("next_title"):
            lines.append(f"⏭ بعدی: {st['next_title']}")
        queue = st.get("queue") or []
        if queue:
            lines.append("🧾 صف: " + " | ".join(f"{i}) {t}" for i, t in enumerate(queue[:5], 1)))
        lines.append(f"📚 آهنگ‌های سرور: {st.get('library_count', 0)}")
        lines.append("!p لینک | !q لینک | !next | !prev | !musiclist")
        await self._php_say("\n".join(lines))

    async def _php_show_queue(self):
        st = await self._php_status_data()
        queue = (st or {}).get("queue") or []
        if not queue:
            await self.highrise.chat("🧾 صف خالی است؛ بعد از این آهنگ، آهنگ‌های سرور پخش می‌شوند.")
            return
        await self._php_say("🧾 صف پخش:\n" + "\n".join(f"{i}. {t}" for i, t in enumerate(queue[:10], 1)))

    async def _php_show_library(self, page_arg=""):
        code, data = await self._php_api("library", timeout=10)
        tracks = (data or {}).get("tracks", []) if code == 200 else []
        if not tracks:
            await self.highrise.chat("📭 کتابخانه‌ی سرور خالی است یا هنوز آماده نشده.")
            return
        per = 10
        pages = (len(tracks) + per - 1) // per
        page = int(page_arg) if page_arg.isdigit() and int(page_arg) > 0 else 1
        page = min(page, pages)
        chunk = tracks[(page - 1) * per: page * per]
        text = f"🎵 آهنگ‌های سرور (صفحه {page}/{pages}):\n"
        text += "\n".join(f"{t['n']}. {t['title']}" for t in chunk)
        text += "\nپخش: !p <شماره>"
        if page < pages:
            text += f" | صفحه بعد: !musiclist {page + 1}"
        await self._php_say(text)

    async def _php_skip(self, which):
        code, data = await self._php_api(which)
        if code == 200 and data and data.get("ok"):
            self._php_quiet()
            icon = "⏭" if which == "next" else "⏮"
            await self.highrise.chat(f"{icon} الان پخش می‌شود: {data.get('title') or '—'}")
        else:
            await self.highrise.chat(f"❌ {(data or {}).get('error') or 'سرور رادیو جواب نداد'}")

    # ─── روتر دستورها ──────────────────────────────────────────
    def _php_old_handler(self, cmd):
        if cmd == "!play":
            return self._cmd_play
        if cmd in ("!prev", "!previous"):
            return self._cmd_prevsong
        if cmd == "!musiclist":
            return self._cmd_musiclist
        return self._cmd_radio

    async def _cmd_radio_php(self, user, message):
        parts = message.strip().split(maxsplit=1)
        cmd = parts[0].lower() if parts else "!radio"
        arg = parts[1].strip() if len(parts) > 1 else ""
        old = self._php_old_handler(cmd)

        if not self._php_ready():
            return await old(user, message)

        admin_msg = "⛔ این بخش فقط برای مدیر رادیو فعال است."

        if cmd in ("!radio", "!music", "!song"):
            sub = arg.split(maxsplit=1)
            action = sub[0].lower() if sub else "status"
            rest = sub[1].strip() if len(sub) > 1 else ""
            if cmd != "!radio" and arg:
                return await old(user, message)            # !music نام آهنگ ← جستجوی قدیمی
            if action in ("status", "help", "current", "now"):
                return await self._php_show_status()
            if action in ("queue", "q") and not rest:
                return await self._php_show_queue()
            if action in ("list", "library"):
                return await self._php_show_library(rest)
            if action in ("next", "skip", "prev", "previous", "back", "clear", "play", "queue", "q"):
                if action in ("queue", "q"):
                    return await self._php_start("queue", rest)
                if not self._is_admin(user):
                    return await self.highrise.chat(admin_msg)
                if action in ("next", "skip"):
                    return await self._php_skip("next")
                if action in ("prev", "previous", "back"):
                    return await self._php_skip("prev")
                if action == "clear":
                    code, data = await self._php_api("clear")
                    self._php_quiet()
                    return await self.highrise.chat("🧹 صف پاک شد." if code == 200 else "⚠️ سرور رادیو جواب نداد.")
                if not rest:
                    return await self._php_show_status()
                return await self._php_start("play", rest)
            return await old(user, message)                # search / pick / fav / vote / ...

        if cmd in ("!p", "!play"):
            if not arg:
                return await self._php_show_status()
            if not self._is_admin(user):
                return await self.highrise.chat(admin_msg)
            return await self._php_start("play", arg)

        if cmd == "!q":
            if not arg:
                return await self._php_show_queue()
            return await self._php_start("queue", arg)

        if cmd in ("!n", "!next"):
            if not self._is_admin(user):
                return await self.highrise.chat(admin_msg)
            return await self._php_skip("next")

        if cmd in ("!prev", "!previous"):
            if not self._is_admin(user):
                return await self.highrise.chat(admin_msg)
            return await self._php_skip("prev")

        if cmd == "!musiclist":
            return await self._php_show_library(arg)

        return await old(user, message)

    # ─── اعلام تمام‌شدن آهنگ (فقط بات موزیک) ──────────────────
    async def _radio_finish_announcement_loop(self):
        await asyncio.sleep(8)
        last = None
        self._php_quiet_until = getattr(self, "_php_quiet_until", 0)
        while True:
            try:
                if self._php_ready():
                    st = await self._php_status_data()
                    seq = st.get("finished_seq") if st else None
                    if seq is not None:
                        if last is None:
                            last = seq
                        elif seq != last:
                            last = seq
                            if time.time() >= self._php_quiet_until:
                                nxt = st.get("now_playing_title") or st.get("next_title") or "آهنگ بعدی"
                                await self.highrise.chat(
                                    f"✅ «{st.get('finished_title') or 'آهنگ قبلی'}» تمام شد.\n"
                                    f"▶️ بعدی: «{nxt}»"
                                )
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.debug(f"رادیو فعلاً قابل دسترسی نیست: {exc}")
            await asyncio.sleep(5)
